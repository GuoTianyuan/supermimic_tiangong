# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example Basic Plotting
#
# Shows how to access and plot per-step simulation diagnostics from the
# MuJoCo solver. This is useful for debugging solver performance, energy
# conservation, and contact behavior.
#
# The example loads a humanoid model that falls under gravity and collides
# with the ground, collecting per-step metrics:
#   - Solver iteration count (max across worlds — worst-case effort)
#   - Kinetic and potential energy (world 0 — replicated worlds are identical)
#   - Active constraint count (world 0 — replicated worlds are identical)
#
# Worlds are deterministic replicates, so per-world values are identical;
# iteration count is reported as a max to surface worst-case solver cost.
#
# Command: python -m newton.examples basic_plotting --world-count 4
#
###########################################################################

import warnings

import numpy as np
import warp as wp

import newton
import newton.examples


class Example:
    def __init__(self, viewer, args):
        self.fps = 60
        self.frame_dt = 1.0 / self.fps
        self.sim_time = 0.0
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps

        self.viewer = viewer

        humanoid = newton.ModelBuilder()
        humanoid.rigid_gap = 0.0

        mjcf_filename = newton.examples.get_asset("nv_humanoid.xml")
        humanoid.add_mjcf(
            mjcf_filename,
            ignore_names=["floor", "ground"],
            xform=wp.transform(wp.vec3(0, 0, 1.5)),
        )

        builder = newton.ModelBuilder()
        builder.rigid_gap = humanoid.rigid_gap
        builder.replicate(humanoid, args.world_count)
        builder.add_ground_plane()

        self.model = builder.finalize()

        self.solver = newton.solvers.SolverMuJoCo(self.model)

        # Enable energy computation in MuJoCo (set on whichever model backs the solver)
        try:
            import mujoco  # noqa: PLC0415

            mjm = self.solver.mjw_model if hasattr(self.solver, "mjw_model") else self.solver.mj_model
            mjm.opt.enableflags |= mujoco.mjtEnableBit.mjENBL_ENERGY
        except ImportError:
            pass

        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()

        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)

        self.collision_pipeline = newton.CollisionPipeline(self.model)
        self.contacts = self.collision_pipeline.contacts()

        # Per-step diagnostics (lists grow unbounded for interactive use)
        self.log_iterations: list[float] = []
        self.log_energy_kinetic: list[float] = []
        self.log_energy_potential: list[float] = []
        self.log_nefc: list[float] = []

        self.viewer.set_model(self.model)

        self.capture()

    def capture(self):
        try:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph
        except Exception as exc:
            self.graph = None
            warnings.warn(f"Graph capture failed: {exc}", stacklevel=2)

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.viewer.apply_forces(self.state_0)
            self.collision_pipeline.collide(self.state_0, self.contacts)
            self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def _read_status(self):
        d = self.solver.mjw_data if hasattr(self.solver, "mjw_data") else self.solver.mj_data

        # Max across worlds: worst-case solver cost.
        niter_np = d.solver_niter.numpy() if hasattr(d.solver_niter, "numpy") else d.solver_niter
        self.log_iterations.append(float(np.max(niter_np)))

        # mjData.energy columns are (potential, kinetic); read world 0.
        energy_np = d.energy.numpy() if hasattr(d.energy, "numpy") else np.asarray(d.energy)
        self.log_energy_potential.append(float(energy_np[0, 0]))
        self.log_energy_kinetic.append(float(energy_np[0, 1]))

        # nefc = active constraint rows; read world 0.
        nefc_np = d.nefc.numpy() if hasattr(d.nefc, "numpy") else d.nefc
        self.log_nefc.append(float(nefc_np[0]) if hasattr(nefc_np, "__len__") else float(nefc_np))

    def step(self):
        if self.graph:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

        self._read_status()

        # Raw per-frame values so the overlay matches the latest plot point and side panel.
        self.viewer.log_scalar("Solver Iterations (max)", self.log_iterations[-1])
        self.viewer.log_scalar("Kinetic Energy [J]", self.log_energy_kinetic[-1])
        self.viewer.log_scalar("Potential Energy [J]", self.log_energy_potential[-1])
        self.viewer.log_scalar("Active Constraints", self.log_nefc[-1])

    def test_final(self):
        # Verify the humanoid hasn't exploded or fallen through the ground
        newton.examples.test_body_state(
            self.model,
            self.state_0,
            "bodies above ground",
            lambda q, qd: q[2] > -0.1,
        )

        self._plot()

    def _plot(self):
        """Save diagnostics plots to a PNG file."""
        try:
            from matplotlib.backends.backend_agg import FigureCanvasAgg  # noqa: PLC0415
            from matplotlib.figure import Figure  # noqa: PLC0415
        except ImportError:
            self._print_summary()
            return

        n = len(self.log_iterations)
        time = np.arange(n, dtype=np.float32) * self.frame_dt

        # File-only output must not initialize a GUI or change the user's backend.
        fig = Figure(figsize=(10, 8))
        FigureCanvasAgg(fig)
        axs = fig.subplots(3, 1, sharex=True)

        axs[0].step(time, self.log_iterations, color="blue")
        axs[0].set_ylabel("Solver Iterations")
        axs[0].set_title("MuJoCo Simulation Diagnostics")
        axs[0].grid(True)

        axs[1].plot(time, self.log_energy_kinetic, color="red", label="kinetic")
        axs[1].plot(time, self.log_energy_potential, color="blue", label="potential")
        total = np.array(self.log_energy_kinetic) + np.array(self.log_energy_potential)
        axs[1].plot(time, total, color="black", linestyle="--", label="total")
        axs[1].set_ylabel("Energy [J]")
        axs[1].legend()
        axs[1].grid(True)

        axs[2].step(time, self.log_nefc, color="green")
        axs[2].set_ylabel("Active Constraints")
        axs[2].set_xlabel("Time [s]")
        axs[2].grid(True)

        fig.tight_layout()
        fig.savefig("solver_convergence.png", dpi=150)
        print("Diagnostics plot saved to solver_convergence.png")

    def _print_summary(self):
        """Print a text summary of diagnostics data."""
        n = len(self.log_iterations)
        if n == 0:
            print("\nSimulation diagnostics summary: no steps recorded.")
            return
        iters = np.array(self.log_iterations)
        print(f"\nSimulation diagnostics summary ({n} steps):")
        print(f"  Iterations (max):   mean={np.mean(iters):.1f}, peak={np.max(iters):.0f}")
        print(f"  Kinetic E [J]:    final={self.log_energy_kinetic[-1]:.4f}")
        print(f"  Potential E [J]:  final={self.log_energy_potential[-1]:.4f}")
        print(f"  Constraints:        mean={np.mean(self.log_nefc):.1f}, peak={np.max(self.log_nefc):.1f}")

    def gui(self, ui):
        n = len(self.log_iterations)
        if n == 0:
            ui.text("Waiting for simulation data...")
            return

        ui.text(f"Step: {n}")
        ui.text(f"Solver iterations (max): {int(self.log_iterations[-1])}")
        ui.text(f"Kinetic E: {self.log_energy_kinetic[-1]:.4f} J")
        ui.text(f"Potential E: {self.log_energy_potential[-1]:.4f} J")
        ui.text(f"Active constraints: {int(self.log_nefc[-1])}")

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_contacts(self.contacts, self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        newton.examples.add_world_count_arg(parser)
        parser.set_defaults(world_count=4)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    viewer, args = newton.examples.init(parser)

    newton.examples.run(Example(viewer, args), args)
