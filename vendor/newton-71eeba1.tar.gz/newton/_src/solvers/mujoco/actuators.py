# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Programmatic authoring helpers for MuJoCo actuators."""

from __future__ import annotations

from bisect import bisect_right
from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Any

import warp as wp

from ...geometry import ShapeFlags
from ...sim import JointType, ModelBuilder
from ._authoring import _add_custom_frequency_row, _ensure_mujoco_attributes, _tristate, _vector
from .enums import _ActuatorBiasType, _ActuatorDynamicsType, _ActuatorGainType


@dataclass(frozen=True)
class ActuatorTarget:
    """A typed MuJoCo actuator transmission target.

    Construct targets with :meth:`joint`, :meth:`joint_dof`, :meth:`tendon`,
    :meth:`site`, :meth:`body`, or :meth:`slider_crank`. The authoring helper
    resolves the target to MuJoCo's heterogeneous ``trnid`` representation.

    Targets must belong to the builder's current world or the global world
    (``-1``). For ball and free joints, the native MuJoCo transmission requires an explicit three- or six-component gear,
    respectively, and does not select a Newton DOF. Ball gears express torque
    in the child body frame; free gears combine world-frame force at the body
    origin with child-frame torque. Use :attr:`~newton.Control.joint_f` to apply forces in
    Newton's DOF convention.
    """

    class Kind(Enum):
        """Transmission target kinds supported by :class:`ActuatorTarget`."""

        JOINT = "joint"
        """A Newton joint, optionally restricted to one local DOF."""

        JOINT_DOF = "joint_dof"
        """An absolute Newton joint-DOF index."""

        TENDON = "tendon"
        """A ``mujoco:tendon`` row."""

        SITE = "site"
        """A Newton site shape, optionally relative to a reference site."""

        BODY = "body"
        """A Newton body."""

        SLIDER_CRANK = "slider_crank"
        """The crank and slider sites of a slider-crank transmission."""

    kind: ActuatorTarget.Kind
    """Transmission target kind."""

    index: int
    """Primary Newton entity index."""

    secondary_index: int = -1
    """Secondary Newton entity index, or ``-1`` if unused."""

    dof: int | None = None
    """Local joint DOF, when :attr:`kind` is :attr:`Kind.JOINT`."""

    @classmethod
    def joint(cls, joint: int, *, dof: int | None = None) -> ActuatorTarget:
        """Target a Newton joint, selecting a scalar axis for D6 joints.

        Args:
            joint: Newton joint index.
            dof: Local DOF within a scalar or D6 joint. Required for multi-axis
                D6 joints. Omit for ball/free joints and supply an explicit
                native MuJoCo gear to the actuator helper.

        Returns:
            A typed joint target.
        """
        return cls(cls.Kind.JOINT, int(joint), dof=None if dof is None else int(dof))

    @classmethod
    def joint_dof(cls, dof: int) -> ActuatorTarget:
        """Target an absolute Newton joint-DOF index.

        Args:
            dof: Absolute Newton joint-DOF index for a scalar or D6 joint.
                Ball/free joints require :meth:`joint` with native gear instead.

        Returns:
            A typed joint-DOF target.
        """
        return cls(cls.Kind.JOINT_DOF, int(dof))

    @classmethod
    def tendon(cls, tendon: int) -> ActuatorTarget:
        """Target a ``mujoco:tendon`` row.

        Args:
            tendon: Row index returned by :func:`add_tendon_fixed` or
                :func:`add_tendon_spatial`.

        Returns:
            A typed tendon target.
        """
        return cls(cls.Kind.TENDON, int(tendon))

    @classmethod
    def site(cls, site: int, *, refsite: int | None = None) -> ActuatorTarget:
        """Target a Newton site shape, optionally relative to another site.

        Args:
            site: Newton site-shape index.
            refsite: Optional reference site-shape index.

        Returns:
            A typed site target.
        """
        return cls(cls.Kind.SITE, int(site), -1 if refsite is None else int(refsite))

    @classmethod
    def body(cls, body: int) -> ActuatorTarget:
        """Target a Newton body.

        Args:
            body: Newton body index.

        Returns:
            A typed body target.
        """
        return cls(cls.Kind.BODY, int(body))

    @classmethod
    def slider_crank(cls, cranksite: int, slidersite: int) -> ActuatorTarget:
        """Target the crank and slider sites of a slider-crank transmission.

        Args:
            cranksite: Newton crank site-shape index.
            slidersite: Newton slider site-shape index.

        Returns:
            A typed slider-crank target.
        """
        return cls(cls.Kind.SLIDER_CRANK, int(cranksite), int(slidersite))


def _validate_index(name: str, index: int, count: int) -> None:
    if index < 0 or index >= count:
        raise IndexError(f"{name} index {index} is outside [0, {count}).")


def _validate_target_world(builder: ModelBuilder, name: str, index: int, world: int) -> None:
    if world not in (-1, builder.current_world):
        raise ValueError(
            f"{name} index {index} belongs to world {world}, "
            f"but the actuator is added to world {builder.current_world}."
        )


def _validate_site(builder: ModelBuilder, site: int, name: str) -> None:
    _validate_index(name, site, len(builder.shape_flags))
    if not (int(builder.shape_flags[site]) & int(ShapeFlags.SITE)):
        raise ValueError(f"{name} index {site} does not identify a Newton site.")
    _validate_target_world(builder, name, site, int(builder.shape_world[site]))


def _resolve_target(builder: ModelBuilder, target: ActuatorTarget) -> tuple[int, wp.vec2i, int]:
    """Resolve transmission indices and any required native gear length."""
    from .solver_mujoco import SolverMuJoCo  # noqa: PLC0415

    if not isinstance(target, ActuatorTarget):
        raise TypeError("target must be an ActuatorTarget.")

    if target.kind == ActuatorTarget.Kind.JOINT:
        _validate_index("joint", target.index, len(builder.joint_type))
        linear_dofs, angular_dofs = builder.joint_dof_dim[target.index]
        dof_count = linear_dofs + angular_dofs
        if builder.joint_type[target.index] in (JointType.BALL, JointType.FREE):
            if target.dof is not None:
                raise ValueError(
                    "Ball/free joints require a joint target without dof and an explicit native MuJoCo gear."
                )
            local_dof = 0
        elif target.dof is None:
            if dof_count != 1:
                raise ValueError(
                    f"Joint {target.index} has {dof_count} DOFs; specify the local dof in ActuatorTarget.joint()."
                )
            local_dof = 0
        else:
            local_dof = target.dof
        _validate_index("joint dof", local_dof, dof_count)
        joint = target.index
        dof = int(builder.joint_qd_start[joint]) + local_dof
    elif target.kind == ActuatorTarget.Kind.JOINT_DOF:
        _validate_index("joint dof", target.index, len(builder.joint_qd))
        dof = target.index
        joint = bisect_right(builder.joint_qd_start, dof) - 1
        if builder.joint_type[joint] in (JointType.BALL, JointType.FREE):
            raise ValueError("Ball/free joints require ActuatorTarget.joint() with an explicit native MuJoCo gear.")

    if target.kind in (ActuatorTarget.Kind.JOINT, ActuatorTarget.Kind.JOINT_DOF):
        _validate_target_world(builder, "joint", joint, int(builder.joint_world[joint]))
        gear_length = {JointType.BALL: 3, JointType.FREE: 6}.get(builder.joint_type[joint], 0)
        return int(SolverMuJoCo.TrnType.JOINT), wp.vec2i(dof, -1), gear_length

    if target.kind == ActuatorTarget.Kind.TENDON:
        tendon_count = builder._custom_frequency_counts.get("mujoco:tendon", 0)
        _validate_index("tendon", target.index, tendon_count)
        world_attr = builder.custom_attributes["mujoco:tendon_world"]
        world = world_attr.values[target.index] if target.index < len(world_attr.values) else None
        _validate_target_world(builder, "tendon", target.index, int(world_attr.default if world is None else world))
        return int(SolverMuJoCo.TrnType.TENDON), wp.vec2i(target.index, -1), 0

    if target.kind == ActuatorTarget.Kind.SITE:
        _validate_site(builder, target.index, "site")
        if target.secondary_index >= 0:
            _validate_site(builder, target.secondary_index, "refsite")
        return int(SolverMuJoCo.TrnType.SITE), wp.vec2i(target.index, target.secondary_index), 0

    if target.kind == ActuatorTarget.Kind.BODY:
        _validate_index("body", target.index, len(builder.body_mass))
        _validate_target_world(builder, "body", target.index, int(builder.body_world[target.index]))
        return int(SolverMuJoCo.TrnType.BODY), wp.vec2i(target.index, -1), 0

    if target.kind == ActuatorTarget.Kind.SLIDER_CRANK:
        _validate_site(builder, target.index, "cranksite")
        _validate_site(builder, target.secondary_index, "slidersite")
        return int(SolverMuJoCo.TrnType.SLIDERCRANK), wp.vec2i(target.index, target.secondary_index), 0

    raise ValueError(f"Unsupported actuator target kind {target.kind!r}.")


def _enum_value(value: int | str, mapping: dict[str, int], name: str) -> int:
    if isinstance(value, str):
        try:
            return mapping[value.lower().replace("_", "").strip()]
        except KeyError as error:
            choices = ", ".join(sorted(mapping))
            raise ValueError(f"Unknown {name} {value!r}; expected one of {choices}.") from error
    return int(value)


def _dynamics_type(value: int | str) -> int:
    return _enum_value(
        value,
        {
            "none": int(_ActuatorDynamicsType.NONE),
            "integrator": int(_ActuatorDynamicsType.INTEGRATOR),
            "filter": int(_ActuatorDynamicsType.FILTER),
            "filterexact": int(_ActuatorDynamicsType.FILTER_EXACT),
            "muscle": int(_ActuatorDynamicsType.MUSCLE),
            "user": int(_ActuatorDynamicsType.USER),
        },
        "dyntype",
    )


def _gain_type(value: int | str) -> int:
    return _enum_value(
        value,
        {
            "fixed": int(_ActuatorGainType.FIXED),
            "affine": int(_ActuatorGainType.AFFINE),
            "muscle": int(_ActuatorGainType.MUSCLE),
            "user": int(_ActuatorGainType.USER),
        },
        "gaintype",
    )


def _bias_type(value: int | str) -> int:
    return _enum_value(
        value,
        {
            "none": int(_ActuatorBiasType.NONE),
            "affine": int(_ActuatorBiasType.AFFINE),
            "muscle": int(_ActuatorBiasType.MUSCLE),
            "user": int(_ActuatorBiasType.USER),
        },
        "biastype",
    )


def _add_actuator(
    builder: ModelBuilder,
    target: ActuatorTarget,
    *,
    ctrl_type: int,
    dyntype: int | str = "none",
    gaintype: int | str = "fixed",
    biastype: int | str = "none",
    dynprm: Sequence[float] = (1.0,),
    gainprm: Sequence[float] = (1.0,),
    biasprm: Sequence[float] = (0.0,),
    gear: Sequence[float] = (1.0,),
    ctrlrange: Sequence[float] | None = None,
    ctrllimited: bool | int | str = "auto",
    forcerange: Sequence[float] | None = None,
    forcelimited: bool | int | str = "auto",
    actrange: Sequence[float] | None = None,
    actlimited: bool | int | str = "auto",
    actdim: int | None = None,
    actearly: bool = False,
    cranklength: float | None = None,
    ctrl: float = 0.0,
    custom_attributes: dict[str, Any] | None = None,
) -> int:
    from .solver_mujoco import SolverMuJoCo  # noqa: PLC0415

    _ensure_mujoco_attributes(builder, "mujoco:actuator_trnid")
    trntype, trnid, gear_length = _resolve_target(builder, target)
    if gear_length and len(gear) < gear_length:
        raise ValueError(f"This joint requires an explicit native MuJoCo gear with at least {gear_length} components.")
    if trntype == int(SolverMuJoCo.TrnType.SLIDERCRANK):
        if cranklength is None or cranklength <= 0.0:
            raise ValueError("A slider-crank actuator requires a positive cranklength [m].")

    values: dict[str, Any] = {
        "mujoco:actuator_trnid": trnid,
        "mujoco:actuator_target_label": "",
        "mujoco:actuator_trntype": trntype,
        "mujoco:actuator_dyntype": _dynamics_type(dyntype),
        "mujoco:actuator_gaintype": _gain_type(gaintype),
        "mujoco:actuator_biastype": _bias_type(biastype),
        "mujoco:actuator_world": builder.current_world,
        "mujoco:actuator_ctrllimited": _tristate(ctrllimited),
        "mujoco:actuator_forcelimited": _tristate(forcelimited),
        "mujoco:actuator_ctrlrange": _vector(
            builder,
            "mujoco:actuator_ctrlrange",
            ctrlrange if ctrlrange is not None else (0.0, 0.0),
            2,
        ),
        "mujoco:actuator_has_ctrlrange": int(ctrlrange is not None),
        "mujoco:actuator_forcerange": _vector(
            builder,
            "mujoco:actuator_forcerange",
            forcerange if forcerange is not None else (0.0, 0.0),
            2,
        ),
        "mujoco:actuator_has_forcerange": int(forcerange is not None),
        "mujoco:actuator_gear": _vector(builder, "mujoco:actuator_gear", gear, 6, exact=False),
        "mujoco:actuator_cranklength": 0.0 if cranklength is None else float(cranklength),
        "mujoco:actuator_dynprm": _vector(builder, "mujoco:actuator_dynprm", dynprm, 10, exact=False),
        "mujoco:actuator_gainprm": _vector(builder, "mujoco:actuator_gainprm", gainprm, 10, exact=False),
        "mujoco:actuator_biasprm": _vector(builder, "mujoco:actuator_biasprm", biasprm, 10, exact=False),
        "mujoco:actuator_actlimited": _tristate(actlimited),
        "mujoco:actuator_actrange": _vector(
            builder,
            "mujoco:actuator_actrange",
            actrange if actrange is not None else (0.0, 0.0),
            2,
        ),
        "mujoco:actuator_has_actrange": int(actrange is not None),
        "mujoco:actuator_actdim": -1 if actdim is None else int(actdim),
        "mujoco:actuator_actearly": bool(actearly),
        "mujoco:ctrl": float(ctrl),
        "mujoco:ctrl_source": int(SolverMuJoCo.CtrlSource.CTRL_DIRECT),
        "mujoco:ctrl_type": int(ctrl_type),
    }

    return _add_custom_frequency_row(
        builder,
        "mujoco:actuator",
        values,
        index_key="mujoco:actuator_trnid",
        custom_attributes=custom_attributes,
    )


def add_actuator_general(
    builder: ModelBuilder,
    target: ActuatorTarget,
    *,
    dyntype: int | str = "none",
    gaintype: int | str = "fixed",
    biastype: int | str = "none",
    dynprm: Sequence[float] = (1.0,),
    gainprm: Sequence[float] = (1.0,),
    biasprm: Sequence[float] = (0.0,),
    gear: Sequence[float] = (1.0,),
    ctrlrange: Sequence[float] | None = None,
    ctrllimited: bool | int | str = "auto",
    forcerange: Sequence[float] | None = None,
    forcelimited: bool | int | str = "auto",
    actrange: Sequence[float] | None = None,
    actlimited: bool | int | str = "auto",
    actdim: int | None = None,
    actearly: bool = False,
    cranklength: float | None = None,
    ctrl: float = 0.0,
    custom_attributes: dict[str, Any] | None = None,
) -> int:
    """Add a MuJoCo-native general actuator controlled through ``control.mujoco.ctrl``.

    Args:
        builder: Model builder receiving the actuator.
        target: Typed actuator transmission target.
        dyntype: MuJoCo activation dynamics type.
        gaintype: MuJoCo gain type.
        biastype: MuJoCo bias type.
        dynprm: Activation dynamics parameters, padded to ten values.
        gainprm: Gain parameters, padded to ten values.
        biasprm: Bias parameters, padded to ten values.
        gear: Native MuJoCo transmission gear, padded to six values. Ball/free
            joints require at least three/six components; these use MuJoCo's
            frames and force reference point, as described in :class:`ActuatorTarget`.
        ctrlrange: Optional control range.
        ctrllimited: Control-limit tri-state (false, true, or auto).
        forcerange: Optional actuator force range [N or N·m].
        forcelimited: Force-limit tri-state (false, true, or auto).
        actrange: Optional activation-state range.
        actlimited: Activation-limit tri-state (false, true, or auto).
        actdim: Activation-state dimension, or ``None`` for automatic selection.
        actearly: Whether force uses the next activation state.
        cranklength: Slider-crank length [m]. Required for slider-crank targets.
        ctrl: Initial MuJoCo control value.
        custom_attributes: Additional registered ``mujoco:actuator`` attributes.

    Returns:
        The ``mujoco:actuator`` row index.
    """
    from .solver_mujoco import SolverMuJoCo  # noqa: PLC0415

    return _add_actuator(
        builder,
        target,
        ctrl_type=int(SolverMuJoCo.CtrlType.GENERAL),
        dyntype=dyntype,
        gaintype=gaintype,
        biastype=biastype,
        dynprm=dynprm,
        gainprm=gainprm,
        biasprm=biasprm,
        gear=gear,
        ctrlrange=ctrlrange,
        ctrllimited=ctrllimited,
        forcerange=forcerange,
        forcelimited=forcelimited,
        actrange=actrange,
        actlimited=actlimited,
        actdim=actdim,
        actearly=actearly,
        cranklength=cranklength,
        ctrl=ctrl,
        custom_attributes=custom_attributes,
    )


def add_actuator_motor(
    builder: ModelBuilder,
    target: ActuatorTarget,
    *,
    gear: Sequence[float] = (1.0,),
    ctrlrange: Sequence[float] | None = None,
    ctrllimited: bool | int | str = "auto",
    forcerange: Sequence[float] | None = None,
    forcelimited: bool | int | str = "auto",
    cranklength: float | None = None,
    ctrl: float = 0.0,
    custom_attributes: dict[str, Any] | None = None,
) -> int:
    """Add a MuJoCo motor shortcut controlled through ``control.mujoco.ctrl``.

    Args:
        builder: Model builder receiving the actuator.
        target: Typed actuator transmission target.
        gear: Native MuJoCo transmission gear, padded to six values. Ball/free
            joints require at least three/six components; these use MuJoCo's
            frames and force reference point, as described in :class:`ActuatorTarget`.
        ctrlrange: Optional control range.
        ctrllimited: Control-limit tri-state (false, true, or auto).
        forcerange: Optional actuator force range [N or N·m].
        forcelimited: Force-limit tri-state (false, true, or auto).
        cranklength: Slider-crank length [m]. Required for slider-crank targets.
        ctrl: Initial MuJoCo control value.
        custom_attributes: Additional registered ``mujoco:actuator`` attributes.

    Returns:
        The ``mujoco:actuator`` row index.
    """
    return add_actuator_general(
        builder,
        target,
        gainprm=(1.0,),
        biasprm=(0.0,),
        gear=gear,
        ctrlrange=ctrlrange,
        ctrllimited=ctrllimited,
        forcerange=forcerange,
        forcelimited=forcelimited,
        cranklength=cranklength,
        ctrl=ctrl,
        custom_attributes=custom_attributes,
    )


def add_actuator_position(
    builder: ModelBuilder,
    target: ActuatorTarget,
    *,
    kp: float = 1.0,
    kv: float = 0.0,
    dampratio: float = 0.0,
    gear: Sequence[float] = (1.0,),
    ctrlrange: Sequence[float] | None = None,
    ctrllimited: bool | int | str = "auto",
    forcerange: Sequence[float] | None = None,
    forcelimited: bool | int | str = "auto",
    cranklength: float | None = None,
    ctrl: float = 0.0,
    custom_attributes: dict[str, Any] | None = None,
) -> int:
    """Add a MuJoCo position shortcut controlled through ``control.mujoco.ctrl``.

    Args:
        builder: Model builder receiving the actuator.
        target: Typed actuator transmission target.
        kp: Position feedback gain.
        kv: Velocity feedback gain.
        dampratio: Damping ratio used when ``kv`` is zero.
        gear: Native MuJoCo transmission gear, padded to six values. Ball/free
            joints require at least three/six components; these use MuJoCo's
            frames and force reference point, as described in :class:`ActuatorTarget`.
        ctrlrange: Optional control range.
        ctrllimited: Control-limit tri-state (false, true, or auto).
        forcerange: Optional actuator force range [N or N·m].
        forcelimited: Force-limit tri-state (false, true, or auto).
        cranklength: Slider-crank length [m]. Required for slider-crank targets.
        ctrl: Initial MuJoCo control value.
        custom_attributes: Additional registered ``mujoco:actuator`` attributes.

    Returns:
        The ``mujoco:actuator`` row index.
    """
    from .solver_mujoco import SolverMuJoCo  # noqa: PLC0415

    if kp < 0.0:
        raise ValueError("kp must be nonnegative.")
    if kv < 0.0 or dampratio < 0.0:
        raise ValueError("kv and dampratio must be nonnegative.")
    if kv != 0.0 and dampratio != 0.0:
        raise ValueError("Specify either kv or dampratio, not both.")
    bias_damping = -float(kv) if kv != 0.0 else (float(dampratio) if kp > 0.0 else 0.0)
    return _add_actuator(
        builder,
        target,
        ctrl_type=int(SolverMuJoCo.CtrlType.POSITION),
        gaintype="fixed",
        biastype="affine",
        gainprm=(kp,),
        biasprm=(0.0, -kp, bias_damping),
        gear=gear,
        ctrlrange=ctrlrange,
        ctrllimited=ctrllimited,
        forcerange=forcerange,
        forcelimited=forcelimited,
        cranklength=cranklength,
        ctrl=ctrl,
        custom_attributes=custom_attributes,
    )


def add_actuator_velocity(
    builder: ModelBuilder,
    target: ActuatorTarget,
    *,
    kv: float = 1.0,
    gear: Sequence[float] = (1.0,),
    ctrlrange: Sequence[float] | None = None,
    ctrllimited: bool | int | str = "auto",
    forcerange: Sequence[float] | None = None,
    forcelimited: bool | int | str = "auto",
    cranklength: float | None = None,
    ctrl: float = 0.0,
    custom_attributes: dict[str, Any] | None = None,
) -> int:
    """Add a MuJoCo velocity shortcut controlled through ``control.mujoco.ctrl``.

    Args:
        builder: Model builder receiving the actuator.
        target: Typed actuator transmission target.
        kv: Velocity feedback gain.
        gear: Native MuJoCo transmission gear, padded to six values. Ball/free
            joints require at least three/six components; these use MuJoCo's
            frames and force reference point, as described in :class:`ActuatorTarget`.
        ctrlrange: Optional control range.
        ctrllimited: Control-limit tri-state (false, true, or auto).
        forcerange: Optional actuator force range [N or N·m].
        forcelimited: Force-limit tri-state (false, true, or auto).
        cranklength: Slider-crank length [m]. Required for slider-crank targets.
        ctrl: Initial MuJoCo control value.
        custom_attributes: Additional registered ``mujoco:actuator`` attributes.

    Returns:
        The ``mujoco:actuator`` row index.
    """
    from .solver_mujoco import SolverMuJoCo  # noqa: PLC0415

    if kv < 0.0:
        raise ValueError("kv must be nonnegative.")
    return _add_actuator(
        builder,
        target,
        ctrl_type=int(SolverMuJoCo.CtrlType.VELOCITY),
        gaintype="fixed",
        biastype="affine",
        gainprm=(kv,),
        biasprm=(0.0, 0.0, -kv),
        gear=gear,
        ctrlrange=ctrlrange,
        ctrllimited=ctrllimited,
        forcerange=forcerange,
        forcelimited=forcelimited,
        cranklength=cranklength,
        ctrl=ctrl,
        custom_attributes=custom_attributes,
    )


__all__ = [
    "ActuatorTarget",
    "add_actuator_general",
    "add_actuator_motor",
    "add_actuator_position",
    "add_actuator_velocity",
]
