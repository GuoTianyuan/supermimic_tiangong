# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""
Defines configurations for :class:`SolverKamino`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Literal

import warp as wp

from ...core.types import override
from ...sim import Model, ModelBuilder

###
# Module interface
###

__all__ = [
    "CollisionDetectorConfig",
    "ConfigBase",
    "ConstrainedDynamicsConfig",
    "ConstraintStabilizationConfig",
    "DVIAPGDConfig",
    "DVISolverConfig",
    "ForwardKinematicsSolverConfig",
    "PADMMSolverConfig",
]


###
# Types
###


@dataclass
class ConfigBase:
    """
    Defines a base class for configuration containers providing interfaces for
    registering custom attributes and parsing configurations from a Newton model.
    """

    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for config type with the given builder.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        pass

    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> ConfigBase:
        """
        Creates a :class:`ConfigBase` by attempting to parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        return ConfigBase(**kwargs)

    def validate(self) -> None:
        """
        Validates the config parameters to ensure they are within acceptable ranges and consistent with each other.

        Raises:
            ValueError: If any parameter is out of range or if there are inconsistencies between parameters.
            TypeError: If any parameter is of an incorrect type.
        """
        pass


@dataclass
class CollisionDetectorConfig(ConfigBase):
    """
    A container to hold configurations for the internal collision detector used for contact generation.
    """

    pipeline: Literal["primitive", "unified"] = "unified"
    """
    The type of collision-detection pipeline to use, either `primitive` or `unified`.\n
    Defaults to `unified`.
    """

    broadphase: Literal["nxn", "sap", "explicit"] = "explicit"
    """
    The broad-phase collision-detection to use (`nxn`, `sap`, or `explicit`).\n
    Defaults to `explicit`.
    """

    bvtype: Literal["aabb", "bs"] = "aabb"
    """
    The type of bounding volume to use in the broad-phase.\n
    Defaults to `aabb`.
    """

    max_contacts: int | None = None
    """
    Model-wide cap on contact buffer capacity during collision-detector
    initialization.\n
    When ``max_contacts_per_world`` is None, the geometry-based estimate is
    capped at this value; otherwise this field is ignored.\n
    Defaults to ``None``, leaving the geometry-based estimate uncapped.
    """

    max_contacts_per_world: int | None = None
    """
    Per-world contact buffer capacity override.\n
    When set, allocates ``max_contacts_per_world`` contacts for every world
    (``num_worlds * max_contacts_per_world`` total), bypassing the
    geometry-based estimate and ``max_contacts``.\n
    Defaults to ``None``.
    """

    max_contacts_per_pair: int | None = None
    """
    The maximum number of contacts to generate per candidate geom-pair.\n
    Used to compute the total maximum contacts allocated for the model,
    in conjunction with the total number of candidate geom-pairs.\n
    Defaults to `DEFAULT_GEOM_PAIR_MAX_CONTACTS` (`12`) if unspecified.
    """

    max_triangle_pairs: int | None = None
    """
    The maximum number of triangle-primitive shape pairs to consider in the narrow-phase.\n
    Used only when the model contains triangle meshes or heightfields.\n
    Defaults to `DEFAULT_TRIANGLE_MAX_PAIRS` (`1_000_000`) if unspecified.
    """

    default_gap: float | None = None
    """
    The default detection gap [m] applied as a floor to per-geometry gaps.\n
    Defaults to `DEFAULT_GEOM_PAIR_CONTACT_GAP` (`0.0`) if unspecified.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for the CollisionDetector solver config with the given builder.

        Note: Currently, this class does not have any custom attributes registered,
        as only those supported by the Kamino USD scene API have been included. More
        will be added in the future as latter is being developed.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        pass  # TODO: Add custom attributes for the CD when supported by the Kamino USD scene API

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> CollisionDetectorConfig:
        """
        Creates a :class:`CollisionDetectorConfig` by attempting to
        parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        cfg = CollisionDetectorConfig(**kwargs)

        # TODO: Implement these

        # Return the fully constructed config with configurations
        # parsed from the model's custom attributes if available,
        # otherwise using defaults or provided kwargs.
        return cfg

    @override
    def validate(self) -> None:
        """
        Validates the current values held by the :class:`CollisionDetectorConfig` instance.
        """
        # Import here to avoid module-level imports and circular dependencies
        from ._src.geometry import BoundingVolumeType, BroadPhaseType, CollisionPipelineType  # noqa: PLC0415
        from ._src.geometry.contacts import (  # noqa: PLC0415
            DEFAULT_GEOM_PAIR_CONTACT_GAP,
            DEFAULT_GEOM_PAIR_MAX_CONTACTS,
            DEFAULT_TRIANGLE_MAX_PAIRS,
        )

        # Check that the string literals provided correspond to supported enum types, and raise an error if not
        pipelines_supported = [e.name.lower() for e in CollisionPipelineType]
        if self.pipeline not in pipelines_supported:
            raise ValueError(f"Invalid CD pipeline type: {self.pipeline}. Valid options are: {pipelines_supported}")
        broadphases_supported = [e.name.lower() for e in BroadPhaseType]
        if self.broadphase not in broadphases_supported:
            raise ValueError(
                f"Invalid CD broad-phase type: {self.broadphase}. Valid options are: {broadphases_supported}"
            )
        bvtypes_supported = [e.name.lower() for e in BoundingVolumeType]
        if self.bvtype not in bvtypes_supported:
            raise ValueError(f"Invalid CD bounding-volume type: {self.bvtype}. Valid options are: {bvtypes_supported}")

        # Ensure that max_contacts, if specified, is non-negative
        if self.max_contacts is not None and self.max_contacts < 0:
            raise ValueError(f"Invalid max_contacts: {self.max_contacts}. Must be non-negative.")
        if self.max_contacts_per_world is not None and self.max_contacts_per_world < 0:
            raise ValueError(f"Invalid max_contacts_per_world: {self.max_contacts_per_world}. Must be non-negative.")
        if self.max_contacts_per_pair is not None and self.max_contacts_per_pair < 0:
            raise ValueError(f"Invalid max_contacts_per_pair: {self.max_contacts_per_pair}. Must be non-negative.")
        if self.max_triangle_pairs is not None and self.max_triangle_pairs < 0:
            raise ValueError(f"Invalid max_triangle_pairs: {self.max_triangle_pairs}. Must be non-negative.")

        # Check if optional arguments are specified and override with defaults if not
        if self.max_contacts_per_pair is None:
            self.max_contacts_per_pair = DEFAULT_GEOM_PAIR_MAX_CONTACTS
        if self.max_triangle_pairs is None:
            self.max_triangle_pairs = DEFAULT_TRIANGLE_MAX_PAIRS
        if self.default_gap is None:
            self.default_gap = DEFAULT_GEOM_PAIR_CONTACT_GAP

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()


@dataclass
class ConstraintStabilizationConfig(ConfigBase):
    """
    A container to hold configurations for global constraint stabilization parameters.

    These parameters serve as global defaults/overrides, to be used
    in combination with the per-constraint stabilization parameters
    specified in the model, if the latter are provided.
    """

    alpha: float = 0.01
    """
    Global default Baumgarte stabilization parameter for bilateral joint constraints.\n
    Must be in range `[0, 1.0]`.\n
    Defaults to `0.01`.
    """

    beta: float = 0.01
    """
    Global default Baumgarte stabilization parameter for unilateral joint-limit constraints.\n
    Must be in range `[0, 1.0]`.\n
    Defaults to `0.01`.
    """

    gamma: float = 0.01
    """
    Global default Baumgarte stabilization parameter for unilateral contact constraints.\n
    Must be in range `[0, 1.0]`.\n
    Defaults to `0.01`.
    """

    delta: float = 1.0e-6
    """
    Contact penetration margin used for unilateral contact constraints.\n
    Must be non-negative.\n
    Defaults to `1.0e-6`.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for this config with the given builder.

        Note: Currently, not all configurations are registered as custom attributes,
        as only those supported by the Kamino USD scene API have been included. More
        will be added in the future as latter is being developed.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        # Create a default instance of the config to access default values for the attributes
        default_cfg = ConstraintStabilizationConfig()

        # Register KaminoSceneAPI attributes so the USD importer will store them on the model
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="constraints_alpha",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=default_cfg.alpha,
                namespace="kamino",
                usd_attribute_name="newton:kamino:constraints:alpha",
            )
        )
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="constraints_beta",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=default_cfg.beta,
                namespace="kamino",
                usd_attribute_name="newton:kamino:constraints:beta",
            )
        )
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="constraints_gamma",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=default_cfg.gamma,
                namespace="kamino",
                usd_attribute_name="newton:kamino:constraints:gamma",
            )
        )

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> ConstraintStabilizationConfig:
        """
        Creates a :class:`ConstraintStabilizationConfig` by attempting
        to parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        cfg = ConstraintStabilizationConfig(**kwargs)

        # Parse solver-specific attributes imported from USD
        kamino_attrs = getattr(model, "kamino", None)
        if kamino_attrs is not None:
            if hasattr(kamino_attrs, "constraints_alpha"):
                cfg.alpha = float(kamino_attrs.constraints_alpha.numpy()[0])
            if hasattr(kamino_attrs, "constraints_beta"):
                cfg.beta = float(kamino_attrs.constraints_beta.numpy()[0])
            if hasattr(kamino_attrs, "constraints_gamma"):
                cfg.gamma = float(kamino_attrs.constraints_gamma.numpy()[0])

        # Return the fully constructed config with configurations
        # parsed from the model's custom attributes if available,
        # otherwise using defaults or provided kwargs.
        return cfg

    @override
    def validate(self) -> None:
        """
        Validates the current values held by the :class:`ConstraintStabilizationConfig` instance.
        """
        if self.alpha < 0.0 or self.alpha > 1.0:
            raise ValueError(f"Invalid alpha: {self.alpha}. Must be in range [0, 1.0].")
        if self.beta < 0.0 or self.beta > 1.0:
            raise ValueError(f"Invalid beta: {self.beta}. Must be in range [0, 1.0].")
        if self.gamma < 0.0 or self.gamma > 1.0:
            raise ValueError(f"Invalid gamma: {self.gamma}. Must be in range [0, 1.0].")
        if self.delta < 0.0:
            raise ValueError(f"Invalid delta: {self.delta}. Must be non-negative.")

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()


@dataclass
class ConstrainedDynamicsConfig(ConfigBase):
    """
    A container to hold configurations for the construction of the constrained forward dynamics problem.
    """

    preconditioning: bool = True
    """
    Set to `True` to enable preconditioning of the dual problem.\n
    Defaults to `True`.
    """

    linear_solver_type: Literal["LLTB", "LLTBRCM", "CR", "CRF"] = "LLTB"
    """
    The type of linear solver to use for the dynamics problem.\n
    See :class:`LinearSolverType` for available options.\n
    Defaults to 'LLTB' (:class:`LLTBlockedSolver`, dense blocked LLT). The
    RCM-reordered semi-sparse variant is available as 'LLTBRCM'
    (:class:`LLTBlockedRCMSolver`) and is currently opt-in pending further
    performance optimization.
    """

    linear_solver_kwargs: dict[str, Any] = field(default_factory=dict)
    """
    Additional keyword arguments to pass to the linear solver.\n
    Defaults to an empty dictionary.
    """

    cull_speculative_contacts: bool = True
    """
    Whether to cull speculative (= separated) contacts in the dynamics solve.
    These contacts have occasionally led to numerical instabilities, and
    can yield inaccurate restitutive impacts.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for the constrained dynamics problem configurations with the given builder.

        Note: Currently, not all configurations are registered as custom attributes,
        as only those supported by the Kamino USD scene API have been included. More
        will be added in the future as latter is being developed.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        # Register KaminoSceneAPI attributes so the USD importer will store them on the model
        # TODO: Rename `name` to this to "dynamics_preconditioning" or similar
        # TODO: Rename `usd_attribute_name` to "newton:kamino:usePreconditioning" or similar
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="constraints_use_preconditioning",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.bool,
                default=True,
                namespace="kamino",
                usd_attribute_name="newton:kamino:constraints:usePreconditioning",
            )
        )

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> ConstrainedDynamicsConfig:
        """
        Creates a :class:`ConstrainedDynamicsConfig` by attempting to
        parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        cfg = ConstrainedDynamicsConfig(**kwargs)

        # Parse solver-specific attributes imported from USD
        kamino_attrs = getattr(model, "kamino", None)
        if kamino_attrs is not None:
            if hasattr(kamino_attrs, "constraints_use_preconditioning"):
                cfg.preconditioning = bool(kamino_attrs.constraints_use_preconditioning.numpy()[0])

        # Return the fully constructed config with configurations
        # parsed from the model's custom attributes if available,
        # otherwise using defaults or provided kwargs.
        return cfg

    @override
    def validate(self) -> None:
        """
        Validates the current values held by the :class:`ConstrainedDynamicsConfig` instance.
        """
        # Import here to avoid module-level imports and circular dependencies
        from ._src.linalg import LinearSolverNameToType  # noqa: PLC0415

        # Ensure that the linear solver type is a valid option
        supported_linear_solver_types = LinearSolverNameToType.keys()
        if self.linear_solver_type not in supported_linear_solver_types:
            raise ValueError(
                f"Invalid linear_solver_type: {self.linear_solver_type}. "
                f"Must be one of {supported_linear_solver_types}."
            )

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()


@dataclass
class PADMMSolverConfig:
    """
    A container to hold configurations for the PADMM forward dynamics solver.
    """

    primal_tolerance: float = 1e-6
    """
    The target tolerance on the total primal residual `r_primal`.\n
    Must be greater than zero. Defaults to `1e-6`.
    """

    dual_tolerance: float = 1e-6
    """
    The target tolerance on the total dual residual `r_dual`.\n
    Must be greater than zero. Defaults to `1e-6`.
    """

    compl_tolerance: float = 1e-6
    """
    The target tolerance on the complementarity residual `r_compl`.\n
    Must be greater than zero. Defaults to `1e-6`.
    """

    restart_tolerance: float = 0.999
    """
    The tolerance on the total combined primal-dual residual `r_comb`,
    for determining when gradient acceleration should be restarted.\n
    Must be greater than zero. Defaults to `0.999`.
    """

    eta: float = 1e-5
    """
    The proximal regularization parameter.\n
    Must be greater than zero. Defaults to `1e-5`.
    """

    rho_0: float = 1.0
    """
    The initial value of the ALM penalty parameter.\n
    Must be greater than zero. Defaults to `1.0`.
    """

    rho_min: float = 1e-5
    """
    The lower-bound applied to the ALM penalty parameter.\n
    Used to ensure numerical stability when adaptive penalty updates are used.\n
    Must be greater than zero. Defaults to `1e-5`.
    """

    a_0: float = 1.0
    """
    The initial value of the acceleration parameter.\n
    Must be greater than zero. Defaults to `1.0`.
    """

    alpha: float = 10.0
    """
    The primal-dual residual threshold used to determine when penalty updates are needed.
    Must be greater than one. Defaults to `10.0`.
    """

    tau: float = 1.5
    """
    The factor by which the ALM penalty is increased/decreased when
    the primal-dual residual ratios exceed the threshold `alpha`.\n
    Must be greater than `1.0`. Defaults to `1.5`.
    """

    max_iterations: int = 200
    """
    The maximum number of solver iterations.\n
    Must be greater than zero. Defaults to `200`.
    """

    penalty_update_freq: int = 1
    """
    The permitted frequency of penalty updates.\n
    If zero, no updates are performed. Otherwise, updates are performed every
    `penalty_update_freq` iterations. Defaults to `1`.
    """

    penalty_update_method: Literal["fixed", "balanced"] = "fixed"
    """
    The penalty update method used to adapt the penalty parameter.\n
    Defaults to `fixed`. See :class:`PADMMPenaltyUpdate` for details.
    """

    linear_solver_tolerance: float = 0.0
    """
    The default absolute tolerance for the iterative linear solver.\n
    When zero, the iterative solver's own tolerance is left unchanged.\n
    When positive, the iterative solver's atol is initialized
    to this value at the start of each ADMM solve.\n
    Must be non-negative. Defaults to `0.0`.
    """

    linear_solver_tolerance_ratio: float = 0.0
    """
    The ratio used to adapt the iterative linear solver tolerance from the ADMM primal residual.\n
    When zero, the linear solver tolerance is not adapted (fixed tolerance).\n
    When positive, the linear solver absolute tolerance is
    set to `ratio * ||r_primal||_2` at each ADMM iteration.\n
    Must be non-negative. Defaults to `0.0`.
    """

    use_acceleration: bool = True
    """
    Enables Nesterov-type acceleration, i.e. use APADMM instead of standard PADMM.\n
    Defaults to `True`.
    """

    use_graph_conditionals: bool = True
    """
    Enables use of CUDA graph conditional nodes in iterative solvers.\n
    If `False`, replaces `wp.capture_while` with unrolled for-loops over max iterations.\n
    Defaults to `True`.
    """

    warmstart_mode: Literal["none", "internal", "containers"] = "containers"
    """
    Warmstart mode to be used for the dynamics solver.\n
    See :class:`PADMMWarmStartMode` for the available options.\n
    Defaults to `containers` to warmstart from the solver data containers.
    """

    warmstart_scale: float = 0.9
    """
    Scale applied to cached constraint forces during warm-starting.\n
    Must be in the range [0, 1]. Defaults to `0.9`.

    PADMM converges to a minimum-norm deviation from its initial guess. Scaling
    the warm-start forces makes null-space forces converge to the overall
    minimum-norm solution.
    """

    contact_warmstart_method: Literal[
        "key_and_position",
        "geom_pair_net_force",
        "geom_pair_net_wrench",
        "key_and_position_with_net_force_backup",
        "key_and_position_with_net_wrench_backup",
    ] = "key_and_position"
    """
    Method to be used for warm-starting contacts.\n
    See :class:`WarmstarterContacts.Method` for available options.\n
    Defaults to `key_and_position`.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for the PADMM solver configurations with the given builder.

        Note: Currently, not all configurations are registered as custom attributes,
        as only those supported by the Kamino USD scene API have been included. More
        will be added in the future as latter is being developed.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        # Import here to avoid module-level imports and circular dependencies
        from ._src.solvers.padmm import PADMMWarmStartMode  # noqa: PLC0415

        # Separately register `newton:maxSolverIterations` from
        # `KaminoSceneAPI` so we have access to it through the model.
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="max_solver_iterations",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.int32,
                default=-1,
                namespace="kamino",
                usd_attribute_name="newton:maxSolverIterations",
            )
        )

        # Register KaminoSceneAPI attributes so the USD importer will store them on the model
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="padmm_primal_tolerance",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=1e-6,
                namespace="kamino",
                usd_attribute_name="newton:kamino:padmm:primalTolerance",
            )
        )
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="padmm_dual_tolerance",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=1e-6,
                namespace="kamino",
                usd_attribute_name="newton:kamino:padmm:dualTolerance",
            )
        )
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="padmm_complementarity_tolerance",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=1e-6,
                namespace="kamino",
                usd_attribute_name="newton:kamino:padmm:complementarityTolerance",
            )
        )
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="padmm_use_acceleration",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=wp.bool,
                default=True,
                namespace="kamino",
                usd_attribute_name="newton:kamino:padmm:useAcceleration",
            )
        )
        builder.add_custom_attribute(
            ModelBuilder.CustomAttribute(
                name="padmm_warmstarting",
                frequency=Model.AttributeFrequency.ONCE,
                assignment=Model.AttributeAssignment.MODEL,
                dtype=str,
                default="containers",
                namespace="kamino",
                usd_attribute_name="newton:kamino:padmm:warmstarting",
                usd_value_transformer=PADMMWarmStartMode.parse_usd_attribute,
            )
        )

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> PADMMSolverConfig:
        """
        Creates a :class:`PADMMSolverConfig` by attempting to
        parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        cfg = PADMMSolverConfig(**kwargs)

        # Parse solver-specific attributes imported from USD
        kamino_attrs = getattr(model, "kamino", None)
        if kamino_attrs is not None:
            if hasattr(kamino_attrs, "max_solver_iterations"):
                max_iterations = kamino_attrs.max_solver_iterations.numpy()[0]
                if max_iterations >= 0:
                    cfg.max_iterations = max_iterations
            if hasattr(kamino_attrs, "padmm_primal_tolerance"):
                cfg.primal_tolerance = float(kamino_attrs.padmm_primal_tolerance.numpy()[0])
            if hasattr(kamino_attrs, "padmm_dual_tolerance"):
                cfg.dual_tolerance = float(kamino_attrs.padmm_dual_tolerance.numpy()[0])
            if hasattr(kamino_attrs, "padmm_complementarity_tolerance"):
                cfg.compl_tolerance = float(kamino_attrs.padmm_complementarity_tolerance.numpy()[0])
            if hasattr(kamino_attrs, "padmm_warmstarting"):
                cfg.warmstart_mode = kamino_attrs.padmm_warmstarting[0]
            if hasattr(kamino_attrs, "padmm_use_acceleration"):
                cfg.use_acceleration = bool(kamino_attrs.padmm_use_acceleration.numpy()[0])

        # Return the fully constructed config with configurations
        # parsed from the model's custom attributes if available,
        # otherwise using defaults or provided kwargs.
        return cfg

    @override
    def validate(self) -> None:
        """
        Validates the current values held by the :class:`PADMMSolverConfig` instance.
        """
        # Import here to avoid module-level imports and circular dependencies
        from ._src.solvers.padmm import PADMMPenaltyUpdate, PADMMWarmStartMode  # noqa: PLC0415
        from ._src.solvers.warmstart import WarmstarterContacts  # noqa: PLC0415

        # Ensure that the scalar parameters are within valid ranges
        if self.primal_tolerance < 0.0:
            raise ValueError(f"Invalid primal tolerance: {self.primal_tolerance}. Must be non-negative.")
        if self.dual_tolerance < 0.0:
            raise ValueError(f"Invalid dual tolerance: {self.dual_tolerance}. Must be non-negative.")
        if self.compl_tolerance < 0.0:
            raise ValueError(f"Invalid complementarity tolerance: {self.compl_tolerance}. Must be non-negative.")
        if not (0.0 <= self.restart_tolerance < 1.0):
            raise ValueError(f"Invalid restart tolerance: {self.restart_tolerance}. Must be in the range [0.0, 1.0).")
        if self.eta <= 0.0:
            raise ValueError(f"Invalid proximal parameter: {self.eta}. Must be greater than zero.")
        if self.rho_0 <= 0.0:
            raise ValueError(f"Invalid initial ALM penalty: {self.rho_0}. Must be greater than zero.")
        if self.rho_min <= 0.0:
            raise ValueError(f"Invalid minimum ALM penalty: {self.rho_min}. Must be greater than zero.")
        if self.a_0 <= 0.0:
            raise ValueError(f"Invalid initial acceleration parameter: {self.a_0}. Must be greater than zero.")
        if self.alpha <= 1.0:
            raise ValueError(f"Invalid penalty threshold: {self.alpha}. Must be greater than one.")
        if self.tau <= 1.0:
            raise ValueError(f"Invalid penalty increment factor: {self.tau}. Must be greater than one.")
        if self.max_iterations <= 0:
            raise ValueError(f"Invalid maximum iterations: {self.max_iterations}. Must be a positive integer.")
        if self.penalty_update_freq < 0:
            raise ValueError(f"Invalid penalty update frequency: {self.penalty_update_freq}. Must be non-negative.")
        if self.linear_solver_tolerance < 0.0:
            raise ValueError(f"Invalid linear solver tolerance: {self.linear_solver_tolerance}. Must be non-negative.")
        if self.linear_solver_tolerance_ratio < 0.0:
            raise ValueError(
                f"Invalid linear solver tolerance ratio: {self.linear_solver_tolerance_ratio}. Must be non-negative."
            )
        if not 0.0 <= self.warmstart_scale <= 1.0:
            raise ValueError(f"Invalid warmstart scale: {self.warmstart_scale}. Must be in the range [0, 1].")

        # Ensure that the enum-valued parameters are valid options
        # Conversion to enum-type configs will raise an error
        # if the corresponding input string is invalid.
        PADMMPenaltyUpdate.from_string(self.penalty_update_method)
        PADMMWarmStartMode.from_string(self.warmstart_mode)
        WarmstarterContacts.Method.from_string(self.contact_warmstart_method)

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()


@dataclass(kw_only=True)
class DVIAPGDConfig:
    """Controls for the APGD unilateral subsolver.

    Select APGD and set these controls before constructing the solver::

        config = newton.solvers.SolverKamino.Config(dynamics_solver="dvi")
        config.dvi.unilateral_solver = "apgd"
        config.dvi.apgd.max_iterations = 64
        config.dvi.apgd.max_nonlinear_corrections = 1
        config.dvi.apgd.tolerance = 1.0e-5
        solver = newton.solvers.SolverKamino(model, config=config)

    Iteration budgets are upper limits. The inner and nonlinear loops stop
    early in each world when their residual meets :attr:`tolerance`.
    The nonlinear correction loop is separate
    from the bilateral/unilateral alternation controlled by
    :attr:`DVISolverConfig.max_alternating_iterations` and
    :attr:`DVISolverConfig.bilateral_solve_interval`. Schur mode eliminates
    bilateral rows during the unilateral solve and recovers their impulses
    afterward.

    These runtime solver controls are Python-only; they do not author a
    material model or add USD schema attributes.
    CUDA execution requires a Warp build and CUDA driver supporting CUDA
    12.4+ conditional graphs. Capture the solve for GPU-only loop control;
    uncaptured CUDA execution reads conditions back to the host.
    """

    max_iterations: int = 64
    """Maximum accepted APGD steps per frozen-correction quadratic solve.

    After an accepted step, the inner loop stops if its frozen-correction
    residual meets :attr:`tolerance`. If the budget is exhausted, the nonlinear
    loop relaxes the partial solution, checks its fresh residual, and starts
    another correction if needed and budget remains.
    """

    max_backtracks: int = 24
    """Maximum trial steps per APGD iteration, including the initial trial.

    The search stops on a finite step satisfying the quadratic curvature test,
    which has a roundoff allowance independent of :attr:`tolerance`. Exhaustion
    or non-finite data sets ``apgd_line_search_failed`` in the terminal status,
    retains the last accepted impulses, and stops all APGD loops for that world.
    """

    max_nonlinear_corrections: int = 1
    """Maximum De Saxce fixed-point iterations per unilateral phase.

    Each iteration freezes the correction for one inner APGD solve. The
    default of one performs a single frozen-correction approximation.
    Increase this budget for tighter nonlinear contact accuracy; increasing
    ``max_iterations`` alone cannot resolve a stale correction. The nonlinear
    loop stops when the fresh residual meets :attr:`tolerance`. Exhaustion
    returns the last accepted, possibly unconverged impulses without raising
    an exception; the residual remains available in the terminal status.
    """

    tolerance: float = 1.0e-5
    """Shared absolute infinity-norm tolerance on inner and nonlinear natural maps.

    The inner map uses the frozen correction; the nonlinear map recomputes
    it at the accepted impulse after relaxation. Both use a unit projection
    step, independent of the APGD step size and contact count. The residual
    type is fixed. Backtracking uses a curvature test instead. Full-system
    status checks use the independent :attr:`DVISolverConfig.tolerance`.
    """

    relaxation: float = 1.0
    """Damping of each De Saxce impulse update, in ``(0, 1]``.

    After each inner solve, blend its output with the impulse at the start of
    the correction before testing the nonlinear residual. This convex
    combination preserves feasibility. A failed line search skips relaxation.
    """

    def validate(self) -> None:
        """Reject non-finite tolerances and invalid nonlinear or inner budgets."""
        for name in ("max_iterations", "max_backtracks", "max_nonlinear_corrections"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"`{name}` must be a positive integer.")
        if isinstance(self.tolerance, bool) or not math.isfinite(self.tolerance) or self.tolerance < 0.0:
            raise ValueError("`tolerance` must be finite and non-negative.")
        if isinstance(self.relaxation, bool) or not math.isfinite(self.relaxation) or not 0.0 < self.relaxation <= 1.0:
            raise ValueError("`relaxation` must be finite and in (0, 1].")

    def __post_init__(self) -> None:
        """Validate constructor arguments."""
        self.validate()


@dataclass
class DVISolverConfig:
    """
    A container to hold configurations for the DVI forward dynamics solver.
    """

    unilateral_solver: Literal["pgs", "apgd"] = field(default="pgs", kw_only=True)
    """Backend for bounded rows, limits, and contacts. Defaults to ``pgs``.

    The ``apgd`` backend uses frozen De Saxce corrections around accelerated
    cone-QP solves. It retains the existing bilateral coupling controls.
    Nonlinear convergence depends on the contact problem and iteration budget.
    """

    apgd: DVIAPGDConfig = field(default_factory=DVIAPGDConfig, kw_only=True)
    """APGD iteration controls; unused by the default PGS backend."""

    tolerance: float = 1e-5
    """
    The convergence tolerance on the projected update size.
    Must be non-negative. Defaults to `1e-5`.
    """

    regularization: float = 1e-6
    """
    Diagonal regularization added to each PGS projected update denominator.
    Unused by APGD, which uses backtracking on the existing dual operator.
    Must be positive. Defaults to `1e-6`.
    """

    omega: float = 1.0
    """
    Relaxation factor applied to projected Gauss-Seidel updates.
    Must be in the range `(0, 2]`. Defaults to `1.0`.
    """

    max_alternating_iterations: int = 24
    """
    Maximum number of outer DVI iterations alternating direct bilateral
    solves with projected inequality solves. Must be greater than zero.
    This schedule is also used when no bilateral constraints are present;
    in that case, the bilateral solve is skipped. APGD uses its own iteration
    budgets when no bilateral rows are present or Schur elimination is enabled.
    Defaults to `24`.
    """

    inequality_sweeps_per_iteration: int = 2
    """
    Number of projected Gauss-Seidel sweeps used for unilateral inequalities
    during each alternating DVI iteration. Contacts use graph-colored sweeps
    on CUDA. Unused by APGD. Must be greater than zero. Defaults to `2`.
    """

    use_schur_complement: bool = False
    """
    Whether to eliminate bilateral rows from the unilateral solve through a Schur complement.

    .. experimental::

        The ``True`` mode may change without prior notice. It requires the same
        setting in every world. PGS adds response-matrix setup and storage;
        APGD applies the response using the factored bilateral operator.

    Defaults to ``False``.
    """

    bilateral_solve_interval: int = 1
    """
    Number of alternating DVI iterations between repeated direct bilateral solves.
    This controls coupling when :attr:`use_schur_complement` is ``False``.
    Larger values trade coupling accuracy for fewer direct solves. Must be greater
    than zero. Defaults to `1`.
    """

    tangential_warmstart_scale: float = 0.97
    """
    Scale applied to cached tangential contact reactions before a DVI solve.
    Normal reactions remain fully warm-started. Must be in the range `[0, 1]`.
    Defaults to `0.97`.
    """

    bilateral_solver_type: Literal["LLTB", "LLTBRCM"] = "LLTB"
    """
    Direct linear solver used for the bilateral constraint block.
    ``LLTBRCM`` can accelerate large sparse articulated systems, while
    ``LLTB`` remains preferable for small or dense systems. Defaults to
    ``LLTB``.
    """

    bilateral_solver_kwargs: dict[str, Any] = field(default_factory=dict)
    """
    Additional keyword arguments passed to the bilateral linear solver.
    Defaults to an empty dictionary.
    """

    warmstart_mode: Literal["none", "internal", "containers"] = "containers"
    """
    Warmstart mode to be used for the DVI solver.
    Uses the same choices as the other dual dynamics solvers. Defaults to `containers`.
    """

    contact_warmstart_method: Literal[
        "key_and_position",
        "geom_pair_net_force",
        "key_and_position_with_net_force_backup",
        "key_and_position_with_tangential_net_force",
        "key_and_position_with_net_force_backup_and_tangential_net_force",
    ] = "key_and_position_with_tangential_net_force"
    """
    The contact warmstart method used when `warmstart_mode` is `containers`.
    See :class:`WarmstarterContacts.Method` for available options.
    Defaults to `key_and_position_with_tangential_net_force`.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """Register DVI custom attributes supported by the Kamino USD schema.

        DVI-specific tuning options are currently Python-only. The shared
        ``max_solver_iterations`` attribute is registered by
        :class:`PADMMSolverConfig` and parsed by both dynamics solvers.
        """

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> DVISolverConfig:
        """Creates a :class:`DVISolverConfig` from model attributes if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        cfg = DVISolverConfig(**kwargs)
        kamino_attrs = getattr(model, "kamino", None)
        if kamino_attrs is not None and hasattr(kamino_attrs, "max_solver_iterations"):
            max_alternating_iterations = int(kamino_attrs.max_solver_iterations.numpy()[0])
            if max_alternating_iterations >= 0:
                cfg.max_alternating_iterations = max_alternating_iterations
        cfg.validate()
        return cfg

    @override
    def validate(self) -> None:
        """Validates the current values held by this config instance."""
        from ._src.solvers.common import WarmStartMode  # noqa: PLC0415
        from ._src.solvers.warmstart import WarmstarterContacts  # noqa: PLC0415

        if self.unilateral_solver not in {"pgs", "apgd"}:
            raise ValueError("`unilateral_solver` must be 'pgs' or 'apgd'.")
        if not isinstance(self.apgd, DVIAPGDConfig):
            raise TypeError("`apgd` must be a DVIAPGDConfig.")
        self.apgd.validate()
        if self.tolerance < 0.0:
            raise ValueError(f"Invalid tolerance: {self.tolerance}. Must be non-negative.")
        if self.regularization <= 0.0:
            raise ValueError(f"Invalid regularization: {self.regularization}. Must be greater than zero.")
        if self.omega <= 0.0 or self.omega > 2.0:
            raise ValueError(f"Invalid omega: {self.omega}. Must be in the range (0, 2].")
        if self.max_alternating_iterations <= 0:
            raise ValueError(
                f"Invalid maximum alternating iterations: {self.max_alternating_iterations}. "
                "Must be a positive integer."
            )
        if self.inequality_sweeps_per_iteration <= 0:
            raise ValueError(
                f"Invalid inequality sweeps per iteration: {self.inequality_sweeps_per_iteration}. "
                "Must be a positive integer."
            )
        if self.bilateral_solve_interval <= 0:
            raise ValueError(
                f"Invalid bilateral solve interval: {self.bilateral_solve_interval}. Must be a positive integer."
            )
        if self.tangential_warmstart_scale < 0.0 or self.tangential_warmstart_scale > 1.0:
            raise ValueError(
                f"Invalid tangential warmstart scale: {self.tangential_warmstart_scale}. Must be in the range [0, 1]."
            )
        if self.bilateral_solver_type not in {"LLTB", "LLTBRCM"}:
            raise ValueError(
                f"Invalid bilateral solver type: {self.bilateral_solver_type}. Must be one of ['LLTB', 'LLTBRCM']."
            )
        WarmStartMode.from_string(self.warmstart_mode)
        WarmstarterContacts.Method.from_string(self.contact_warmstart_method)
        implemented_contact_warmstart_methods = {
            "key_and_position",
            "geom_pair_net_force",
            "key_and_position_with_net_force_backup",
            "key_and_position_with_tangential_net_force",
            "key_and_position_with_net_force_backup_and_tangential_net_force",
        }
        if self.contact_warmstart_method not in implemented_contact_warmstart_methods:
            raise ValueError(
                f"DVI contact warmstart method is not implemented: {self.contact_warmstart_method}. "
                f"Choose one of {sorted(implemented_contact_warmstart_methods)}."
            )

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()


@dataclass
class ForwardKinematicsSolverConfig:
    """
    A container to hold configurations for the Gauss-Newton forward kinematics solver used for state resets.
    """

    tolerance: float = 1e-6
    """
    Maximal absolute kinematic constraint value that is acceptable at the solution.
    This setting can be altered after the solver's construction (but will get baked in captured graphs).
    Defaults to `1e-6`.
    """

    max_newton_iterations: int = 30
    """
    Maximal number of Gauss-Newton iterations.
    This setting can be altered after the solver's construction (but will get baked in captured graphs).
    Defaults to `30`.
    """

    max_line_search_iterations: int = 20
    """
    Maximal line search iterations in the inner loop.
    This setting can be altered after the solver's construction (but will get baked in captured graphs).
    Defaults to `20`.
    """

    reset_state: bool = True
    """
    Whether to reset the state before the FK solve, using the reference state of the system as initial guess.
    If False, the current body poses are used as initial guess, which often leads to faster convergence
    when solving forward kinematics along a trajectory (as opposed to isolated poses).
    This setting can be altered after the solver's construction (but will get baked in captured graphs).
    Defaults to `True`.
    """

    add_axis_joints: bool = True
    """
    Whether to automatically add axis joints to take out superfluous DoFs at tie rods (i.e. bodies
    between two passive spherical or gimbal joints, that may rotate freely about the connecting axis),
    that otherwise render the FK problem ill-posed.
    Defaults to `True`.
    """

    use_incremental_solve: bool = True
    """
    Whether to automatically split large steps in actuator coordinates into smaller steps
    in the FK solve, to improve the solver's robustness for a mild added cost.
    Defaults to `True`.
    """

    max_linear_incremental_step: float = 0.05
    """
    If incremental solve is enabled, maximal allowed step in linear actuator coordinates
    per solver iteration, in meters. A lower value results in more incremental steps.
    Defaults to `0.05`.
    """

    max_angular_incremental_step: float = math.radians(10.0)
    """
    If incremental solve is enabled, maximal allowed step in angular actuator coordinates
    per solver iteration, in radians. A lower value results in more incremental steps.
    Defaults to `math.radians(10.0)`, i.e. 10 degrees.
    """

    use_regularization: bool = False
    """
    Whether to regularize the FK problem by trying to preserve the rigid body poses with a small weight.
    This might result in constraint violations of the order of the regularization weight, but allows to
    tackle systems with solution sub-spaces, in particular underactuated systems.

    Important note: the default tolerance of 1e-6 may not be reachable if regularization is enabled,
    using 1e-5 instead is recommended in most cases.

    For systems that are only underactuated due to tie rods being free to rotate about their own axis,
    enabling `add_axis_joints` is recommended instead.

    Defaults to `False`.
    """

    regularization_weight: float = 1e-5
    """
    Weight applied to the rigid body pose least-squares regularizer, if regularization is enabled.
    This setting can be altered after the solver's construction (but will get baked in captured graphs).
    Defaults to `1e-5`.
    """

    use_sparsity: bool = False
    """
    Whether to use sparse Jacobian and solver; else dense versions are used (recommended for most systems).
    Defaults to `False`.
    """

    preconditioner: Literal["none", "jacobi_diagonal", "jacobi_block_diagonal"] = "jacobi_block_diagonal"
    """
    Preconditioner to use for the Conjugate Gradient solver if sparsity is enabled.
    Defaults to `jacobi_block_diagonal`.
    """

    use_adaptive_cg_tolerance: bool = True
    """
    Whether to use an adaptive tolerance strategy for the Conjugate Gradient solver if sparsity
    is enabled, which reduces the number of CG iterations in most cases.
    This setting can be altered after the solver's construction (but will get baked in captured graphs).
    Defaults to `True`.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for the FK solver configurations with the given builder.

        Note: Currently, this class does not have any custom attributes registered,
        as only those supported by the Kamino USD scene API have been included. More
        will be added in the future as latter is being developed.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        pass  # TODO: Add custom attributes for the FK solver when supported by the Kamino USD scene API

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> ForwardKinematicsSolverConfig:
        """
        Creates a :class:`ForwardKinematicsSolverConfig` by attempting
        to parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        cfg = ForwardKinematicsSolverConfig(**kwargs)

        # TODO: Implement these

        # Return the fully constructed config with configurations
        # parsed from the model's custom attributes if available,
        # otherwise using defaults or provided kwargs.
        return cfg

    @override
    def validate(self) -> None:
        """
        Validates the current values held by the :class:`ForwardKinematicsSolverConfig` instance.
        """
        # Import here to avoid module-level imports and circular dependencies
        from ._src.solvers.fk import ForwardKinematicsSolver  # noqa: PLC0415

        # Ensure that the enum-valued parameters are valid options
        ForwardKinematicsSolver.PreconditionerType.from_string(self.preconditioner)

        # Ensure that the integer and float parameters are within valid ranges
        if self.max_newton_iterations <= 0:
            raise ValueError("`max_newton_iterations` must be positive.")
        if self.max_line_search_iterations <= 0:
            raise ValueError("`max_line_search_iterations` must be positive.")
        if self.tolerance <= 0.0:
            raise ValueError("`tolerance` must be positive.")
        if self.max_linear_incremental_step <= 0.0:
            raise ValueError("`max_linear_incremental_step` must be positive.")
        if self.max_angular_incremental_step <= 0.0:
            raise ValueError("`max_angular_incremental_step` must be positive.")
        if self.regularization_weight < 0.0:
            raise ValueError("`regularization_weight` must be non-negative.")

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()


@dataclass
class MaterialManagerConfig(ConfigBase):
    """
    A container to hold configurations for the internal material manager and material property mixing.
    """

    friction_mix_mode: Literal["average", "multiply", "max", "min", "geometric_average"] = "average"
    """
    The mixing mode to use for friction.\n
    Defaults to `average`.
    """

    restitution_mix_mode: Literal["average", "multiply", "max", "min", "geometric_average"] = "min"
    """
    The mixing mode to use for restitution.\n
    Defaults to `min`.
    """

    @override
    @staticmethod
    def register_custom_attributes(builder: ModelBuilder) -> None:
        """
        Registers custom attributes for the MaterialManagerConfig with the given builder.

        Note: Currently, this class does not have any custom attributes registered,
        as only those supported by the Kamino USD scene API have been included. More
        will be added in the future as latter is being developed.

        Args:
            builder: The model builder instance with which to register the custom attributes.
        """
        pass  # TODO: Add custom attributes for the MaterialManager when supported by the Kamino USD scene API

    @override
    @staticmethod
    def from_model(model: Model, **kwargs: dict[str, Any]) -> MaterialManagerConfig:
        """
        Creates a :class:`MaterialManagerConfig` by attempting to
        parse custom attributes from a :class:`Model` if available.

        Args:
            model: The Newton model from which to parse configurations.
        """
        # Return the fully constructed config with configurations
        # parsed from the model's custom attributes if available,
        # otherwise using defaults or provided kwargs.
        return MaterialManagerConfig(**kwargs)

    @override
    def validate(self) -> None:
        """
        Validates the current values held by the :class:`MaterialManagerConfig` instance.
        """
        # Import here to avoid module-level imports and circular dependencies
        from ._src.core.materials import MaterialMixMode  # noqa: PLC0415

        # Ensure that the enum-valued parameters are valid options
        MaterialMixMode.from_string(self.friction_mix_mode)
        MaterialMixMode.from_string(self.restitution_mix_mode)

    @override
    def __post_init__(self):
        """Post-initialization to validate configurations."""
        self.validate()
