# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""
USD schema resolver infrastructure.

This module defines the base resolver types used to map authored USD schema
attributes onto Newton builder attributes. Public users should import resolver
types from :mod:`newton.usd`.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from enum import IntEnum
from typing import TYPE_CHECKING, Any, ClassVar

from . import utils as usd

if TYPE_CHECKING:
    from pxr import Usd

    from ..sim.builder import ModelBuilder


class PrimType(IntEnum):
    """Enumeration of USD prim types that can be resolved by schema resolvers."""

    SCENE = 0
    """PhysicsScene prim type."""
    JOINT = 1
    """Joint prim type."""
    SHAPE = 2
    """Shape prim type."""
    BODY = 3
    """Body prim type."""
    MATERIAL = 4
    """Material prim type."""
    ACTUATOR = 5
    """Actuator prim type."""
    ARTICULATION = 6
    """Articulation root prim type."""


class SchemaResolver:
    """Base class mapping USD schema attributes to Newton attributes."""

    @dataclass
    class SchemaAttribute:
        """
        Specifies a USD attribute and its transformation function.

        Args:
            name: The name of the USD attribute (or primary attribute when using a getter).
            default: Default USD-authored value from schema, if any.
            usd_value_transformer: Optional function to transform the raw value into the format expected by Newton.
            usd_value_getter: Optional function (prim) -> value used instead of reading a single attribute (e.g. to compute gap from contactOffset - restOffset).
            attribute_names: When set, names used for collect_prim_attrs; otherwise [name] is used.
        """

        name: str
        default: Any | None = None
        usd_value_transformer: Callable[[Any], Any] | None = None
        usd_value_getter: Callable[[Usd.Prim], Any] | None = None
        attribute_names: Sequence[str] = ()

    # mapping is a dictionary for known variables in Newton. Its purpose is to map USD attributes to existing Newton data.
    # PrimType -> Newton variable -> Attribute
    mapping: ClassVar[dict[PrimType, dict[str, SchemaAttribute]]]

    # Name of the schema resolver
    name: ClassVar[str]

    # extra_attr_namespaces is a list of additional USD attribute namespaces in which the schema attributes may be authored.
    extra_attr_namespaces: ClassVar[list[str]] = []

    # deformable_attr_namespaces lists vendor namespaces that carry the deformable
    # material/geometry attributes (parsed as a fallback to the canonical physics:
    # schema). Kept separate from extra_attr_namespaces so generic rigid-body
    # namespaces are never read as deformable attributes.
    deformable_attr_namespaces: ClassVar[list[str]] = []

    def __init__(self) -> None:
        # Precompute the full set of USD attribute names referenced by this resolver's mapping.
        names: set[str] = set()
        try:
            mapping_items = self.mapping.items()
        except AttributeError:
            mapping_items = []
        for _prim_type, var_map in mapping_items:
            try:
                var_items = var_map.items()
            except AttributeError:
                continue
            for _var, spec in var_items:
                if spec.attribute_names:
                    names.update(spec.attribute_names)
                else:
                    names.add(spec.name)
        self._solver_attributes = frozenset(names)

    def get_value(self, prim: Usd.Prim, prim_type: PrimType, key: str) -> Any | None:
        """Get an authored value for a resolver key.

        Args:
            prim: USD prim to query.
            prim_type: Prim type category.
            key: Logical Newton attribute key within the prim category.

        Returns:
            Resolved authored value, or ``None`` when not found.
        """
        if prim is None:
            return None
        spec = self.mapping.get(prim_type, {}).get(key)
        if spec is not None:
            if spec.usd_value_getter is not None:
                v = spec.usd_value_getter(prim)
            else:
                v = usd.get_attribute(prim, spec.name)
            if v is not None:
                return spec.usd_value_transformer(v) if spec.usd_value_transformer is not None else v
        return None

    def collect_prim_attrs(self, prim: Usd.Prim) -> dict[str, Any]:
        """Collect all resolver-relevant attributes for a prim.

        Args:
            prim: USD prim to inspect.

        Returns:
            Dictionary mapping authored USD attribute names to values.
        """
        if prim is None:
            return {}

        # Prims author only a small subset of the attributes supported by a resolver.
        # Traverse that subset once instead of querying every possible schema name.
        prefixes = tuple(
            ns + ":" if ns and not ns.endswith(":") else ns for ns in (self.name, *self.extra_attr_namespaces)
        )
        out: dict[str, Any] = {}
        for attr in prim.GetAuthoredAttributes():
            name = attr.GetName()
            in_namespace = name.startswith(prefixes)
            if (in_namespace or name in self._solver_attributes) and attr.HasAuthoredValue():
                value = attr.Get()
                # Namespaced time-sampled attributes retain their missing default value.
                if value is not None or in_namespace:
                    out[name] = value
        return out

    def validate_custom_attributes(self, builder: ModelBuilder) -> None:
        """
        Validate that solver-specific custom attributes are registered on the builder.

        Override in subclasses to check that required custom attributes have been
        registered before parsing. Called by parse_usd() before processing entities.

        Args:
            builder: The ModelBuilder to validate custom attributes on.
        """
        del builder


# Backward-compatible alias; prefer SchemaResolver.SchemaAttribute.
SchemaAttribute = SchemaResolver.SchemaAttribute


class SchemaResolverManager:
    """
    Manager for resolving multiple USD schemas in a priority order.
    """

    def __init__(self, resolvers: Sequence[SchemaResolver]):
        """
        Initialize resolver manager with resolver instances in priority order.

        Args:
            resolvers: List of instantiated resolvers in priority order.
        """
        # Use provided resolver instances directly
        self.resolvers = list(resolvers)

        # Dictionary to accumulate schema attributes as prims are encountered
        # Pre-initialize maps for each configured resolver
        self._schema_attrs: dict[str, dict[str, dict[str, Any]]] = {r.name: {} for r in self.resolvers}

    def _collect_on_first_use(self, resolver: SchemaResolver, prim: Usd.Prim) -> None:
        """Collect and store attributes for this resolver/prim on first use."""
        if prim is None:
            return
        prim_path = str(prim.GetPath())
        if prim_path in self._schema_attrs[resolver.name]:
            return
        self._schema_attrs[resolver.name][prim_path] = resolver.collect_prim_attrs(prim)

    def get_value(
        self, prim: Usd.Prim, prim_type: PrimType, key: str, default: Any = None, verbose: bool = False
    ) -> Any:
        """
        Resolve value using schema priority, with layered fallbacks:

        1) First authored value found in resolver order (highest priority first)
        2) If none authored, use the provided 'default' argument if not None
        3) If no default provided, use the first non-None mapping default from resolvers in priority order
        4) If no mapping default found, return None

        Args:
            prim: USD prim to query (for scene prim_type, this should be scene_prim)
            prim_type: Prim type (PrimType enum)
            key: Attribute key within the prim type
            default: Default value if not found

        Returns:
            Resolved value according to the precedence above.
        """
        value, _ = self.get_value_with_resolver(prim, prim_type, key, default, verbose)
        return value

    def get_value_with_resolver(
        self, prim: Usd.Prim, prim_type: PrimType, key: str, default: Any = None, verbose: bool = False
    ) -> tuple[Any, SchemaResolver | None]:
        """Resolve a value and return the resolver that supplied an authored value."""
        # 1) Authored value by schema priority
        for r in self.resolvers:
            val = r.get_value(prim, prim_type, key)
            if val is None:
                continue
            self._collect_on_first_use(r, prim)
            return val, r

        # 2) Caller-provided default, if any
        if default is not None:
            return default, None

        # 3) Resolver mapping defaults in priority order
        for resolver in self.resolvers:
            spec = resolver.mapping.get(prim_type, {}).get(key) if hasattr(resolver, "mapping") else None
            if spec is not None:
                d = getattr(spec, "default", None)
                if d is not None:
                    transformer = getattr(spec, "usd_value_transformer", None)
                    return (transformer(d) if transformer is not None else d), None

        # Nothing found
        try:
            prim_path = str(prim.GetPath()) if prim is not None else "<None>"
        except (AttributeError, RuntimeError):
            prim_path = "<invalid>"
        if verbose:
            error_message = (
                f"Error: Cannot resolve value for '{prim_type.name.lower()}:{key}' on prim '{prim_path}'; "
                + "no authored value, no explicit default, and no solver mapping default."
            )
            print(error_message)
        return None, None

    def deformable_compat_namespaces(self) -> list[str]:
        """Deformable vendor attribute namespaces declared by the active resolvers.

        Returns the union of every resolver's ``deformable_attr_namespaces``, in
        resolver priority order. Used to accept deformable material/geometry
        attributes authored under vendor namespaces (e.g. ``omniphysics:``,
        ``physxDeformableBody:``) as a fallback to the canonical ``physics:``
        schema. This is deliberately separate from the generic
        ``extra_attr_namespaces`` so unrelated namespaces (``physxScene``,
        ``drive``, ``state``, ...) are never read as deformable schema attributes.
        Empty by default, so a default import reads only the canonical schema.
        """
        seen: set[str] = set()
        namespaces: list[str] = []
        for r in self.resolvers:
            for ns in r.deformable_attr_namespaces:
                if ns not in seen:
                    seen.add(ns)
                    namespaces.append(ns)
        return namespaces

    def read_deformable_attr(self, prim: Usd.Prim, name: str) -> Any:
        """Read a deformable physics attribute: canonical ``physics:`` first, then the
        resolver-declared vendor namespaces. The first authored value, or ``None``."""
        return usd._read_physics_attr(prim, name, self.deformable_compat_namespaces())

    def collect_prim_attrs(self, prim: Usd.Prim) -> None:
        """
        Collect and accumulate schema attributes for a single prim.

        Args:
            prim: USD prim to collect attributes from
        """
        if prim is None:
            return

        prim_path = str(prim.GetPath())

        for resolver in self.resolvers:
            # only collect if we haven't seen this prim for this resolver
            if prim_path not in self._schema_attrs[resolver.name]:
                self._schema_attrs[resolver.name][prim_path] = resolver.collect_prim_attrs(prim)

    @property
    def schema_attrs(self) -> dict[str, dict[str, dict[str, Any]]]:
        """
        Get the accumulated attributes.

        Returns:
            Dictionary with structure: schema_name -> prim_path -> {attr_name: attr_value}
            e.g., {"mjc": {"/World/Cube": {"mjc:option:timestep": 0.01}}}
        """
        return self._schema_attrs
