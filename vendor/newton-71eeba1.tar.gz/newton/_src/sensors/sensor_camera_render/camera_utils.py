# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import math
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, TypeAlias

import warp as wp

if TYPE_CHECKING:
    from pxr import Usd, UsdGeom

    UsdCameraLike: TypeAlias = Usd.Prim | UsdGeom.Camera
    UsdTime: TypeAlias = Usd.TimeCode | float
else:
    UsdCameraLike: TypeAlias = Any
    UsdTime: TypeAlias = Any

UsdCameraInput: TypeAlias = UsdCameraLike
UsdCameraSequenceInput: TypeAlias = UsdCameraInput | Sequence[UsdCameraInput]


def _is_camera_sequence(cameras: Any) -> bool:
    return isinstance(cameras, Sequence) and not isinstance(cameras, (str, bytes, bytearray))


def _coerce_usd_time(time: Any) -> Any:
    try:
        from pxr import Usd
    except ImportError as e:
        raise ImportError("USD camera ray helpers require the pxr USD Python modules.") from e

    if time is None:
        return Usd.TimeCode.Default()
    if isinstance(time, Usd.TimeCode):
        return time
    return Usd.TimeCode(float(time))


def _normalize_usd_camera(camera: UsdCameraInput) -> Any:
    try:
        from pxr import Usd, UsdGeom
    except ImportError as e:
        raise ImportError("USD camera ray helpers require the pxr USD Python modules.") from e

    if isinstance(camera, UsdGeom.Camera):
        usd_camera = camera
        prim = usd_camera.GetPrim()
    elif isinstance(camera, Usd.Prim):
        prim = camera
        if not prim.IsValid():
            raise TypeError("Expected a valid UsdGeom.Camera prim.")
        usd_camera = UsdGeom.Camera(prim)
    else:
        raise TypeError("Expected a single UsdGeom.Camera or Usd.Prim.")

    if not prim.IsValid():
        raise TypeError("Expected a valid UsdGeom.Camera prim.")
    if not prim.IsA(UsdGeom.Camera):
        raise TypeError(f"Expected a UsdGeom.Camera prim, got {prim.GetPath()!r}.")
    return usd_camera


def compute_camera_rays_pinhole_usd(
    width: int,
    height: int,
    camera: UsdCameraInput,
    *,
    device: wp.Device,
    time: UsdTime | None = None,
    sample_count: int = 1,
    out_rays: wp.array4d[wp.vec3f],
) -> wp.array4d[wp.vec3f]:
    time_code = _coerce_usd_time(time)
    usd_camera = _normalize_usd_camera(camera)
    projection = str(usd_camera.GetProjectionAttr().Get(time_code))
    if projection != "perspective":
        prim = usd_camera.GetPrim()
        raise NotImplementedError(f"USD camera {prim.GetPath()} uses unsupported projection {projection!r}.")

    wp.launch(
        kernel=compute_camera_rays_pinhole_from_aperture_kernel,
        dim=(height, width, sample_count),
        inputs=[
            width,
            height,
            float(usd_camera.GetFocalLengthAttr().Get(time_code)),
            float(usd_camera.GetHorizontalApertureAttr().Get(time_code)),
            float(usd_camera.GetVerticalApertureAttr().Get(time_code)),
            float(usd_camera.GetHorizontalApertureOffsetAttr().Get(time_code)),
            float(usd_camera.GetVerticalApertureOffsetAttr().Get(time_code)),
            sample_count,
            out_rays,
        ],
        device=device,
    )

    return out_rays


def compute_camera_transforms_usd(
    cameras: UsdCameraSequenceInput,
    *,
    device: wp.Device,
    target_up_axis: Any | None = None,
    time: UsdTime | None = None,
    xform: Any | None = None,
) -> wp.array[wp.transformf]:
    """Read world-space camera transforms from one USD camera per view.

    Returns a ``(view_count,)`` array of ``transformf``, converting each camera
    pose from its stage up axis to *target_up_axis* and composing an optional
    scene *xform*.
    """
    try:
        from pxr import UsdGeom
    except ImportError as e:
        raise ImportError("USD camera ray helpers require the pxr USD Python modules.") from e

    from ...core import Axis, quat_between_axes  # noqa: PLC0415
    from ...usd.utils import get_transform  # noqa: PLC0415

    camera_items = list(cameras) if _is_camera_sequence(cameras) else [cameras]
    if not camera_items:
        raise ValueError("At least one USD camera is required.")
    usd_cameras = [_normalize_usd_camera(camera) for camera in camera_items]

    time_code = _coerce_usd_time(time)
    xform_cache = UsdGeom.XformCache(time_code)
    scene_xform = wp.transform(*xform) if xform is not None else None

    transforms = []
    for usd_camera in usd_cameras:
        prim = usd_camera.GetPrim()
        transform = get_transform(prim, local=False, xform_cache=xform_cache)
        if target_up_axis is not None:
            stage_up_axis = Axis.from_string(str(UsdGeom.GetStageUpAxis(prim.GetStage())))
            axis_xform = wp.transform(wp.vec3(0.0), quat_between_axes(stage_up_axis, target_up_axis))
            transform = axis_xform * transform
        if scene_xform is not None:
            transform = scene_xform * transform
        transforms.append(transform)

    return wp.array(transforms, dtype=wp.transformf, device=device)


@wp.func
def _opencv_fisheye_radius(theta: wp.float32, k0: wp.float32, k1: wp.float32, k2: wp.float32, k3: wp.float32):
    theta2 = theta * theta
    theta4 = theta2 * theta2
    theta6 = theta4 * theta2
    theta8 = theta4 * theta4
    return theta * (1.0 + k0 * theta2 + k1 * theta4 + k2 * theta6 + k3 * theta8)


@wp.func
def _ftheta_radius(
    theta: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
):
    theta2 = theta * theta
    theta3 = theta2 * theta
    theta4 = theta2 * theta2
    return k0 + k1 * theta + k2 * theta2 + k3 * theta3 + k4 * theta4


@wp.func
def _kannala_brandt_k3_radius(
    theta: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
):
    theta2 = theta * theta
    theta3 = theta2 * theta
    theta5 = theta3 * theta2
    theta7 = theta5 * theta2
    return k0 * theta + k1 * theta3 + k2 * theta5 + k3 * theta7


@wp.func
def _solve_opencv_fisheye_theta(
    radius: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    max_theta: wp.float32,
):
    if radius <= 1.0e-7:
        return wp.float32(0.0)

    # This endpoint check and the binary search assume r(theta) is monotonic.
    max_radius = _opencv_fisheye_radius(max_theta, k0, k1, k2, k3)
    if radius > max_radius + 1.0e-5:
        return wp.float32(-1.0)

    lo = wp.float32(0.0)
    hi = max_theta
    for _i in range(24):
        mid = (lo + hi) * 0.5
        if _opencv_fisheye_radius(mid, k0, k1, k2, k3) < radius:
            lo = mid
        else:
            hi = mid
    return (lo + hi) * 0.5


@wp.func
def _solve_ftheta_theta(
    radius: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
    max_theta: wp.float32,
):
    if radius <= 1.0e-7:
        return wp.float32(0.0)

    # When k0 != 0 the polynomial has a nonzero floor at theta=0 (r(0) = k0).
    # Pixels inside that central circle are undefined by the model; return theta=0 (forward).
    min_radius = _ftheta_radius(0.0, k0, k1, k2, k3, k4)
    if radius <= min_radius:
        return wp.float32(0.0)

    # This endpoint check and the binary search assume r(theta) is monotonic.
    max_radius = _ftheta_radius(max_theta, k0, k1, k2, k3, k4)
    if radius > max_radius + 1.0e-5:
        return wp.float32(-1.0)

    lo = wp.float32(0.0)
    hi = max_theta
    for _i in range(24):
        mid = (lo + hi) * 0.5
        if _ftheta_radius(mid, k0, k1, k2, k3, k4) < radius:
            lo = mid
        else:
            hi = mid
    return (lo + hi) * 0.5


@wp.func
def _solve_kannala_brandt_k3_theta(
    radius: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    max_theta: wp.float32,
):
    if radius <= 1.0e-7:
        return wp.float32(0.0)

    # This endpoint check and the binary search assume r(theta) is monotonic.
    max_radius = _kannala_brandt_k3_radius(max_theta, k0, k1, k2, k3)
    if radius > max_radius + 1.0e-5:
        return wp.float32(-1.0)

    lo = wp.float32(0.0)
    hi = max_theta
    for _i in range(24):
        mid = (lo + hi) * 0.5
        if _kannala_brandt_k3_radius(mid, k0, k1, k2, k3) < radius:
            lo = mid
        else:
            hi = mid
    return (lo + hi) * 0.5


@wp.func
def _fisheye_direction_from_theta(x: wp.float32, y: wp.float32, radius: wp.float32, theta: wp.float32):
    # Valid fisheye rays are unit-length by construction; zero is reserved for invalid rays.
    if theta < 0.0:
        return wp.vec3f(0.0)
    if radius <= 1.0e-7:
        return wp.vec3f(0.0, 0.0, -1.0)

    sin_theta = wp.sin(theta)
    return wp.vec3f((x / radius) * sin_theta, (y / radius) * sin_theta, -wp.cos(theta))


@wp.func
def _multisample_offset(sample_index: int, sample_count: int):
    if sample_count <= 1:
        return wp.vec2f(0.5, 0.5)

    # Two distinct samples cannot include the center and retain a centered mean.
    if sample_count == 2:
        v = wp.mod(0.5 * 0.61803398875, 1.0)
        if sample_index == 1:
            return wp.vec2f(0.75, 1.0 - v)
        return wp.vec2f(0.25, v)

    if sample_index == 0:
        return wp.vec2f(0.5, 0.5)

    # Equally spaced points on a ring have a centered mean for any ring size.
    angle = 0.7853981633974483 + 6.283185307179586 * float(sample_index - 1) / float(sample_count - 1)
    radius = 0.42
    return wp.vec2f(0.5 + radius * wp.cos(angle), 0.5 + radius * wp.sin(angle))


@wp.kernel(enable_backward=False)
def compute_camera_rays_pinhole(
    width: int,
    height: int,
    camera_fov: wp.float32,
    sample_count: int,
    out_rays: wp.array4d[wp.vec3f],
):
    py, px, sample_index = wp.tid()
    offset = _multisample_offset(sample_index, sample_count)
    aspect_ratio = float(width) / float(height)
    u = (float(px) + offset[0]) / float(width) - 0.5
    v = (float(py) + offset[1]) / float(height) - 0.5
    h = wp.tan(camera_fov / 2.0)
    ray_direction_camera_space = wp.vec3f(u * 2.0 * h * aspect_ratio, -v * 2.0 * h, -1.0)
    out_rays[py, px, sample_index, 0] = wp.vec3f(0.0)
    out_rays[py, px, sample_index, 1] = wp.normalize(ray_direction_camera_space)


@wp.kernel(enable_backward=False)
def compute_camera_rays_pinhole_from_aperture_kernel(
    width: int,
    height: int,
    focal_length: wp.float32,
    horizontal_aperture: wp.float32,
    vertical_aperture: wp.float32,
    horizontal_aperture_offset: wp.float32,
    vertical_aperture_offset: wp.float32,
    sample_count: int,
    out_rays: wp.array4d[wp.vec3f],
):
    py, px, sample_index = wp.tid()
    offset = _multisample_offset(sample_index, sample_count)
    u = (float(px) + offset[0]) / float(width)
    v = (float(py) + offset[1]) / float(height)
    film_x = (u - 0.5) * horizontal_aperture + horizontal_aperture_offset
    film_y = (0.5 - v) * vertical_aperture + vertical_aperture_offset
    ray_direction_camera_space = wp.vec3f(film_x / focal_length, film_y / focal_length, -1.0)
    out_rays[py, px, sample_index, 0] = wp.vec3f(0.0)
    out_rays[py, px, sample_index, 1] = wp.normalize(ray_direction_camera_space)


_PINHOLE_OPENCV_INVERSION_ITERATIONS = 10
_PINHOLE_OPENCV_LINE_SEARCH_ITERATIONS = 6
# Residuals are in normalized image coordinates; convergence ~1e-6, acceptance ~2e-5 RMS.
_PINHOLE_OPENCV_CONVERGENCE_TOLERANCE_SQUARED = 1.0e-12
_PINHOLE_OPENCV_ACCEPTANCE_TOLERANCE_SQUARED = 4.0e-10
_PINHOLE_OPENCV_SOLVER_EPSILON = 1.0e-8


@wp.func
def _distort_pinhole_opencv(
    x: wp.float32,
    y: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
    k5: wp.float32,
    k6: wp.float32,
    p1: wp.float32,
    p2: wp.float32,
    s1: wp.float32,
    s2: wp.float32,
    s3: wp.float32,
    s4: wp.float32,
) -> wp.vec2f:
    radius_squared = x * x + y * y
    radius_fourth = radius_squared * radius_squared
    radius_sixth = radius_fourth * radius_squared
    radial = (1.0 + k1 * radius_squared + k2 * radius_fourth + k3 * radius_sixth) / (
        1.0 + k4 * radius_squared + k5 * radius_fourth + k6 * radius_sixth
    )
    tangential_prism_x = (
        2.0 * p1 * x * y + p2 * (radius_squared + 2.0 * x * x) + s1 * radius_squared + s2 * radius_fourth
    )
    tangential_prism_y = (
        p1 * (radius_squared + 2.0 * y * y) + 2.0 * p2 * x * y + s3 * radius_squared + s4 * radius_fourth
    )
    return wp.vec2f(x * radial + tangential_prism_x, y * radial + tangential_prism_y)


@wp.func
def _invert_pinhole_opencv(
    x_distorted: wp.float32,
    y_distorted: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
    k5: wp.float32,
    k6: wp.float32,
    p1: wp.float32,
    p2: wp.float32,
    s1: wp.float32,
    s2: wp.float32,
    s3: wp.float32,
    s4: wp.float32,
) -> wp.vec3f:
    # Damped Newton inversion; unverifiable pixels return the zero sentinel.
    x = x_distorted
    y = y_distorted
    valid = True
    done = False
    for _ in range(_PINHOLE_OPENCV_INVERSION_ITERATIONS):
        if valid and not done:
            distorted = _distort_pinhole_opencv(x, y, k1, k2, k3, k4, k5, k6, p1, p2, s1, s2, s3, s4)
            residual_x = distorted[0] - x_distorted
            residual_y = distorted[1] - y_distorted
            residual_squared = residual_x * residual_x + residual_y * residual_y

            if not wp.isfinite(residual_squared):
                valid = False
            elif residual_squared <= _PINHOLE_OPENCV_CONVERGENCE_TOLERANCE_SQUARED:
                done = True
            else:
                radius_squared = x * x + y * y
                radius_fourth = radius_squared * radius_squared
                radius_sixth = radius_fourth * radius_squared
                numerator = 1.0 + k1 * radius_squared + k2 * radius_fourth + k3 * radius_sixth
                denominator = 1.0 + k4 * radius_squared + k5 * radius_fourth + k6 * radius_sixth

                if wp.abs(denominator) <= _PINHOLE_OPENCV_SOLVER_EPSILON:
                    valid = False
                else:
                    radial = numerator / denominator
                    numerator_derivative = k1 + 2.0 * k2 * radius_squared + 3.0 * k3 * radius_fourth
                    denominator_derivative = k4 + 2.0 * k5 * radius_squared + 3.0 * k6 * radius_fourth
                    radial_derivative = (numerator_derivative * denominator - numerator * denominator_derivative) / (
                        denominator * denominator
                    )
                    radial_derivative_x = 2.0 * x * radial_derivative
                    radial_derivative_y = 2.0 * y * radial_derivative

                    jacobian_00 = (
                        radial
                        + x * radial_derivative_x
                        + 2.0 * p1 * y
                        + 6.0 * p2 * x
                        + 2.0 * s1 * x
                        + 4.0 * s2 * radius_squared * x
                    )
                    jacobian_01 = (
                        x * radial_derivative_y
                        + 2.0 * p1 * x
                        + 2.0 * p2 * y
                        + 2.0 * s1 * y
                        + 4.0 * s2 * radius_squared * y
                    )
                    jacobian_10 = (
                        y * radial_derivative_x
                        + 2.0 * p1 * x
                        + 2.0 * p2 * y
                        + 2.0 * s3 * x
                        + 4.0 * s4 * radius_squared * x
                    )
                    jacobian_11 = (
                        radial
                        + y * radial_derivative_y
                        + 6.0 * p1 * y
                        + 2.0 * p2 * x
                        + 2.0 * s3 * y
                        + 4.0 * s4 * radius_squared * y
                    )
                    determinant = jacobian_00 * jacobian_11 - jacobian_01 * jacobian_10

                    if not wp.isfinite(determinant) or wp.abs(determinant) <= _PINHOLE_OPENCV_SOLVER_EPSILON:
                        valid = False
                    else:
                        delta_x = (jacobian_11 * residual_x - jacobian_01 * residual_y) / determinant
                        delta_y = (jacobian_00 * residual_y - jacobian_10 * residual_x) / determinant
                        if not wp.isfinite(delta_x) or not wp.isfinite(delta_y):
                            valid = False
                        else:
                            base_x = x
                            base_y = y
                            step = 1.0
                            accepted = False
                            for _line_search_iteration in range(_PINHOLE_OPENCV_LINE_SEARCH_ITERATIONS):
                                candidate_x = base_x - step * delta_x
                                candidate_y = base_y - step * delta_y
                                candidate_distorted = _distort_pinhole_opencv(
                                    candidate_x,
                                    candidate_y,
                                    k1,
                                    k2,
                                    k3,
                                    k4,
                                    k5,
                                    k6,
                                    p1,
                                    p2,
                                    s1,
                                    s2,
                                    s3,
                                    s4,
                                )
                                candidate_residual_x = candidate_distorted[0] - x_distorted
                                candidate_residual_y = candidate_distorted[1] - y_distorted
                                candidate_residual_squared = (
                                    candidate_residual_x * candidate_residual_x
                                    + candidate_residual_y * candidate_residual_y
                                )
                                if (
                                    not accepted
                                    and wp.isfinite(candidate_residual_squared)
                                    and candidate_residual_squared < residual_squared
                                ):
                                    x = candidate_x
                                    y = candidate_y
                                    accepted = True
                                step *= 0.5
                            # Stalled: no step reduced the residual; stop iterating.
                            if not accepted:
                                done = True

    # Accept only if the forward model reproduces the target within tolerance.
    if valid:
        distorted = _distort_pinhole_opencv(x, y, k1, k2, k3, k4, k5, k6, p1, p2, s1, s2, s3, s4)
        residual_x = distorted[0] - x_distorted
        residual_y = distorted[1] - y_distorted
        residual_squared = residual_x * residual_x + residual_y * residual_y
        valid = wp.isfinite(residual_squared) and residual_squared <= _PINHOLE_OPENCV_ACCEPTANCE_TOLERANCE_SQUARED

    if valid:
        return wp.normalize(wp.vec3f(x, -y, -1.0))
    return wp.vec3f(0.0)


@wp.kernel(enable_backward=False)
def compute_camera_rays_pinhole_opencv_kernel(
    width: int,
    height: int,
    image_width: wp.float32,
    image_height: wp.float32,
    fx: wp.float32,
    fy: wp.float32,
    cx: wp.float32,
    cy: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
    k5: wp.float32,
    k6: wp.float32,
    p1: wp.float32,
    p2: wp.float32,
    s1: wp.float32,
    s2: wp.float32,
    s3: wp.float32,
    s4: wp.float32,
    sample_count: int,
    out_rays: wp.array4d[wp.vec3f],
):
    py, px, sample_index = wp.tid()
    offset = _multisample_offset(sample_index, sample_count)
    u = ((float(px) + offset[0]) / float(width)) * image_width
    v = ((float(py) + offset[1]) / float(height)) * image_height
    x_distorted = (u - cx) / fx
    y_distorted = (v - cy) / fy

    ray_direction_camera_space = _invert_pinhole_opencv(
        x_distorted, y_distorted, k1, k2, k3, k4, k5, k6, p1, p2, s1, s2, s3, s4
    )

    out_rays[py, px, sample_index, 0] = wp.vec3f(0.0)
    out_rays[py, px, sample_index, 1] = ray_direction_camera_space


@wp.kernel(enable_backward=False)
def compute_camera_rays_fisheye_opencv_kernel(
    width: int,
    height: int,
    image_width: wp.float32,
    image_height: wp.float32,
    fx: wp.float32,
    fy: wp.float32,
    cx: wp.float32,
    cy: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
    max_fov: wp.float32,
    sample_count: int,
    out_rays: wp.array4d[wp.vec3f],
):
    py, px, sample_index = wp.tid()
    offset = _multisample_offset(sample_index, sample_count)
    u = ((float(px) + offset[0]) / float(width)) * image_width
    v = ((float(py) + offset[1]) / float(height)) * image_height
    x = (u - cx) / fx
    y = -(v - cy) / fy
    radius = wp.sqrt(x * x + y * y)
    theta = _solve_opencv_fisheye_theta(
        radius,
        k1,
        k2,
        k3,
        k4,
        wp.min(max_fov * wp.float32(0.5), wp.float32(math.pi)),
    )
    ray_direction_camera_space = _fisheye_direction_from_theta(x, y, radius, theta)

    out_rays[py, px, sample_index, 0] = wp.vec3f(0.0)
    out_rays[py, px, sample_index, 1] = ray_direction_camera_space


@wp.kernel(enable_backward=False)
def compute_camera_rays_fisheye_ftheta_kernel(
    width: int,
    height: int,
    nominal_width: wp.float32,
    nominal_height: wp.float32,
    optical_center_x: wp.float32,
    optical_center_y: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    k4: wp.float32,
    max_fov: wp.float32,
    sample_count: int,
    out_rays: wp.array4d[wp.vec3f],
):
    py, px, sample_index = wp.tid()
    offset = _multisample_offset(sample_index, sample_count)
    u = ((float(px) + offset[0]) / float(width)) * nominal_width
    v = ((float(py) + offset[1]) / float(height)) * nominal_height
    x = u - optical_center_x
    y = -(v - optical_center_y)
    radius = wp.sqrt(x * x + y * y)
    max_theta = wp.min(max_fov * 0.5, wp.float32(math.pi))
    theta = _solve_ftheta_theta(
        radius,
        k0,
        k1,
        k2,
        k3,
        k4,
        max_theta,
    )
    ray_direction_camera_space = _fisheye_direction_from_theta(x, y, radius, theta)

    out_rays[py, px, sample_index, 0] = wp.vec3f(0.0)
    out_rays[py, px, sample_index, 1] = ray_direction_camera_space


@wp.kernel(enable_backward=False)
def compute_camera_rays_fisheye_kannala_brandt_kernel(
    width: int,
    height: int,
    nominal_width: wp.float32,
    nominal_height: wp.float32,
    optical_center_x: wp.float32,
    optical_center_y: wp.float32,
    k0: wp.float32,
    k1: wp.float32,
    k2: wp.float32,
    k3: wp.float32,
    max_fov: wp.float32,
    sample_count: int,
    out_rays: wp.array4d[wp.vec3f],
):
    py, px, sample_index = wp.tid()
    offset = _multisample_offset(sample_index, sample_count)
    u = ((float(px) + offset[0]) / float(width)) * nominal_width
    v = ((float(py) + offset[1]) / float(height)) * nominal_height
    x = u - optical_center_x
    y = -(v - optical_center_y)
    radius = wp.sqrt(x * x + y * y)
    max_theta = wp.min(max_fov * 0.5, wp.float32(math.pi))
    theta = _solve_kannala_brandt_k3_theta(
        radius,
        k0,
        k1,
        k2,
        k3,
        max_theta,
    )
    ray_direction_camera_space = _fisheye_direction_from_theta(x, y, radius, theta)

    out_rays[py, px, sample_index, 0] = wp.vec3f(0.0)
    out_rays[py, px, sample_index, 1] = ray_direction_camera_space
