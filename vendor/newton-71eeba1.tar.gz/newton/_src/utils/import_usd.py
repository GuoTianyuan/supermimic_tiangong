# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import copy
import itertools
import logging
import math
import re
import warnings
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from pxr import Usd

    from ..geometry.types import TetMesh

    UsdStage = Usd.Stage
else:
    UsdStage = Any

import numpy as np
import warp as wp

from ..core import quat_between_axes
from ..core._warnings import _external_warning_stacklevel
from ..core.types import Axis, Transform
from ..geometry import Mesh, ShapeFlags, compute_inertia_sphere
from ..sim.builder import ModelBuilder
from ..sim.enums import JointTargetMode, JointType
from ..sim.model import Model
from ..solvers.mujoco.enums import EqType, _ActuatorBiasType, _ActuatorDynamicsType, _ActuatorGainType
from ..solvers.mujoco.equality import _add_equality_constraint, _register_equality_constraint_attributes
from ..solvers.mujoco.utils import (
    mjc_add_equality_loop_joint,
    mjc_add_equality_mimic,
    mjc_polycoef_has_higher_order,
)
from ..usd import require_newton_usd_schemas
from ..usd import utils as usd
from ..usd._asset_download import resolve_usd_from_url  # noqa: F401
from ..usd._resolution_policy import (
    _PhysicsMaterial,
    _resolve_physics_material,
    _UsdJointProperties,
)
from ..usd.particles import find_particle_prims, import_particles
from ..usd.schema_resolver import PrimType, SchemaResolver, SchemaResolverManager
from ..usd.schemas import SchemaResolverNewton
from .color import color_linear_to_srgb
from .import_usd_deformable_attachments import (
    _deformable_import_attachments,
    _deformable_import_element_collision_filters,
    _deformable_remap_collapsed,
)
from .import_usd_deformable_cable import (
    _deformable_import_cable,
    _deformable_prepare_cable_topology,
    _read_cable_articulation_root,
    _read_cable_attachment_endpoint,
)
from .import_usd_deformable_cloth import _deformable_import_cloth
from .import_usd_deformable_utils import (
    _LOADABLE_VISUAL_TYPE_NAMES_LOWER,
    _DeformableImportContext,
    _scout_deformable_prims,
)
from .import_usd_deformable_volume import _deformable_import_volume

logger = logging.getLogger("newton")

AttributeFrequency = Model.AttributeFrequency


# `UsdPreviewSurface`'s schema default for `diffuseColor`. A visual shape whose prim binds no
# material is given this rather than left for ModelBuilder's per-shape debug palette, which
# would render an unmaterialed scene in colours the asset never authored. Display-encoded to
# match the colours that are resolved from a material.
_UNMATERIALED_VISUAL_COLOR = color_linear_to_srgb((0.18, 0.18, 0.18))


def _is_uniform_scale(scale, rel_tol: float = 1.0e-6) -> bool:
    """Whether the three components of a scale vector agree to within ``rel_tol``.

    Scales reach the importer through single-precision transform decomposition, so an
    exactly uniform scale routinely comes back with components a few ULP apart. An exact
    ``==`` comparison reports those as non-uniform.
    """
    lo, hi = min(scale), max(scale)
    return hi - lo <= rel_tol * max(abs(lo), abs(hi))


def _warn_mirrored_body_transform(usd_prim, key: str, xform_cache) -> None:
    """Warn when a rigid body prim has an improper (mirrored) world transform.

    Improper transforms (negative determinant) have no unique rotation
    decomposition: the USD physics parser's ``rotation`` and
    ``usd.get_transform()`` may absorb the reflection on different axes, and
    their disagreement becomes a spurious constant rotation injected into the
    imported body and joint frames via the incoming-xform rebase.

    Args:
        usd_prim: The rigid body ``Usd.Prim``.
        key: Prim path string used in the warning message.
        xform_cache: ``UsdGeom.XformCache`` for world transform lookup.
    """
    if xform_cache.GetLocalToWorldTransform(usd_prim).GetDeterminant() < 0.0:
        warnings.warn(
            f"Rigid body prim {key} has a mirrored (negative-determinant) "
            "world transform. Imported body and joint frames may acquire a "
            "spurious rotation. Bake the reflection into the mesh geometry "
            "(negate vertices, flip triangle winding) and re-author the body "
            "with a proper transform before import.",
            stacklevel=_external_warning_stacklevel(),
        )


@dataclass(frozen=True, slots=True)
class _CableAttachmentCandidate:
    """Cable endpoint and rigid target that may share an articulation."""

    cable_prim: Any
    attachment_prim: Any
    point_count: int
    closed: bool
    target_path: str


def parse_usd(
    builder: ModelBuilder,
    source: str | UsdStage,
    *,
    xform: Transform | None = None,
    floating: bool | None = None,
    base_joint: dict | None = None,
    parent_body: int = -1,
    only_load_enabled_rigid_bodies: bool = False,
    only_load_enabled_joints: bool = True,
    joint_drive_gains_scaling: float = 1.0,
    verbose: bool = False,
    ignore_paths: list[str] | None = None,
    collapse_fixed_joints: bool = False,
    enable_self_collisions: bool = True,
    apply_up_axis_from_stage: bool = False,
    root_path: str = "/",
    joint_ordering: Literal["bfs", "dfs"] | None = "dfs",
    bodies_follow_joint_ordering: bool = True,
    skip_mesh_approximation: bool = False,
    load_sites: bool = True,
    load_visual_shapes: bool = True,
    load_static_visual_shapes: bool = True,
    hide_collision_shapes: bool = False,
    force_show_colliders: bool = False,
    parse_mujoco_options: bool = True,
    mesh_maxhullvert: int | None = None,
    schema_resolvers: list[SchemaResolver] | None = None,
    force_position_velocity_actuation: bool = False,
    convert_mjc_equality_constraints: bool = True,
    override_root_xform: bool = False,
    legacy_margin_gap: bool = False,
    legacy_angular_velocity_units: bool = False,
    legacy_springref_units: bool = False,
    return_deformable_results: bool = False,
) -> dict[str, Any]:
    """Parses a Universal Scene Description (USD) stage and adds rigid bodies, particles, soft bodies, shapes, and joints to the given ModelBuilder.

    The USD description has to be either a path (file name or URL), or an existing USD stage instance that implements the `Stage <https://openusd.org/dev/api/class_usd_stage.html>`_ interface.

    See :ref:`usd_parsing` for more information.

    Args:
        builder: The :class:`ModelBuilder` to add the bodies and joints to.
        source: The file path to the USD file, or an existing USD stage instance.
        xform: The transform to apply to the entire scene.
        override_root_xform: If ``True``, the articulation root's world-space
            transform is replaced by ``xform`` instead of being composed with it,
            preserving only the internal structure (relative body positions). Useful
            for cloning articulations at explicit positions. Not intended for sources
            containing multiple articulations, as all roots would be placed at the
            same ``xform``. Defaults to ``False``.
        floating: Controls the base joint type for the root body (bodies not connected as
            a child to any joint).

            - ``None`` (default): Uses format-specific default (creates a FREE joint for USD bodies without joints).
            - ``True``: Creates a FREE joint with 6 DOF (3 translation + 3 rotation). Only valid when
              ``parent_body == -1`` since FREE joints must connect to world frame.
            - ``False``: Creates a FIXED joint (0 DOF).

            Cannot be specified together with ``base_joint``.
        base_joint: Custom joint specification for connecting the root body to the world
            (or to ``parent_body`` if specified). This parameter enables hierarchical composition with
            custom mobility. Dictionary with joint parameters as accepted by
            :meth:`ModelBuilder.add_joint` (e.g., joint type, axes, limits, stiffness).

            Cannot be specified together with ``floating``.
        parent_body: Parent body index for hierarchical composition. If specified, attaches the
            imported root body to this existing body, making them part of the same kinematic articulation.
            The connection type is determined by ``floating`` or ``base_joint``. If ``-1`` (default),
            the root connects to the world frame. **Restriction**: Only the most recently added
            articulation can be used as parent; attempting to attach to an older articulation will raise
            a ``ValueError``.

            .. note::
               Valid combinations of ``floating``, ``base_joint``, and ``parent_body``:

               .. list-table::
                  :header-rows: 1
                  :widths: 15 15 15 55

                  * - floating
                    - base_joint
                    - parent_body
                    - Result
                  * - ``None``
                    - ``None``
                    - ``-1``
                    - Format default (USD: FREE joint for bodies without joints)
                  * - ``True``
                    - ``None``
                    - ``-1``
                    - FREE joint to world (6 DOF)
                  * - ``False``
                    - ``None``
                    - ``-1``
                    - FIXED joint to world (0 DOF)
                  * - ``None``
                    - ``{dict}``
                    - ``-1``
                    - Custom joint to world (e.g., D6)
                  * - ``False``
                    - ``None``
                    - ``body_idx``
                    - FIXED joint to parent body
                  * - ``None``
                    - ``{dict}``
                    - ``body_idx``
                    - Custom joint to parent body (e.g., D6)
                  * - *explicitly set*
                    - *explicitly set*
                    - *any*
                    - ❌ Error: mutually exclusive (cannot specify both)
                  * - ``True``
                    - ``None``
                    - ``body_idx``
                    - ❌ Error: FREE joints require world frame

        only_load_enabled_rigid_bodies: If True, only rigid bodies which do not have `physics:rigidBodyEnabled` set to False are loaded.
        only_load_enabled_joints: If True, only joints which do not have `physics:jointEnabled` set to False are loaded.
        joint_drive_gains_scaling: The default scaling of the PD control gains (stiffness and damping), if not set in the PhysicsScene with as "newton:joint_drive_gains_scaling".
        verbose: If True, print additional information about the parsed USD file. Default is False.
        ignore_paths: A list of regular expressions matching prim paths to ignore.
        collapse_fixed_joints: If True, fixed joints are removed and the respective bodies are merged. Only considered if not set on the PhysicsScene as "newton:collapse_fixed_joints".
        enable_self_collisions: Default for whether self-collisions are enabled for all shapes within an articulation. Resolved via the schema resolver from ``newton:selfCollisionEnabled`` (NewtonArticulationRootAPI) or ``physxArticulation:enabledSelfCollisions``; if neither is authored, this value takes precedence.
        apply_up_axis_from_stage: If True, the up axis of the stage will be used to set :attr:`newton.ModelBuilder.up_axis`. Otherwise, the stage will be rotated such that its up axis aligns with the builder's up axis. Default is False.
        root_path: The USD path to import, defaults to "/". Bound physics materials
            outside this subtree are resolved without importing unrelated bodies
            or shapes.
        joint_ordering: The ordering of the joints in the simulation. Can be either "bfs" or "dfs" for breadth-first or depth-first search, or ``None`` to keep joints in the order in which they appear in the USD. Default is "dfs".
        bodies_follow_joint_ordering: If True, the bodies are added to the builder in the same order as the joints (parent then child body). Otherwise, bodies are added in the order they appear in the USD. Default is True.
        skip_mesh_approximation: If True, mesh approximation is skipped. Otherwise, meshes are approximated according to the ``physics:approximation`` attribute defined on the UsdPhysicsMeshCollisionAPI (if it is defined), using the settings from :attr:`~newton.ModelBuilder.default_mesh_approximation_cfg`. Default is False.
        load_sites: If True, sites (prims with ``NewtonSiteAPI`` or ``MjcSiteAPI``) are loaded as non-colliding reference points. If False, sites are ignored. Default is True.
        load_visual_shapes: If True, non-physics visual geometry is loaded. If False, visual-only shapes are ignored (sites are still controlled by ``load_sites``). Default is True.
        load_static_visual_shapes: If True, supported visual-only geometry outside
            rigid-body hierarchies is loaded as static shapes when
            ``load_visual_shapes`` is also True. Default is True.
        hide_collision_shapes: If True, collision shapes on bodies that already
            have visual-only geometry are hidden unconditionally, regardless of
            whether the collider has authored PBR material data. Default is False.
        force_show_colliders: If True, collision shapes get the VISIBLE flag
            regardless of whether visual shapes exist on the same body. Note that
            ``hide_collision_shapes=True`` still suppresses the VISIBLE flag for
            colliders on bodies with visual-only geometry. Default is False.
        parse_mujoco_options: Whether MuJoCo solver options from the PhysicsScene should be parsed. If False, solver options are not loaded and custom attributes retain their default values. Default is True.
        convert_mjc_equality_constraints: Whether MuJoCo equality schemas should be converted to Newton loop
            joints or mimic constraints while preserving MuJoCo equality metadata for SolverMuJoCo. If False,
            equality constraints are preserved in the ``mujoco:equality_constraint`` custom-attribute namespace
            and finalize under ``model.mujoco.equality_constraint_*``.
        mesh_maxhullvert: Maximum vertices for convex hull approximation of meshes. Note that an authored ``newton:maxHullVertices`` attribute on any shape with a ``NewtonMeshCollisionAPI`` will take priority over this value.
        schema_resolvers: Resolver instances in priority order. Default is to only parse Newton-specific attributes.
            Schema resolvers collect per-prim "solver-specific" attributes, see :ref:`schema_resolvers` for more information.
            These include namespaced attributes such as ``newton:*``, ``physx*``
            (e.g., ``physxScene:*``, ``physxRigidBody:*``, ``physxSDFMeshCollision:*``), and ``mjc:*`` that
            are authored in the USD but not strictly required to build the simulation. This is useful for
            inspection, experimentation, or custom pipelines that read these values via
            ``result["schema_attrs"]`` returned from ``parse_usd()``.

            .. experimental::

                The ``schema_resolvers`` argument may change without prior notice.
        force_position_velocity_actuation: If True and both stiffness (kp) and damping (kd)
            are non-zero, joints use :attr:`~newton.JointTargetMode.POSITION_VELOCITY` actuation mode.
            If False (default), actuator modes are inferred per joint via :func:`newton.JointTargetMode.from_gains`:
            :attr:`~newton.JointTargetMode.POSITION` if stiffness > 0, :attr:`~newton.JointTargetMode.VELOCITY` if only
            damping > 0, :attr:`~newton.JointTargetMode.EFFORT` if a drive is present but both gains are zero
            (direct torque control), or :attr:`~newton.JointTargetMode.NONE` if no drive/actuation is applied.
        legacy_margin_gap: If True, restore pre-MuJoCo-3.9 import behavior
            where ``shape_margin`` is computed as ``mjc_margin - mjc_gap``.
            Use for USD files authored against MuJoCo <= 3.8. Defaults to
            False (identity translation matching MuJoCo 3.9 semantics).
        legacy_angular_velocity_units: If True, restore Newton 1.6 joint-state angular velocity handling:
            resolved ``state:angular:physics:velocity``
            and D6 ``state:rot*:physics:velocity`` values are copied into
            ``joint_qd`` without converting degrees/s to radians/s. Applies
            to revolute, native D6, and merged joints. Rigid-body velocities,
            linear joint velocities, positions, and drive targets retain their
            usual unit conversion. Defaults to False.

            .. deprecated:: 1.7
                This temporary flag will be removed in Newton 1.8. Enabling
                it emits a :class:`DeprecationWarning`. Migrate authored
                asset values to their documented units and leave it False.

        legacy_springref_units: If True, restore Newton 1.6 handling of ``mjc:springref`` as an
            already converted Newton value, ignoring
            ``mjc:compiler:angle`` for spring references only. ``mjc:ref``
            conversion is unchanged. Requires registered MuJoCo custom
            attributes to load spring references. Defaults to False, which
            interprets revolute spring references using the compiler's angle
            units (degrees if unauthored) and converts them to radians.

            .. deprecated:: 1.7
                This temporary flag will be removed in Newton 1.8. Enabling
                it emits a :class:`DeprecationWarning`. Migrate authored
                asset values to their documented units and leave it False.

        return_deformable_results: If True, include the experimental deformable entries in the
            returned mapping (``path_cable_map`` / ``path_cloth_map`` / ``path_soft_map`` /
            ``path_attachment_map`` and the matching ``path_*_attrs``). Off by default, so the
            default return shape carries no deformable additions.

    Returns:
        .. experimental::

           ``return_deformable_results`` and its conditional result entries are experimental and
           may change or be removed without prior notice.

        When ``return_deformable_results=True``, imported deformable (cable/cloth/volume) element
        ranges are returned by prim path in the ``path_cable_map`` / ``path_cloth_map`` /
        ``path_soft_map`` entries below, and the material attributes as authored in the
        matching ``path_*_attrs`` entries. The map entries are build-time snapshots of the
        builder immediately after this call (already remapped when this call collapses fixed
        joints); they are not live selections, and a later ``replicate()``, ``add_builder()``,
        or other structural mutation is outside their contract. The ``path_*_attrs`` entries
        hold authored or resolved source values (``material`` as authored,
        ``resolved_density`` as used), while the map entries and ``joint_indices`` inside
        ``path_attachment_attrs`` are realized builder indices; ``unsupported_reason`` is
        diagnostic text, not a stable code, and a prim absent from a realized map may still
        appear in the authored metadata.

        ``path_particle_map`` is always returned. It maps each imported
        ``UsdGeom.Points`` prim carrying ``NewtonPointsDeformableSimAPI`` whose
        governing ``PhysicsDeformableBodyAPI`` resolves to a
        ``NewtonMPMSceneAPI`` owner to its half-open ``[start, end)`` builder
        particle range. These ranges are build-time snapshots and are not
        updated by later structural builder mutations.
        Each resolved whole-prim or point-``GeomSubset`` physics material must
        apply ``NewtonMPMMaterialAPI``, ``PhysicsMaterialAPI``, or
        ``PhysicsVolumeDeformableMaterialAPI``. MPM elasticity is read from
        ``newton:mpm:youngsModulus`` and ``newton:mpm:poissonsRatio``. After
        unit conversion, Young's modulus is in Pa and density is in kg/m^3.
        Unbound Points use Newton's registered material defaults and
        ``ModelBuilder.default_shape_cfg`` density. All Points imported by one
        call must resolve to the same MPM scene; unrelated PhysicsScenes
        and particle systems are ignored. ``particle_scene_path`` contains the
        governing ``UsdPhysics.Scene`` prim path, or ``None`` when no particles
        are imported.

        Particle widths are diameters. Newton converts each radius as
        ``width / 2`` after applying stage units and the prim's uniform world
        scale; converted widths and radii are in meters. Authored
        ``physics:masses`` take precedence over body mass or density, then
        material density. Density-derived mass uses
        ``physics:density * width**3``; converted masses are in kilograms.
        Without widths, it uses ``ModelBuilder.default_particle_radius`` and a
        support width of twice that radius. Non-uniform scale or shear is
        rejected because one scalar width cannot preserve a spherical particle
        under that transform.

        Visual meshes load or generate normals through :func:`newton.usd.get_mesh`.
        Sharp shading can duplicate vertices in :attr:`Model.shape_source`,
        including for untextured meshes. Collision-only loads do not request
        normals, and visual expansion preserves source mass properties. Use
        :func:`newton.usd.get_mesh` with ``load_normals=False`` when source
        vertex sharing is required for geometry processing.

        The returned mapping has the following entries:

        .. list-table::
            :widths: 25 75

            * - ``"fps"``
              - USD stage frames per second
            * - ``"duration"``
              - Difference between end time code and start time code of the USD stage
            * - ``"up_axis"``
              - :class:`Axis` representing the stage's up axis ("X", "Y", or "Z")
            * - ``"path_body_map"``
              - Mapping from prim path (str) of a rigid body prim (e.g. that implements the PhysicsRigidBodyAPI) to the respective body index in :class:`~newton.ModelBuilder`
            * - ``"path_joint_map"``
              - Mapping from prim path (str) of a joint prim (e.g. that implements the PhysicsJointAPI) to the respective joint index in :class:`~newton.ModelBuilder`
            * - ``"path_shape_map"``
              - Mapping from prim path (str) of the UsdGeom to the respective shape index in :class:`~newton.ModelBuilder`
            * - ``"path_shape_scale"``
              - Mapping from prim path (str) of the UsdGeom to its respective 3D world scale
            * - ``"path_particle_map"``
              - Mapping from an imported particle-simulation ``UsdGeom.Points`` prim path to its half-open ``(particle_start, particle_end)`` builder range
            * - ``"path_cable_map"``
              - Mapping from prim path (str) of a curve deformable (cable) to its ``(body_indices, joint_indices)`` lists. Curves welded into a rod graph report empty joints (the joints belong to the shared graph articulation). Present only with ``return_deformable_results=True``.
            * - ``"path_cloth_map"``
              - Mapping from prim path (str) of a surface deformable (cloth) to its ``[start, end)`` index ranges, keyed ``"particle"`` / ``"tri"`` / ``"edge"``. Present only with ``return_deformable_results=True``.
            * - ``"path_soft_map"``
              - Mapping from prim path (str) of a soft body (a volume deformable, or a legacy bare TetMesh) to its ``[start, end)`` index ranges, keyed ``"particle"`` / ``"tet"``. Present only with ``return_deformable_results=True``.
            * - ``"path_cable_attrs"``
              - Mapping from prim path (str) of a curve deformable (cable) to its validated, solver-neutral cable import metadata (``material``, ``resolved_density``, ``closed``). ``material`` contains supported per-mode structural values before per-joint discretization: stretch/shear stiffness [N] and damping [N·s]; bend/twist stiffness [N·m²] and damping [N·m²·s]. ``graph_component`` is present only for curves successfully welded into the same rod graph; curves in one graph share the identifier. Present only with ``return_deformable_results=True``.
            * - ``"path_cloth_attrs"``
              - Mapping from prim path (str) of a surface deformable (cloth) to its as-authored, solver-neutral attributes (``material`` moduli, ``resolved_density``). Present only with ``return_deformable_results=True``.
            * - ``"path_soft_attrs"``
              - Mapping from prim path (str) of a soft body (a volume deformable, or a legacy bare TetMesh) to its as-authored, solver-neutral attributes (``resolved_density``). Present only with ``return_deformable_results=True``.
            * - ``"path_attachment_map"``
              - Mapping from prim path (str) of a supported ``PhysicsAttachment`` prim to the created joint indices. Curve-to-curve ``point``->``point`` junctions are consumed as rod-graph topology and are absent from this mapping. Present only with ``return_deformable_results=True``.
            * - ``"path_attachment_attrs"``
              - Mapping from prim path (str) of a ``PhysicsAttachment`` prim to its parsed, solver-neutral attributes and any unsupported reason. Junctions consumed as rod-graph topology are absent here as well. Present only with ``return_deformable_results=True``.
            * - ``"mass_unit"``
              - The stage's Kilograms Per Unit (KGPU) definition (1.0 by default)
            * - ``"linear_unit"``
              - The stage's Meters Per Unit (MPU) definition (1.0 by default)
            * - ``"scene_attributes"``
              - Dictionary of all attributes applied to the PhysicsScene prim
            * - ``"physics_scene_path"``
              - Prim path of the PhysicsScene selected during import, or ``None`` if no PhysicsScene was found
            * - ``"collapse_results"``
              - Dictionary returned by :meth:`newton.ModelBuilder.collapse_fixed_joints` if ``collapse_fixed_joints`` is True, otherwise None.
            * - ``"physics_dt"``
              - The resolved physics scene time step (float or None)
            * - ``"schema_attrs"``
              - Dictionary of collected per-prim schema attributes (dict)
            * - ``"max_solver_iterations"``
              - The resolved maximum solver iterations (int or None)
            * - ``"particle_scene_path"``
              - Governing ``UsdPhysics.Scene`` prim path for imported particle simulation geometry, or ``None`` when no particles are imported
            * - ``"path_body_relative_transform"``
              - Mapping from prim path to relative transform for bodies merged via ``collapse_fixed_joints``
            * - ``"path_original_body_map"``
              - Mapping from prim path to original body index before ``collapse_fixed_joints``
            * - ``"actuator_count"``
              - Number of external actuators parsed from the USD stage
    """
    for name, enabled in (
        ("legacy_angular_velocity_units", legacy_angular_velocity_units),
        ("legacy_springref_units", legacy_springref_units),
    ):
        if enabled:
            warnings.warn(
                f"{name}=True is deprecated and will be removed in Newton 1.8. "
                "Migrate authored asset values to their documented units and leave this option False.",
                DeprecationWarning,
                stacklevel=_external_warning_stacklevel(),
            )

    # Early validation of base joint parameters
    builder._validate_base_joint_params(floating, base_joint, parent_body)
    first_imported_joint = builder.joint_count

    if mesh_maxhullvert is None:
        mesh_maxhullvert = Mesh.MAX_HULL_VERTICES

    if schema_resolvers is None:
        schema_resolvers = [SchemaResolverNewton()]
    collect_schema_attrs = len(schema_resolvers) > 0

    try:
        from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics
    except ImportError as e:
        raise ImportError("Failed to import pxr. Please install USD (e.g. via `pip install usd-core`).") from e
    require_newton_usd_schemas(Usd)

    from ..usd import _joints  # noqa: PLC0415
    from ..usd._articulations import _parse_articulations  # noqa: PLC0415
    from ..usd._colliders import _parse_colliders  # noqa: PLC0415
    from ..usd._collision_filters import (  # noqa: PLC0415
        _apply_collision_groups,
        _apply_filtered_pairs,
        _collect_filtered_pairs,
    )
    from ..usd._mass_properties import _is_enabled_collider, _UsdMassProperties  # noqa: PLC0415
    from ..usd._visuals import _UsdVisuals  # noqa: PLC0415

    # Capture material defaults at the start of this import.
    default_material = _PhysicsMaterial(
        staticFriction=builder.default_shape_cfg.mu,
        dynamicFriction=builder.default_shape_cfg.mu,
        torsionalFriction=builder.default_shape_cfg.mu_torsional,
        rollingFriction=builder.default_shape_cfg.mu_rolling,
        restitution=builder.default_shape_cfg.restitution,
        density=builder.default_shape_cfg.density,
    )

    # load joint defaults
    default_joint_friction = builder.default_joint_cfg.friction
    default_joint_damping = builder.default_joint_cfg.damping
    default_joint_limit_ke = builder.default_joint_cfg.limit_ke
    default_joint_limit_kd = builder.default_joint_cfg.limit_kd
    canonical_joint_cfg = ModelBuilder.JointDofConfig()
    default_joint_limit_gains_configured = (
        default_joint_limit_ke != canonical_joint_cfg.limit_ke or default_joint_limit_kd != canonical_joint_cfg.limit_kd
    )
    default_joint_armature = builder.default_joint_cfg.armature
    default_joint_velocity_limit = builder.default_joint_cfg.velocity_limit

    # load shape defaults
    default_shape_density = builder.default_shape_cfg.density

    if ignore_paths is None:
        ignore_paths = []

    usd_axis_to_axis = {
        UsdPhysics.Axis.X: Axis.X,
        UsdPhysics.Axis.Y: Axis.Y,
        UsdPhysics.Axis.Z: Axis.Z,
    }

    if isinstance(source, str):
        stage = Usd.Stage.Open(source, Usd.Stage.LoadAll)
        _raise_on_stage_errors(stage, source)
    else:
        stage = source
        _raise_on_stage_errors(stage, "provided stage")

    DegreesToRadian = float(np.pi / 180)
    mass_unit = 1.0

    try:
        if UsdPhysics.StageHasAuthoredKilogramsPerUnit(stage):
            mass_unit = UsdPhysics.GetStageKilogramsPerUnit(stage)
    except Exception as e:
        if verbose:
            print(f"Failed to get mass unit: {e}")
    linear_unit = 1.0
    try:
        if UsdGeom.StageHasAuthoredMetersPerUnit(stage):
            linear_unit = UsdGeom.GetStageMetersPerUnit(stage)
    except Exception as e:
        if verbose:
            print(f"Failed to get linear unit: {e}")
    has_nonunit_linear_units = not math.isclose(linear_unit, 1.0)
    has_nonunit_mass_units = not math.isclose(mass_unit, 1.0)
    non_regex_ignore_paths = [path for path in ignore_paths if ".*" not in path]
    # The native rigid/joint descriptor parser remains authoritative, so this
    # pre-pass supplies its deformable exclusions before it runs. The same walk also
    # collects static visual leaves when requested, avoiding a third stage traversal.
    root_prim = stage.GetPrimAtPath(root_path)
    particle_prims = find_particle_prims(root_prim, ignore_paths)
    _deformable_prims = _scout_deformable_prims(
        root_prim,
        ignore_paths,
        collect_static_visuals=load_visual_shapes and load_static_visual_shapes,
    )
    deformable_visual_exclude_paths = set(_deformable_prims.native_physics_exclude_paths)
    native_exclude_paths = list(
        dict.fromkeys([*non_regex_ignore_paths, *_deformable_prims.native_physics_exclude_paths])
    )
    ret_dict = usd.load_physics_from_range(stage, [root_path], native_exclude_paths)
    physics_scenes = usd._get_physics_scenes_from_results(stage, ret_dict)
    physics_scene_prim = physics_scenes[0].GetPrim() if physics_scenes else None

    legacy_rigid_object_types = (
        UsdPhysics.ObjectType.RigidBody,
        UsdPhysics.ObjectType.SphereShape,
        UsdPhysics.ObjectType.CubeShape,
        UsdPhysics.ObjectType.CapsuleShape,
        UsdPhysics.ObjectType.CylinderShape,
        UsdPhysics.ObjectType.ConeShape,
        UsdPhysics.ObjectType.MeshShape,
        UsdPhysics.ObjectType.PlaneShape,
    )
    has_legacy_rigid_objects = any(kind in ret_dict for kind in legacy_rigid_object_types)
    has_other_import_candidates = bool(
        has_legacy_rigid_objects or _deformable_prims.has_candidates() or _deformable_prims.static_visuals
    )
    if particle_prims and has_legacy_rigid_objects and (has_nonunit_linear_units or has_nonunit_mass_units):
        warnings.warn(
            "Mixed rigid/collider and particle USD content with non-unit metersPerUnit or kilogramsPerUnit uses "
            "different conversion paths: particles are converted to SI, while the legacy rigid/collider importer "
            "still expects unit stage metadata. Author mixed stages with both units set to 1.0 until rigid import "
            "gains complete unit conversion.",
            stacklevel=_external_warning_stacklevel(),
        )
    elif particle_prims and has_other_import_candidates and (has_nonunit_linear_units or has_nonunit_mass_units):
        warnings.warn(
            "Mixed particles and other imported USD content with non-unit metersPerUnit or kilogramsPerUnit may "
            "use different conversion paths: particles are converted to SI, while other import paths may still "
            "expect unit stage metadata. Author mixed stages with both units set to 1.0.",
            stacklevel=_external_warning_stacklevel(),
        )
    elif not particle_prims:
        if has_nonunit_mass_units:
            warnings.warn(
                "USD stages with non-unit mass units are not supported. "
                f"Set kilogramsPerUnit to 1.0 before import. Found kilogramsPerUnit={mass_unit}.",
                stacklevel=_external_warning_stacklevel(),
            )
        if has_nonunit_linear_units:
            warnings.warn(
                "USD stages with non-unit linear units are not supported. "
                f"Set metersPerUnit to 1.0 before import. Found metersPerUnit={linear_unit}.",
                stacklevel=_external_warning_stacklevel(),
            )

    # Initialize schema resolver according to precedence
    R = SchemaResolverManager(schema_resolvers)

    # Vendor namespaces (e.g. omniphysics, physxDeformableBody) accepted as a
    # fallback to the canonical physics: deformable schema. Empty unless a
    # resolver declaring them (e.g. SchemaResolverPhysx) is active, so a default
    # import parses the AOUSD proposal as written.
    deformable_compat_ns = R.deformable_compat_namespaces()
    # Resolver-owned deformable read (physics: first, then opted-in vendor namespaces).
    deformable_read = R.read_deformable_attr

    # Validate solver-specific custom attributes are registered
    for resolver in schema_resolvers:
        resolver.validate_custom_attributes(builder)
    mjc_resolver = next((resolver for resolver in schema_resolvers if resolver.name == "mjc"), None)
    joint_properties = _UsdJointProperties(
        resolver=R,
        degrees_to_radian=DegreesToRadian,
        default_armature=default_joint_armature,
        default_friction=default_joint_friction,
        default_damping=default_joint_damping,
        default_limit_ke=default_joint_limit_ke,
        default_limit_kd=default_joint_limit_kd,
        limit_gains_configured=default_joint_limit_gains_configured,
        mjc_resolver=mjc_resolver,
        verbose=verbose,
        legacy_angular_velocity_units=legacy_angular_velocity_units,
        legacy_springref_units=legacy_springref_units,
    )
    solreflimit_mode_key = "mujoco:solreflimit_mode"
    solreflimit_gain_baseline_key = "mujoco:solreflimit_gain_baseline"

    # mapping from prim path to body index in ModelBuilder
    path_body_map: dict[str, int] = {}
    # mapping from prim path to shape index in ModelBuilder
    path_shape_map: dict[str, int] = {}
    path_shape_scale: dict[str, wp.vec3] = {}
    # mapping from prim path to joint index in ModelBuilder
    path_joint_map: dict[str, int] = {}
    # Particle ranges are stable build-time snapshots, keyed by authored Points path.
    path_particle_map: dict[str, tuple[int, int]] = {}
    # Import-internal deformable index maps (not returned): the attachment and collapse passes
    # look up a curve/cloth/soft prim's element indices by path while building. The equivalent
    # per-group index ranges are recorded on the builder/Model registries for callers.
    path_cable_map: dict[str, tuple[list[int], list[int]]] = {}
    path_cloth_map: dict[str, dict[str, tuple[int, int]]] = {}
    path_soft_map: dict[str, dict[str, tuple[int, int]]] = {}
    # Solver-neutral deformable attributes per prim path: parsed material properties and resolved
    # density, so another consumer can rebuild the deformable without re-parsing the stage.
    path_cable_attrs: dict[str, dict[str, Any]] = {}
    path_cloth_attrs: dict[str, dict[str, Any]] = {}
    path_soft_attrs: dict[str, dict[str, Any]] = {}
    path_attachment_map: dict[str, list[int]] = {}
    # Attachment attributes are preserved even when the current builder cannot lower
    # the attachment faithfully (e.g. cloth/volume feature attachments).
    path_attachment_attrs: dict[str, dict[str, Any]] = {}
    # Internal cable maps used by the PhysicsAttachment post-pass. Proposal
    # point/segment indices are flattened across each BasisCurves prim in curve order.
    path_cable_point_anchors: dict[str, dict[int, list[tuple[int, wp.vec3]]]] = {}
    path_cable_segments: dict[str, dict[int, tuple[int, float]]] = {}
    # DOF offset within a merged D6 joint for each original prim path (only populated for merged joints)
    merged_dof_offset: dict[str, int] = {}
    # cache for TetMesh data loaded from USD prims
    tetmesh_cache: dict[str, TetMesh] = {}

    physics_dt = None
    max_solver_iters = None
    particle_scene_prim = None

    visual_shape_cfg = ModelBuilder.ShapeConfig(
        density=0.0,
        has_shape_collision=False,
        has_particle_collision=False,
    )

    # Create a cache for world transforms to avoid recomputing them for each prim.
    xform_cache = UsdGeom.XformCache(Usd.TimeCode.Default())
    traverse_instance_proxies = Usd.TraverseInstanceProxies()
    visuals = _UsdVisuals(stage)

    def _xform_to_mat44(xform: wp.transform) -> wp.mat44:
        return wp.transform_compose(xform.p, xform.q, wp.vec3(1.0))

    def _has_api_schema(prim: Usd.Prim, schema_name: str) -> bool:
        return bool(prim and prim.IsValid() and usd.has_applied_api_schema(prim, schema_name))

    mass_properties = _UsdMassProperties(stage, usd_axis_to_axis, visuals.get_mesh_cached)

    def _should_write_solreflimit_mode() -> bool:
        return mjc_resolver is not None and solreflimit_mode_key in builder.custom_attributes

    def _should_write_solreflimit_gain_baseline() -> bool:
        return mjc_resolver is not None and solreflimit_gain_baseline_key in builder.custom_attributes

    def _get_rigid_body_ancestor_path(prim: Usd.Prim) -> str | None:
        current = prim
        while current and current.IsValid():
            current_path = str(current.GetPath())
            if current_path in path_body_map:
                return current_path
            current = current.GetParent()
        return None

    def _is_world_target(target_path: str) -> bool:
        """Return whether the target path represents the world body."""
        if target_path in ("", "/"):
            return True

        default_prim = stage.GetDefaultPrim()
        return bool(
            default_prim
            and default_prim.IsValid()
            and target_path == str(default_prim.GetPath())
            and target_path not in path_body_map
        )

    def _get_target_body_and_local_pos(target_path: str) -> tuple[int, wp.vec3] | None:
        """Resolve a target to its body index and body-local position."""
        if _is_world_target(target_path):
            return (-1, wp.vec3())

        target_prim = stage.GetPrimAtPath(target_path)
        if not target_prim or not target_prim.IsValid():
            return None

        body_path = _get_rigid_body_ancestor_path(target_prim)
        if body_path is None:
            return None

        body_idx = path_body_map.get(body_path, -1)
        if body_idx < 0:
            return None

        if target_path == body_path:
            return (body_idx, wp.vec3())

        body_prim = stage.GetPrimAtPath(body_path)
        body_world = usd.get_transform(body_prim, local=False, xform_cache=xform_cache)
        target_world = usd.get_transform(target_prim, local=False, xform_cache=xform_cache)
        local_tf = wp.transform_inverse(body_world) * target_world
        return (body_idx, local_tf.p)

    def _get_first_target(prim: Usd.Prim, rel_name: str) -> str:
        """Return the first target path of *rel_name* on *prim*, or ``""`` for world."""
        rel = prim.GetRelationship(rel_name)
        targets = rel.GetTargets() if rel else []
        return str(targets[0]) if targets else ""

    def _resolve_equality_bodies(
        joint_prim: Usd.Prim,
        joint_path: str,
        schema_name: str,
    ) -> tuple[tuple[int, wp.vec3] | None, tuple[int, wp.vec3] | None]:
        """Resolve body0 and body1 for a Connect/Weld equality joint prim.

        Returns ``(body0_info, body1_info)`` where each is
        ``(body_index, local_position)`` or ``None`` on failure.
        An empty target list is interpreted as the world body (index -1).
        """
        target0 = _get_first_target(joint_prim, "physics:body0")
        target1 = _get_first_target(joint_prim, "physics:body1")

        if target0 == "" and target1 == "":
            warnings.warn(
                f"{schema_name} on '{joint_path}' has no physics:body0 or physics:body1 targets; skipping.",
                stacklevel=3,
            )
            return None, None

        # Empty target means world body (index -1).
        body0_info = _get_target_body_and_local_pos(target0) if target0 else (-1, wp.vec3())
        body1_info = _get_target_body_and_local_pos(target1) if target1 else (-1, wp.vec3())

        if body0_info is None or body1_info is None:
            failed_targets = []
            if body0_info is None:
                failed_targets.append(f"physics:body0='{target0}'")
            if body1_info is None:
                failed_targets.append(f"physics:body1='{target1}'")
            warnings.warn(
                f"{schema_name} on '{joint_path}' references unresolved body target(s) "
                f"{', '.join(failed_targets)}; skipping.",
                stacklevel=3,
            )
            return None, None

        return body0_info, body1_info

    def _get_tetmesh_cached(prim: Usd.Prim) -> TetMesh:
        """Load and cache TetMesh data to avoid repeated USD extraction."""
        prim_path = str(prim.GetPath())
        if prim_path not in tetmesh_cache:
            # Pass the resolver-declared namespaces explicitly (never None), so the importer keeps the
            # canonical physics: default and does not trip get_tetmesh()'s legacy-default deprecation.
            compat_ns = deformable_compat_ns
            if not compat_ns and usd._material_authors_legacy_deformable_attrs(prim):
                # Without this deprecation window, a vendor-only material would silently
                # import with default stiffness/density instead of its authored values.
                warnings.warn(
                    f"{prim_path}: the bound material authors legacy vendor-namespaced deformable "
                    f"material attributes (omniphysics: / physxDeformableBody:) without "
                    f"PhysicsVolumeDeformableMaterialAPI. add_usd() still reads them, but this is "
                    f"deprecated: author the canonical physics: attributes with the material API, or "
                    f"pass schema_resolvers=[..., SchemaResolverPhysx()] to keep vendor namespaces "
                    f"explicitly.",
                    DeprecationWarning,
                    stacklevel=2,
                )
                compat_ns = usd.DEFORMABLE_LEGACY_NAMESPACES
            tetmesh_cache[prim_path] = usd._get_tetmesh(
                prim,
                compat_namespaces=compat_ns,
                load_custom_attributes=False,
                # The marked-volume pass owns current proposal material lowering. Avoid
                # reading it here too, which would duplicate validation warnings. Keep
                # get_tetmesh's material path for bare TetMeshes and legacy API-less assets.
                load_material=usd._should_load_tetmesh_material_for_import(prim),
            )
        return tetmesh_cache[prim_path]

    bodies_with_visual_shapes: set[int] = set()

    def _get_prim_world_mat(prim, articulation_root_xform, incoming_world_xform):
        prim_world_mat = usd.get_transform_matrix(prim, local=False, xform_cache=xform_cache)
        if articulation_root_xform is not None:
            rebase_mat = _xform_to_mat44(wp.transform_inverse(articulation_root_xform))
            prim_world_mat = rebase_mat @ prim_world_mat
        if incoming_world_xform is not None:
            # Apply the incoming world transform in model space (static shapes or when using body_xform).
            incoming_mat = _xform_to_mat44(incoming_world_xform)
            prim_world_mat = incoming_mat @ prim_world_mat
        return prim_world_mat

    def _load_visual_shape_children(
        parent_body_id: int,
        prim: Usd.Prim,
        body_xform: wp.transform | None,
        articulation_root_xform: wp.transform | None,
        allow_visual_shapes: bool,
    ):
        for child in prim.GetFilteredChildren(traverse_instance_proxies):
            _load_visual_shapes_impl(parent_body_id, child, body_xform, articulation_root_xform, allow_visual_shapes)

    def _load_visual_shapes_impl(
        parent_body_id: int,
        prim: Usd.Prim,
        body_xform: wp.transform | None = None,
        articulation_root_xform: wp.transform | None = None,
        allow_visual_shapes: bool = True,
        recurse: bool = True,
    ):
        """Load visual shapes and sites for a prim subtree.

        Args:
            parent_body_id: ModelBuilder body id to attach shapes to. Use -1 for
                static shapes that are not bound to any rigid body.
            prim: USD prim to inspect for visual geometry and recurse into.
            body_xform: Rigid body transform actually used by the builder.
                This matches any physics-authored pose, scene-level transforms,
                and incoming transforms that were applied when the body was created.
            articulation_root_xform: The articulation root's world-space transform,
                passed when override_root_xform=True. Strips the root's original
                pose from visual prim transforms to match the rebased body transforms.
            allow_visual_shapes: Whether non-site geometry may be loaded from this subtree.
            recurse: Whether to inspect child prims after processing ``prim``.
        """
        if prim.HasAPI(UsdPhysics.RigidBodyAPI):
            return
        path_name = str(prim.GetPath())
        if any(re.match(path, path_name) for path in ignore_paths):
            return
        if _is_enabled_collider(prim):
            if recurse:
                _load_visual_shape_children(parent_body_id, prim, body_xform, articulation_root_xform, False)
            return

        type_name = str(prim.GetTypeName()).lower()
        if type_name.endswith("joint"):
            return

        is_site = usd.has_applied_api_schema(prim, "NewtonSiteAPI") or usd.has_applied_api_schema(prim, "MjcSiteAPI")
        if is_site and not load_sites:
            return
        if not is_site and not allow_visual_shapes:
            if recurse:
                _load_visual_shape_children(
                    parent_body_id, prim, body_xform, articulation_root_xform, allow_visual_shapes
                )
            return
        if type_name not in _LOADABLE_VISUAL_TYPE_NAMES_LOWER:
            # Skip the transform/material work below for prims that cannot produce a shape.
            if (
                len(type_name) > 0
                and type_name not in {"geomsubset", "material", "scope", "shader", "xform", "tetmesh"}
                and path_name not in path_shape_map
                and verbose
            ):
                print(f"Warning: Unsupported geometry type {type_name} at {path_name} while loading visual shapes.")
            if recurse:
                _load_visual_shape_children(
                    parent_body_id, prim, body_xform, articulation_root_xform, allow_visual_shapes
                )
            return

        prim_world_mat = _get_prim_world_mat(
            prim,
            articulation_root_xform,
            incoming_world_xform if (parent_body_id == -1 or body_xform is not None) else None,
        )
        if body_xform is not None:
            # Use the body transform used by the builder to avoid USD/physics pose mismatches.
            body_world_mat = _xform_to_mat44(body_xform)
            rel_mat = wp.inverse(body_world_mat) @ prim_world_mat
        else:
            rel_mat = prim_world_mat

        xform_pos, xform_rot, scale = wp.transform_decompose(rel_mat)
        xform = wp.transform(xform_pos, xform_rot)

        shape_id = -1

        visual_shape_cfg_for_prim = copy.copy(visual_shape_cfg)
        visual_shape_cfg_for_prim.is_visible = is_site or visuals.is_viewport_drawn(prim)
        material_props = visuals.get_material_props_cached(prim)
        shape_color = material_props.get("color")
        shape_visual_kwargs = {}
        if material_props.get("opacity") is not None:
            shape_visual_kwargs["opacity"] = material_props["opacity"]
        # A textured mesh resolves no scalar color on purpose, so the texture is not tinted;
        # the mesh path gives it white. Geometry that never receives the texture still wants
        # the neutral, otherwise it falls through to a palette color.
        carries_texture = material_props.get("texture") is not None and type_name == "mesh"
        if shape_color is None and not carries_texture and visual_shape_cfg_for_prim.is_visible:
            shape_color = _UNMATERIALED_VISUAL_COLOR

        if path_name not in path_shape_map:
            if type_name == "cube":
                size = usd.get_float(prim, "size", 2.0)
                side_lengths = scale * size
                shape_id = builder.add_shape_box(
                    parent_body_id,
                    xform=xform,
                    hx=side_lengths[0] / 2,
                    hy=side_lengths[1] / 2,
                    hz=side_lengths[2] / 2,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    as_site=is_site,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            elif type_name == "sphere":
                if not _is_uniform_scale(scale):
                    print(f"Warning: Non-uniform scaling of spheres is not supported, at {path_name}.")
                radius = usd.get_float(prim, "radius", 1.0) * max(scale)
                shape_id = builder.add_shape_sphere(
                    parent_body_id,
                    xform=xform,
                    radius=radius,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    as_site=is_site,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            elif type_name == "plane":
                axis = usd.get_gprim_axis(prim)
                width, length = visuals.get_planar_visual_dimensions(prim, scale, axis)
                # Apply axis rotation to transform
                xform = wp.transform(xform.p, xform.q * quat_between_axes(Axis.Z, axis))
                shape_id = builder.add_shape_plane(
                    body=parent_body_id,
                    xform=xform,
                    width=width,
                    length=length,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            elif type_name == "capsule":
                axis = usd.get_gprim_axis(prim)
                radius, half_height = visuals.get_axial_visual_dimensions(
                    prim, scale, axis, default_radius=0.5, default_height=1.0
                )
                # Apply axis rotation to transform
                xform = wp.transform(xform.p, xform.q * quat_between_axes(Axis.Z, axis))
                shape_id = builder.add_shape_capsule(
                    parent_body_id,
                    xform=xform,
                    radius=radius,
                    half_height=half_height,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    as_site=is_site,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            elif type_name == "cylinder":
                axis = usd.get_gprim_axis(prim)
                radius, half_height = visuals.get_axial_visual_dimensions(
                    prim, scale, axis, default_radius=1.0, default_height=2.0
                )
                # Apply axis rotation to transform
                xform = wp.transform(xform.p, xform.q * quat_between_axes(Axis.Z, axis))
                shape_id = builder.add_shape_cylinder(
                    parent_body_id,
                    xform=xform,
                    radius=radius,
                    half_height=half_height,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    as_site=is_site,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            elif type_name == "cone":
                axis = usd.get_gprim_axis(prim)
                radius, half_height = visuals.get_axial_visual_dimensions(
                    prim, scale, axis, default_radius=1.0, default_height=2.0
                )
                # Apply axis rotation to transform
                xform = wp.transform(xform.p, xform.q * quat_between_axes(Axis.Z, axis))
                shape_id = builder.add_shape_cone(
                    parent_body_id,
                    xform=xform,
                    radius=radius,
                    half_height=half_height,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    as_site=is_site,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            elif type_name == "mesh":
                subset_meshes = visuals.get_visual_material_subset_meshes(prim)
                if subset_meshes:
                    for subset_path, subset_mesh in subset_meshes:
                        subset_shape_id = builder.add_shape_mesh(
                            parent_body_id,
                            xform=xform,
                            scale=scale,
                            mesh=subset_mesh,
                            cfg=visual_shape_cfg_for_prim,
                            color=None,
                            label=subset_path,
                        )
                        path_shape_map[subset_path] = subset_shape_id
                        path_shape_scale[subset_path] = scale
                        if shape_id < 0:
                            shape_id = subset_shape_id
                        if verbose:
                            print(
                                f"Added visual shape {subset_path} ({type_name} material subset) "
                                f"with id {subset_shape_id}."
                            )
                else:
                    mesh = visuals.get_mesh_with_visual_material(prim, path_name=path_name)
                    shape_id = builder.add_shape_mesh(
                        parent_body_id,
                        xform=xform,
                        scale=scale,
                        mesh=mesh,
                        cfg=visual_shape_cfg_for_prim,
                        color=shape_color,
                        label=path_name,
                        **shape_visual_kwargs,
                    )
            elif type_name == "particlefield3dgaussiansplat":
                gaussian = usd.get_gaussian(prim)
                shape_id = builder.add_shape_gaussian(
                    parent_body_id,
                    gaussian=gaussian,
                    xform=xform,
                    scale=scale,
                    cfg=visual_shape_cfg_for_prim,
                    color=shape_color,
                    label=path_name,
                    **shape_visual_kwargs,
                )
            if shape_id >= 0:
                path_shape_map[path_name] = shape_id
                path_shape_scale[path_name] = scale
                if not is_site and visual_shape_cfg_for_prim.is_visible:
                    bodies_with_visual_shapes.add(parent_body_id)
                if verbose:
                    print(f"Added visual shape {path_name} ({type_name}) with id {shape_id}.")

        if recurse:
            _load_visual_shape_children(parent_body_id, prim, body_xform, articulation_root_xform, allow_visual_shapes)

    def add_body(
        prim: Usd.Prim,
        xform: wp.transform,
        label: str,
        body_qd: wp.spatial_vector,
        articulation_root_xform: wp.transform | None = None,
        is_kinematic: bool = False,
    ) -> int:
        """Add a rigid body to the builder and optionally load its visual shapes and sites among the body prim's children. Returns the resulting body index."""
        # Extract custom attributes for this body
        body_custom_attrs = usd.get_custom_attribute_values(
            prim, builder_custom_attr_body, context={"builder": builder}
        )

        b = builder.add_link(
            xform=xform,
            label=label,
            is_kinematic=is_kinematic,
            custom_attributes=body_custom_attrs,
        )
        builder.body_qd[b] = body_qd
        path_body_map[label] = b
        if load_sites or load_visual_shapes:
            _load_visual_shape_children(b, prim, xform, articulation_root_xform, load_visual_shapes)
        return b

    def parse_body(
        rigid_body_desc: UsdPhysics.RigidBodyDesc,
        prim: Usd.Prim,
        incoming_xform: wp.transform | None = None,
        add_body_to_builder: bool = True,
        articulation_root_xform: wp.transform | None = None,
        *,
        origin: wp.transform | None = None,
    ) -> int | dict[str, Any]:
        """Parses a rigid body description.
        If `add_body_to_builder` is True, adds it to the builder and returns the resulting body index.
        Otherwise returns deferred arguments for the local `add_body` helper."""
        nonlocal path_body_map
        nonlocal physics_scene_prim

        if not rigid_body_desc.rigidBodyEnabled and only_load_enabled_rigid_bodies:
            return -1

        if origin is None:
            rot = rigid_body_desc.rotation
            origin = wp.transform(rigid_body_desc.position, usd.value_to_warp(rot))
            if incoming_xform is not None:
                origin = wp.mul(incoming_xform, origin)
        path = str(prim.GetPath())
        _warn_mirrored_body_transform(prim, path, xform_cache)

        is_kinematic = rigid_body_desc.kinematicBody
        linear_velocity = wp.transform_vector(origin, wp.vec3(*rigid_body_desc.linearVelocity))
        angular_velocity = wp.transform_vector(
            origin,
            DegreesToRadian * wp.vec3(*rigid_body_desc.angularVelocity),
        )
        body_qd = wp.spatial_vector(*linear_velocity, *angular_velocity)

        if add_body_to_builder:
            return add_body(
                prim,
                origin,
                path,
                articulation_root_xform=articulation_root_xform,
                is_kinematic=is_kinematic,
                body_qd=body_qd,
            )
        else:
            result = {
                "prim": prim,
                "xform": origin,
                "label": path,
                "is_kinematic": is_kinematic,
                "body_qd": body_qd,
            }
            if articulation_root_xform is not None:
                result["articulation_root_xform"] = articulation_root_xform
            return result

    # Forward current values: scene settings and custom attributes are populated
    # below, after these functions are defined.
    def resolve_joint_parent_child(
        joint_desc: UsdPhysics.JointDesc,
        body_index_map: dict[str, int],
        get_transforms: bool = True,
    ):
        """Pass the current importer values to the joint parser."""
        return _joints.resolve_joint_parent_child(
            joint_desc,
            body_index_map,
            get_transforms,
            verbose=verbose,
        )

    def parse_joint(
        joint_desc: UsdPhysics.JointDesc,
        incoming_xform: wp.transform | None = None,
    ) -> int | None:
        """Pass the current importer values to the joint parser."""
        return _joints.parse_joint(
            joint_desc,
            incoming_xform,
            builder=builder,
            stage=stage,
            R=R,
            joint_properties=joint_properties,
            path_body_map=path_body_map,
            path_joint_map=path_joint_map,
            builder_custom_attr_joint=builder_custom_attr_joint,
            physics_scene_prim=physics_scene_prim,
            usd_axis_to_axis=usd_axis_to_axis,
            DegreesToRadian=DegreesToRadian,
            default_joint_armature=default_joint_armature,
            default_joint_friction=default_joint_friction,
            default_joint_limit_ke=default_joint_limit_ke,
            default_joint_limit_kd=default_joint_limit_kd,
            default_joint_velocity_limit=default_joint_velocity_limit,
            joint_drive_gains_scaling=joint_drive_gains_scaling,
            force_position_velocity_actuation=force_position_velocity_actuation,
            only_load_enabled_joints=only_load_enabled_joints,
            collect_schema_attrs=collect_schema_attrs,
            verbose=verbose,
            solreflimit_mode_key=solreflimit_mode_key,
            solreflimit_gain_baseline_key=solreflimit_gain_baseline_key,
            _should_write_solreflimit_mode=_should_write_solreflimit_mode,
            _should_write_solreflimit_gain_baseline=_should_write_solreflimit_gain_baseline,
            resolve_joint_parent_child=resolve_joint_parent_child,
        )

    def parse_merged_joints(
        joint_paths: list[str],
        incoming_xform: wp.transform | None = None,
    ) -> int | None:
        """Pass the current importer values to the joint parser."""
        return _joints.parse_merged_joints(
            joint_paths,
            incoming_xform,
            builder=builder,
            stage=stage,
            R=R,
            joint_properties=joint_properties,
            joint_descriptions=joint_descriptions,
            path_body_map=path_body_map,
            path_joint_map=path_joint_map,
            merged_dof_offset=merged_dof_offset,
            builder_custom_attr_joint=builder_custom_attr_joint,
            physics_scene_prim=physics_scene_prim,
            usd_axis_to_axis=usd_axis_to_axis,
            default_joint_velocity_limit=default_joint_velocity_limit,
            joint_drive_gains_scaling=joint_drive_gains_scaling,
            force_position_velocity_actuation=force_position_velocity_actuation,
            only_load_enabled_joints=only_load_enabled_joints,
            collect_schema_attrs=collect_schema_attrs,
            verbose=verbose,
            solreflimit_mode_key=solreflimit_mode_key,
            solreflimit_gain_baseline_key=solreflimit_gain_baseline_key,
            _should_write_solreflimit_mode=_should_write_solreflimit_mode,
            _should_write_solreflimit_gain_baseline=_should_write_solreflimit_gain_baseline,
            resolve_joint_parent_child=resolve_joint_parent_child,
        )

    # Looking for and parsing the attributes on PhysicsScene prims
    scene_attributes = {}
    scene_gravity_direction = None
    scene_gravity_magnitude = None
    gravity_enabled = True
    if physics_scene_prim is not None:
        paths, scene_descs = ret_dict[UsdPhysics.ObjectType.Scene]
        if len(paths) > 1 and verbose:
            print("Only the first PhysicsScene is considered")
        scene_path = physics_scene_prim.GetPath()
        scene_desc = next(desc for path, desc in zip(paths, scene_descs, strict=True) if path == scene_path)
        if verbose:
            print("Found PhysicsScene:", scene_path)
            print("Gravity direction:", scene_desc.gravityDirection)
            print("Gravity magnitude:", scene_desc.gravityMagnitude)
        scene_gravity_direction = scene_desc.gravityDirection
        scene_gravity_magnitude = scene_desc.gravityMagnitude

        # Storing Physics Scene attributes
        for a in physics_scene_prim.GetAttributes():
            scene_attributes[a.GetName()] = a.Get()

        # Parse custom attribute declarations from PhysicsScene prim
        # This must happen before processing any other prims
        declarations = usd.get_custom_attribute_declarations(physics_scene_prim)
        for attr in declarations.values():
            builder.add_custom_attribute(attr)

        # Updating joint_drive_gains_scaling if set of the PhysicsScene
        joint_drive_gains_scaling = usd.get_float(
            physics_scene_prim, "newton:joint_drive_gains_scaling", joint_drive_gains_scaling
        )

        time_steps_per_second = R.get_value(
            physics_scene_prim, prim_type=PrimType.SCENE, key="time_steps_per_second", default=1000, verbose=verbose
        )
        physics_dt = (1.0 / time_steps_per_second) if time_steps_per_second > 0 else 0.001

        gravity_enabled = R.get_value(
            physics_scene_prim, prim_type=PrimType.SCENE, key="gravity_enabled", default=True, verbose=verbose
        )
        max_solver_iters = R.get_value(
            physics_scene_prim, prim_type=PrimType.SCENE, key="max_solver_iterations", default=None, verbose=verbose
        )

    stage_up_axis = Axis.from_string(str(UsdGeom.GetStageUpAxis(stage)))

    if apply_up_axis_from_stage:
        builder.up_axis = stage_up_axis
        axis_xform = wp.transform_identity()
        if verbose:
            print(f"Using stage up axis {stage_up_axis} as builder up axis")
    else:
        axis_xform = wp.transform(wp.vec3(0.0), quat_between_axes(stage_up_axis, builder.up_axis))
        if verbose:
            print(f"Rotating stage to align its up axis {stage_up_axis} with builder up axis {builder.up_axis}")
    if override_root_xform and xform is None:
        raise ValueError("override_root_xform=True requires xform to be set")

    if xform is None:
        incoming_world_xform = axis_xform
    else:
        incoming_world_xform = wp.transform(*xform) * axis_xform

    if scene_gravity_direction is not None:
        gravity_direction = wp.vec3(*scene_gravity_direction)
        direction_length = wp.length(gravity_direction)
        if direction_length > 0.0:
            gravity_direction /= direction_length
        else:
            gravity_direction = -stage_up_axis.to_vec3()
        gravity_xform = axis_xform if override_root_xform else incoming_world_xform
        gravity_direction = wp.transform_vector(gravity_xform, gravity_direction)
        gravity_vector = gravity_direction * scene_gravity_magnitude if gravity_enabled else wp.vec3()
        if builder.current_world >= 0:
            builder.world_gravity[builder.current_world] = gravity_vector
        else:
            builder.gravity = gravity_vector

    resolved_mpm_gravity = None

    def _preflight_mpm_scene(scene_prim: Usd.Prim) -> None:
        """Resolve MPM scene gravity before particle insertion can mutate the builder."""
        nonlocal resolved_mpm_gravity

        scene_path = str(scene_prim.GetPath())
        mpm_scene = UsdPhysics.Scene(scene_prim)
        raw_direction = mpm_scene.GetGravityDirectionAttr().Get()
        direction_array = np.asarray(raw_direction if raw_direction is not None else (0.0, 0.0, 0.0), dtype=float)
        if direction_array.shape != (3,) or not np.isfinite(direction_array).all():
            raise ValueError(
                f"{scene_path}: physics:gravityDirection must contain three finite values, got {raw_direction!r}."
            )
        direction_length = float(np.linalg.norm(direction_array))
        if direction_length > 0.0:
            direction_array /= direction_length
        else:
            direction_array = -np.asarray(stage_up_axis.to_vec3(), dtype=float)

        raw_magnitude = mpm_scene.GetGravityMagnitudeAttr().Get()
        try:
            raw_magnitude = float(raw_magnitude)
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"{scene_path}: physics:gravityMagnitude must be a number, got {raw_magnitude!r}."
            ) from error
        if math.isnan(raw_magnitude) or raw_magnitude == float("inf"):
            raise ValueError(
                f"{scene_path}: physics:gravityMagnitude must be finite or negative for Earth gravity, "
                f"got {raw_magnitude!r}."
            )
        if raw_magnitude < 0.0:
            magnitude_si = 9.81
        else:
            with np.errstate(invalid="ignore", over="ignore", under="ignore"):
                magnitude_si = float(np.float64(raw_magnitude) * np.float64(linear_unit))
            if not math.isfinite(magnitude_si) or (raw_magnitude != 0.0 and magnitude_si == 0.0):
                raise ValueError(
                    f"{scene_path}: physics:gravityMagnitude does not convert to a finite, representable SI value."
                )

        mpm_gravity_enabled = R.get_value(
            scene_prim, prim_type=PrimType.SCENE, key="gravity_enabled", default=True, verbose=verbose
        )
        gravity_xform = axis_xform if override_root_xform else incoming_world_xform
        direction = wp.transform_vector(gravity_xform, wp.vec3(*direction_array))
        gravity = direction * magnitude_si if mpm_gravity_enabled else wp.vec3()
        if not np.isfinite(np.asarray(gravity, dtype=float)).all():
            raise ValueError(f"{scene_path}: transformed gravity must contain only finite SI values.")
        resolved_mpm_gravity = gravity

    path_particle_map, particle_scene_prim = import_particles(
        builder,
        root_prim,
        ignore_paths=ignore_paths,
        xform_cache=xform_cache,
        incoming_world_mat=_xform_to_mat44(incoming_world_xform),
        linear_unit=linear_unit,
        mass_unit=mass_unit,
        scene_preflight=_preflight_mpm_scene,
        particle_prims=particle_prims,
    )
    if particle_scene_prim is not None:
        if resolved_mpm_gravity is None:
            raise RuntimeError("Particle scene preflight did not resolve gravity.")
        if builder.current_world >= 0:
            builder.world_gravity[builder.current_world] = resolved_mpm_gravity
        else:
            builder.gravity = resolved_mpm_gravity
    if verbose:
        print(
            f"Scaling PD gains by (joint_drive_gains_scaling / DegreesToRadian) = {joint_drive_gains_scaling / DegreesToRadian}, default scale for joint_drive_gains_scaling=1 is 1.0/DegreesToRadian = {1.0 / DegreesToRadian}"
        )

    # Process custom attributes defined for different kinds of prim.
    # Note that at this time we may have more custom attributes than before since they may have been
    # declared on the PhysicsScene prim.
    builder_custom_attr_shape: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.SHAPE]
    )
    builder_custom_attr_body: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.BODY]
    )
    builder_custom_attr_joint: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.JOINT, AttributeFrequency.JOINT_DOF, AttributeFrequency.JOINT_COORD]
    )
    _register_equality_constraint_attributes(builder)
    builder_custom_attr_eq: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        ["mujoco:equality_constraint"]
    )
    builder_custom_attr_articulation: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.ARTICULATION]
    )

    if physics_scene_prim is not None:
        # Collect schema-defined attributes from the scene prim for inspection (e.g., mjc:* attributes)
        if collect_schema_attrs:
            R.collect_prim_attrs(physics_scene_prim)

        # Extract custom attributes for model (ONCE and WORLD frequency) from the PhysicsScene prim
        # WORLD frequency attributes use index 0 here; they get remapped during add_world()
        builder_custom_attr_model: list[ModelBuilder.CustomAttribute] = [
            attr
            for attr in builder.custom_attributes.values()
            if attr.frequency in (AttributeFrequency.ONCE, AttributeFrequency.WORLD)
        ]

        # Filter out MuJoCo attributes if parse_mujoco_options is False
        if not parse_mujoco_options:
            builder_custom_attr_model = [attr for attr in builder_custom_attr_model if attr.namespace != "mujoco"]

        # Read custom attribute values from the PhysicsScene prim
        scene_custom_attrs = usd.get_custom_attribute_values(
            physics_scene_prim, builder_custom_attr_model, context={"builder": builder}
        )
        scene_attributes.update(scene_custom_attrs)

        # Set values on builder's custom attributes
        for key, value in scene_custom_attrs.items():
            if key in builder.custom_attributes:
                builder.custom_attributes[key].values[0] = value

    joint_descriptions = {}
    # stores physics spec for every RigidBody in the selected range
    body_specs = {}
    # set of prim paths of rigid bodies that are ignored
    # (to avoid repeated regex evaluations)
    ignored_body_paths = set()
    material_specs = {}

    # TODO: uniform interface for iterating
    def data_for_key(physics_utils_results, key):
        if key not in physics_utils_results:
            return
        if verbose:
            print(physics_utils_results[key])

        yield from zip(*physics_utils_results[key], strict=False)

    # Setting up the default material
    material_specs[""] = default_material

    def warn_invalid_desc(path, descriptor) -> bool:
        if not descriptor.isValid:
            warnings.warn(
                f'Warning: Invalid {type(descriptor).__name__} descriptor for prim at path "{path}".',
                stacklevel=2,
            )
            return True
        return False

    # Parsing physics materials from the stage
    for sdf_path, desc in data_for_key(ret_dict, UsdPhysics.ObjectType.RigidBodyMaterial):
        if warn_invalid_desc(sdf_path, desc):
            continue
        prim = stage.GetPrimAtPath(sdf_path)

        material_specs[str(sdf_path)] = _resolve_physics_material(
            prim, desc, R, builder.default_shape_cfg, default_shape_density=default_shape_density, verbose=verbose
        )

    if UsdPhysics.ObjectType.RigidBody in ret_dict:
        prim_paths, rigid_body_descs = ret_dict[UsdPhysics.ObjectType.RigidBody]
        for prim_path, rigid_body_desc in zip(prim_paths, rigid_body_descs, strict=False):
            if warn_invalid_desc(prim_path, rigid_body_desc):
                continue
            body_path = str(prim_path)
            if any(re.match(p, body_path) for p in ignore_paths):
                ignored_body_paths.add(body_path)
                continue
            body_specs[body_path] = rigid_body_desc
            prim = stage.GetPrimAtPath(prim_path)

    # Bodies that need ComputeMassProperties fallback (no MassAPI, or missing mass, inertia, or CoM).
    bodies_requiring_mass_properties_fallback = mass_properties.bodies_requiring_mass_properties_fallback
    if UsdPhysics.ObjectType.RigidBody in ret_dict:
        prim_paths, rigid_body_descs = ret_dict[UsdPhysics.ObjectType.RigidBody]
        for prim_path, rigid_body_desc in zip(prim_paths, rigid_body_descs, strict=False):
            if warn_invalid_desc(prim_path, rigid_body_desc):
                continue
            body_path = str(prim_path)
            if body_path in ignored_body_paths:
                continue

            prim = stage.GetPrimAtPath(prim_path)
            mass_api = UsdPhysics.MassAPI(prim)
            if not mass_api:
                # Shape insertion already accumulates material/default density.
                # This fallback is only needed for enabled descendant MassAPI overrides.
                descendants = iter(Usd.PrimRange(prim, Usd.TraverseInstanceProxies()))
                for descendant in descendants:
                    if descendant != prim and descendant.HasAPI(UsdPhysics.RigidBodyAPI):
                        descendants.PruneChildren()
                        continue
                    if _is_enabled_collider(descendant) and descendant.HasAPI(UsdPhysics.MassAPI):
                        bodies_requiring_mass_properties_fallback.add(body_path)
                        break
                continue

            has_effective_mass = mass_properties.effective_mass(mass_api) is not None
            has_effective_inertia = mass_properties.effective_diag_inertia(mass_api) is not None
            has_effective_com = mass_properties.effective_com(mass_api) is not None
            if not (has_effective_mass and has_effective_inertia and has_effective_com):
                bodies_requiring_mass_properties_fallback.add(body_path)

    # Collect joint descriptions regardless of whether articulations are authored.
    for key, value in ret_dict.items():
        if key in {
            UsdPhysics.ObjectType.FixedJoint,
            UsdPhysics.ObjectType.RevoluteJoint,
            UsdPhysics.ObjectType.PrismaticJoint,
            UsdPhysics.ObjectType.SphericalJoint,
            UsdPhysics.ObjectType.D6Joint,
            UsdPhysics.ObjectType.DistanceJoint,
        }:
            paths, joint_specs = value
            for path, joint_spec in zip(paths, joint_specs, strict=False):
                joint_descriptions[str(path)] = joint_spec

    mjc_equality_connect_paths: set[str] = set()
    mjc_equality_weld_paths: set[str] = set()
    for joint_path in joint_descriptions:
        joint_prim = stage.GetPrimAtPath(joint_path)
        if _has_api_schema(joint_prim, "MjcEqualityConnectAPI"):
            mjc_equality_connect_paths.add(joint_path)
        if _has_api_schema(joint_prim, "MjcEqualityWeldAPI"):
            mjc_equality_weld_paths.add(joint_path)
    mjc_equality_connect_or_weld_paths = mjc_equality_connect_paths | mjc_equality_weld_paths

    # Track which joints have been processed during articulation parsing.
    # This allows us to parse orphan joints (joints not included in any articulation)
    # even when articulations are present in the USD.
    processed_joints: set[str] = set()
    excluded_articulation_joints: dict[str, wp.transform] = {}

    cable_attachments_by_body: dict[str, list[_CableAttachmentCandidate]] = {}
    if _deformable_prims.cables and _deformable_prims.attachments:
        cable_topology: dict[str, tuple[int, bool]] = {}
        cable_prims_by_path: dict[str, Usd.Prim] = {}
        for cable_prim in _deformable_prims.cables:
            curves = UsdGeom.BasisCurves(cable_prim)
            vertex_counts = curves.GetCurveVertexCountsAttr().Get() or []
            if len(vertex_counts) != 1:
                continue
            cable_path = str(cable_prim.GetPath())
            cable_prims_by_path[cable_path] = cable_prim
            cable_topology[cable_path] = (
                int(vertex_counts[0]),
                curves.GetWrapAttr().Get() == UsdGeom.Tokens.periodic,
            )

        attachments_by_cable: dict[str, list[Usd.Prim]] = {}
        attachment_count_by_cable: dict[str, int] = {}
        for attachment_prim in _deformable_prims.attachments:
            enabled = deformable_read(attachment_prim, "attachmentEnabled")
            if enabled is not None and not bool(enabled):
                continue
            cable_path = _get_first_target(attachment_prim, "physics:src0")
            if cable_path in cable_topology:
                attachments_by_cable.setdefault(cable_path, []).append(attachment_prim)
            other_path = _get_first_target(attachment_prim, "physics:src1")
            for attached_cable_path in {cable_path, other_path}.intersection(cable_topology):
                attachment_count_by_cable[attached_cable_path] = (
                    attachment_count_by_cable.get(attached_cable_path, 0) + 1
                )

        for cable_path, attachment_prims in attachments_by_cable.items():
            if len(attachment_prims) != 1 or attachment_count_by_cable.get(cable_path) != 1:
                continue
            attachment_prim = attachment_prims[0]
            point_count, closed = cable_topology[cable_path]
            if _read_cable_attachment_endpoint(attachment_prim, deformable_read, point_count, closed) is None:
                continue
            target_path = _get_first_target(attachment_prim, "physics:src1")
            if target_path in ("", "/"):
                continue
            target_prim = stage.GetPrimAtPath(target_path)
            if not target_prim or not target_prim.IsValid():
                continue
            current_prim = target_prim
            while current_prim and current_prim.IsValid():
                current_path = str(current_prim.GetPath())
                if current_path in body_specs:
                    cable_attachments_by_body.setdefault(current_path, []).append(
                        _CableAttachmentCandidate(
                            cable_prim=cable_prims_by_path[cable_path],
                            attachment_prim=attachment_prim,
                            point_count=point_count,
                            closed=closed,
                            target_path=target_path,
                        )
                    )
                    break
                current_prim = current_prim.GetParent()

    _deformable_ctx = _DeformableImportContext(
        builder=builder,
        stage=stage,
        root_prim=root_prim,
        resolver=R,
        material_specs=material_specs,
        collect_schema_attrs=collect_schema_attrs,
        deformable_read=deformable_read,
        get_prim_world_mat=_get_prim_world_mat,
        get_rigid_body_ancestor_path=_get_rigid_body_ancestor_path,
        get_first_target=_get_first_target,
        get_tetmesh_cached=_get_tetmesh_cached,
        incoming_world_xform=incoming_world_xform,
        linear_unit=linear_unit,
        ignore_paths=ignore_paths,
        verbose=verbose,
        path_body_map=path_body_map,
        path_shape_map=path_shape_map,
        path_cable_map=path_cable_map,
        path_cable_attrs=path_cable_attrs,
        path_cable_segments=path_cable_segments,
        path_cable_point_anchors=path_cable_point_anchors,
        path_cloth_map=path_cloth_map,
        path_cloth_attrs=path_cloth_attrs,
        path_soft_map=path_soft_map,
        path_soft_attrs=path_soft_attrs,
        path_attachment_map=path_attachment_map,
        path_attachment_attrs=path_attachment_attrs,
        prims=_deformable_prims,
    )

    def import_attached_cables(body_paths) -> None:
        """Import each eligible cable immediately after the articulation containing its target body."""
        if not cable_attachments_by_body or not builder.articulation_count:
            return
        candidates = [
            candidate for body_path in body_paths for candidate in cable_attachments_by_body.pop(body_path, ())
        ]
        if not candidates:
            return
        articulation = builder.articulation_count - 1
        latest_body_ids: set[int] = set()
        for joint in range(builder.articulation_start[articulation], builder.articulation_end[articulation]):
            latest_body_ids.add(builder.joint_child[joint])
            if builder.joint_parent[joint] >= 0:
                latest_body_ids.add(builder.joint_parent[joint])

        roots = {}
        cable_prims = []
        for candidate in candidates:
            root = _read_cable_articulation_root(
                _deformable_ctx,
                candidate.attachment_prim,
                candidate.point_count,
                candidate.closed,
                candidate.target_path,
                latest_body_ids,
            )
            if root is not None:
                cable_path = str(candidate.cable_prim.GetPath())
                roots[cable_path] = root
                cable_prims.append(candidate.cable_prim)
        if not roots:
            return
        _deformable_import_cable(_deformable_ctx, set(), roots, cable_prims=cable_prims)

    authored_articulation_root_paths = [
        str(prim.GetPath())
        for prim in Usd.PrimRange(stage.GetPrimAtPath(root_path), Usd.TraverseInstanceProxies())
        if prim.HasAPI(UsdPhysics.ArticulationRootAPI)
    ]
    authored_articulation_root_paths.sort(key=len, reverse=True)

    # maps from articulation_id to bool indicating if self-collisions are enabled
    articulation_has_self_collision = {}

    if UsdPhysics.ObjectType.Articulation in ret_dict:
        paths, articulation_descs = ret_dict[UsdPhysics.ObjectType.Articulation]

        articulation_entries = list(zip(paths, articulation_descs, strict=False))

        _parse_articulations(
            builder,
            stage,
            articulation_entries,
            R=R,
            xform_cache=xform_cache,
            body_specs=body_specs,
            joint_descriptions=joint_descriptions,
            ignored_body_paths=ignored_body_paths,
            mjc_equality_connect_or_weld_paths=mjc_equality_connect_or_weld_paths,
            path_body_map=path_body_map,
            processed_joints=processed_joints,
            excluded_articulation_joints=excluded_articulation_joints,
            articulation_has_self_collision=articulation_has_self_collision,
            builder_custom_attr_articulation=builder_custom_attr_articulation,
            incoming_world_xform=incoming_world_xform,
            override_root_xform=override_root_xform,
            bodies_follow_joint_ordering=bodies_follow_joint_ordering,
            joint_ordering=joint_ordering,
            parent_body=parent_body,
            floating=floating,
            base_joint=base_joint,
            enable_self_collisions=enable_self_collisions,
            ignore_paths=ignore_paths,
            collect_schema_attrs=collect_schema_attrs,
            verbose=verbose,
            warn_invalid_desc=warn_invalid_desc,
            parse_body=parse_body,
            add_body=add_body,
            resolve_joint_parent_child=resolve_joint_parent_child,
            parse_joint=parse_joint,
            parse_merged_joints=parse_merged_joints,
            import_attached_cables=import_attached_cables,
        )
    no_articulations = UsdPhysics.ObjectType.Articulation not in ret_dict
    has_joints = any(
        (
            not (only_load_enabled_joints and not joint_desc.jointEnabled)
            and not any(re.match(p, joint_path) for p in ignore_paths)
            and str(joint_desc.body0) not in ignored_body_paths
            and str(joint_desc.body1) not in ignored_body_paths
            and joint_path not in mjc_equality_connect_or_weld_paths
        )
        for joint_path, joint_desc in joint_descriptions.items()
    )

    # insert remaining bodies that were not part of any articulation so far
    # (root joints for these bodies will be added after mass properties are resolved)
    for path, rigid_body_desc in body_specs.items():
        key = str(path)
        body_id: int = parse_body(  # pyright: ignore[reportAssignmentType]
            rigid_body_desc,
            stage.GetPrimAtPath(path),
            incoming_xform=incoming_world_xform,
            add_body_to_builder=True,
        )

    # Parse orphan joints: joints that exist in the USD but were not included in any articulation.
    # This can happen when:
    # 1. No articulations are defined in the USD (no_articulations == True)
    # 2. A joint connects bodies that are not under any PhysicsArticulationRootAPI
    orphan_joints_by_body_pair: dict[tuple[str, str], list[str]] = {}
    for joint_path, joint_desc in joint_descriptions.items():
        # Earlier passes already own articulation and equality joints.
        if joint_path in processed_joints:
            continue
        if joint_path in mjc_equality_connect_or_weld_paths:
            if verbose:
                print(f"Skipping equality connect/weld joint '{joint_path}' from orphan joint parsing")
            continue

        # Apply the importer filters before grouping the remaining candidates.
        if only_load_enabled_joints and not joint_desc.jointEnabled:
            continue
        if any(re.match(p, joint_path) for p in ignore_paths):
            continue
        if str(joint_desc.body0) in ignored_body_paths or str(joint_desc.body1) in ignored_body_paths:
            continue

        # Shared endpoints identify joints that may form one compound joint.
        body_pair = (str(joint_desc.body0), str(joint_desc.body1))
        orphan_joints_by_body_pair.setdefault(body_pair, []).append(joint_path)

    # A multi-axis D6 joint may be authored as stacked 1-DOF joints between the same bodies.
    mergeable_joint_types = {UsdPhysics.ObjectType.RevoluteJoint, UsdPhysics.ObjectType.PrismaticJoint}
    orphan_joint_groups: list[list[str]] = []
    for joint_group in orphan_joints_by_body_pair.values():
        if len(joint_group) > 1 and all(
            joint_descriptions[joint_path].type in mergeable_joint_types for joint_path in joint_group
        ):
            orphan_joint_groups.append(joint_group)
        else:
            # Normalize non-mergeable joints to singleton groups for the parsing pass below.
            orphan_joint_groups.extend([[joint_path] for joint_path in joint_group])

    for joint_group in orphan_joint_groups:
        # All members of a merged group share these endpoints, so the first is representative.
        joint_path = joint_group[0]
        joint_desc = joint_descriptions[joint_path]
        body0_path = str(joint_desc.body0)
        body1_path = str(joint_desc.body1)
        # World-connected joints need a reconstructed parent frame before they can be parsed.
        is_body_to_world = body0_path in ("", "/") or body1_path in ("", "/")
        try:
            # Body-to-world joints (the world side may be body0 or body1) have no
            # world-side prim to inherit a frame from, and authoring tools often
            # write the world-side localPose relative to a USD ancestor Xform
            # instead of in world coords. Recover the missing world-side frame from
            # the child body's world pose and the joint local poses so the joint
            # chain FK reproduces the imported child world pose:
            #   world_body = child_world * child_tf * inv(parent_tf)
            # The world-side localPose cancels, so the joint anchors at the
            # USD-authored child body pose however that pose was authored.
            orphan_incoming_xform = incoming_world_xform
            if is_body_to_world:
                _, _, parent_tf_o, child_tf_o = resolve_joint_parent_child(  # pyright: ignore[reportAssignmentType]
                    joint_desc, path_body_map, get_transforms=True
                )
                child_path_o = body1_path if body0_path in ("", "/") else body0_path
                child_prim_o = stage.GetPrimAtPath(child_path_o) if child_path_o else None
                if (
                    parent_tf_o is not None
                    and child_tf_o is not None
                    and child_prim_o is not None
                    and child_prim_o.IsValid()
                ):
                    child_world_xform_o = usd.get_transform(child_prim_o, local=False, xform_cache=xform_cache)
                    world_body_xform_o = child_world_xform_o * child_tf_o * wp.transform_inverse(parent_tf_o)
                    orphan_incoming_xform = incoming_world_xform * world_body_xform_o
            if len(joint_group) > 1:
                parse_merged_joints(joint_group, incoming_xform=orphan_incoming_xform)
            else:
                parse_joint(joint_desc, incoming_xform=orphan_incoming_xform)
        except ValueError as exc:
            if verbose:
                print(f"Skipping joint group {joint_group}: {exc}")

    # parse shapes attached to the rigid bodies
    # Canonicalized (sorted) USD path pairs from physics:filteredPairs. Collected from native
    # colliders and deformable participants, applied only after deformable lowering so every
    # endpoint's Newton shapes exist (a cable maps to several capsule shapes created late).
    authored_filtered_path_pairs: set[tuple[str, str]] = set()

    # The import scout collected supported visual leaf candidates during its existing
    # instance-proxy walk. Body visuals were already loaded by add_body(), so only untouched
    # static candidates need geometry/material work here.
    if load_visual_shapes and load_static_visual_shapes:
        rigid_body_paths = {str(path) for path in ret_dict.get(UsdPhysics.ObjectType.RigidBody, ((), ()))[0]}

        def _is_in_rigid_body_hierarchy(path: str) -> bool:
            while path:
                if path in rigid_body_paths:
                    return True
                path = path.rpartition("/")[0]
            return False

        for prim in _deformable_prims.static_visuals:
            path = str(prim.GetPath())
            if path in deformable_visual_exclude_paths or path in path_shape_map or _is_in_rigid_body_hierarchy(path):
                continue
            _load_visual_shapes_impl(-1, prim, recurse=False)

    # OpenUSD groups are allow-by-default filters and cannot be represented by Newton's
    # equality-based collision group IDs, so their disabled pairs are lowered explicitly after
    # all rigid shapes exist. Preserve the builder default on every imported shape so callers can
    # still disable collisions with zero or a shared negative group.
    imported_rigid_collider_groups: dict[str, tuple[str, ...]] = {}

    _parse_colliders(
        builder=builder,
        stage=stage,
        xform_cache=xform_cache,
        ret_dict=ret_dict,
        R=R,
        visuals=visuals,
        mass_properties=mass_properties,
        material_specs=material_specs,
        default_shape_density=default_shape_density,
        path_body_map=path_body_map,
        path_shape_map=path_shape_map,
        path_shape_scale=path_shape_scale,
        builder_custom_attr_shape=builder_custom_attr_shape,
        bodies_with_visual_shapes=bodies_with_visual_shapes,
        incoming_world_xform=incoming_world_xform,
        usd_axis_to_axis=usd_axis_to_axis,
        imported_rigid_collider_groups=imported_rigid_collider_groups,
        ignore_paths=ignore_paths,
        load_visual_shapes=load_visual_shapes,
        hide_collision_shapes=hide_collision_shapes,
        force_show_colliders=force_show_colliders,
        mesh_maxhullvert=mesh_maxhullvert,
        skip_mesh_approximation=skip_mesh_approximation,
        collect_schema_attrs=collect_schema_attrs,
        legacy_margin_gap=legacy_margin_gap,
        verbose=verbose,
        warn_invalid_desc=warn_invalid_desc,
        authored_filtered_path_pairs=authored_filtered_path_pairs,
        _is_uniform_scale=_is_uniform_scale,
        _UNMATERIALED_VISUAL_COLOR=_UNMATERIALED_VISUAL_COLOR,
    )

    # Filtered pairs are applied after the deformable passes below, once every endpoint's
    # Newton shapes exist.

    mass_properties.zero_mass_information = mass_properties._create_zero_mass_information()

    # Resolve body inertial properties from authored values and collider aggregation.
    if UsdPhysics.ObjectType.RigidBody in ret_dict:
        paths, rigid_body_descs = ret_dict[UsdPhysics.ObjectType.RigidBody]
        for path, rigid_body_desc in zip(paths, rigid_body_descs, strict=False):
            prim = stage.GetPrimAtPath(path)
            mass_api = UsdPhysics.MassAPI(prim)
            body_path = str(path)
            if not mass_api and body_path not in bodies_requiring_mass_properties_fallback:
                continue
            body_id = path_body_map.get(body_path, -1)
            if body_id == -1:
                continue
            effective_mass = mass_properties.effective_mass(mass_api) if mass_api else None
            effective_density = mass_properties.effective_density(mass_api, warn_invalid=True) if mass_api else None
            effective_diag_inertia = mass_properties.effective_diag_inertia(mass_api) if mass_api else None
            effective_com = mass_properties.effective_com(mass_api) if mass_api else None
            has_effective_mass = effective_mass is not None
            has_effective_inertia = effective_diag_inertia is not None
            has_effective_com = effective_com is not None

            # newton:inertia (compact 6-element tensor) overrides physics:diagonalInertia + physics:principalAxes.
            inertia_tensor_val = (
                usd.get_attribute(prim, "newton:inertia") if usd.has_applied_api_schema(prim, "NewtonMassAPI") else None
            )
            has_inertia_tensor = inertia_tensor_val is not None
            if has_inertia_tensor:
                if len(inertia_tensor_val) != 6:
                    warnings.warn(
                        f"Body {body_path}: newton:inertia has {len(inertia_tensor_val)} elements, expected 6. Ignoring.",
                        stacklevel=2,
                    )
                    has_inertia_tensor = False
                elif not all(math.isfinite(v) for v in inertia_tensor_val):
                    warnings.warn(
                        f"Body {body_path}: newton:inertia contains non-finite values. Ignoring.",
                        stacklevel=2,
                    )
                    has_inertia_tensor = False
                elif any(v < 0.0 for v in inertia_tensor_val[:3]):
                    warnings.warn(
                        f"Body {body_path}: newton:inertia has negative diagonal elements. Ignoring.",
                        stacklevel=2,
                    )
                    has_inertia_tensor = False
                else:
                    ixx, iyy, izz, ixy, ixz, iyz = inertia_tensor_val
                    inertia_np = np.array([[ixx, ixy, ixz], [ixy, iyy, iyz], [ixz, iyz, izz]], dtype=np.float64)
                    if np.any(np.linalg.eigvalsh(inertia_np) < 0.0):
                        warnings.warn(
                            f"Body {body_path}: newton:inertia is not positive semidefinite. Ignoring.",
                            stacklevel=2,
                        )
                        has_inertia_tensor = False
                    else:
                        has_effective_inertia = True
                        inertia_tensor = wp.mat33(ixx, ixy, ixz, ixy, iyy, iyz, ixz, iyz, izz)

            # Compute baseline mass properties via mass computer when at least one property needs resolving.
            if not (has_effective_mass and has_effective_inertia and has_effective_com):
                rigid_body_api = UsdPhysics.RigidBodyAPI(prim)
                if mass_properties.requires_recorded_fallback(prim):
                    # Use recorded enabled colliders when OpenUSD cannot aggregate safely.
                    cmp_mass = -1.0
                else:
                    cmp_mass, cmp_i_diag, cmp_com, cmp_principal_axes = rigid_body_api.ComputeMassProperties(
                        mass_properties.get_collision_mass_information
                    )
                if cmp_mass < 0.0 or not math.isfinite(cmp_mass):
                    # ComputeMassProperties failed to discover colliders (e.g. shapes
                    # created by schema resolvers are not real USD prims) or aggregated
                    # non-finite authored values. Prefer the recorded callback payloads,
                    # which also cover colliders below instance proxies. Schema-resolved
                    # shapes without real prims fall back to builder-accumulated values.
                    recorded_properties = mass_properties.aggregate_recorded(
                        body_path, effective_density if not has_effective_mass else None
                    )
                    if recorded_properties is not None:
                        cmp_mass, recorded_inertia, cmp_com = recorded_properties
                        builder.body_inertia[body_id] = recorded_inertia
                        if np.array(recorded_inertia).any():
                            builder.body_inv_inertia[body_id] = wp.inverse(recorded_inertia)
                        else:
                            builder.body_inv_inertia[body_id] = wp.mat33(0.0)
                    else:
                        cmp_mass = builder.body_mass[body_id]
                        if not has_effective_com:
                            cmp_com = builder.body_com[body_id]
                        # When the body has an effective density, rescale accumulated mass
                        # and inertia from the builder's default shape density to the
                        # body-level density.
                        body_density = effective_density
                        if body_density is not None and not has_effective_mass and default_shape_density > 0.0:
                            density_scale = body_density / default_shape_density
                            cmp_mass *= density_scale
                            scaled_inertia = np.array(builder.body_inertia[body_id]) * density_scale
                            builder.body_inertia[body_id] = wp.mat33(scaled_inertia)
                            if scaled_inertia.any():
                                builder.body_inv_inertia[body_id] = wp.inverse(builder.body_inertia[body_id])
                            else:
                                builder.body_inv_inertia[body_id] = wp.mat33(0.0)
                    cmp_i_diag = Gf.Vec3f(0.0, 0.0, 0.0)
                    cmp_principal_axes = Gf.Quatf(1.0, 0.0, 0.0, 0.0)

            if has_effective_com:
                # Match the scale/frame convention used by OpenUSD's collider and joint descriptors.
                cmp_com = Gf.CompMult(effective_com, rigid_body_desc.scale)

            # Inertia: newton:inertia > physics:diagonalInertia + physics:principalAxes > mass computer.
            # When mass is authored but inertia is not, keep accumulated inertia
            # (scaled to match authored mass below) instead of using mass computer
            # inertia, which may already reflect the authored mass.
            if has_inertia_tensor:
                i_diag_np = None  # skip diagonal path; full matrix set below
            elif has_effective_inertia:
                i_diag_np = np.array(effective_diag_inertia, dtype=np.float32)
                principal_axes = mass_properties.effective_principal_axes(mass_api)
                if principal_axes is None:
                    principal_axes = Gf.Quatf(1.0, 0.0, 0.0, 0.0)
            elif not has_effective_mass:
                i_diag_np = np.array(cmp_i_diag, dtype=np.float32)
                principal_axes = cmp_principal_axes
            elif builder.body_mass[body_id] == 0.0 and np.all(np.isfinite(cmp_i_diag)) and min(cmp_i_diag) > 0.0:
                # No collider mass: use OpenUSD's small-sphere inertia, as PhysX does; its principal axes are undefined.
                i_diag_np = np.array(cmp_i_diag, dtype=np.float32)
                principal_axes = Gf.Quatf(1.0, 0.0, 0.0, 0.0)
            else:
                # Mass authored, inertia not: keep accumulated inertia and scale
                # to match authored mass in the mass block below.
                i_diag_np = None
            if has_inertia_tensor:
                builder.body_inertia[body_id] = inertia_tensor
                det = np.linalg.det(np.array(inertia_tensor).reshape(3, 3))
                if det > 0.0:
                    builder.body_inv_inertia[body_id] = wp.inverse(inertia_tensor)
                else:
                    builder.body_inv_inertia[body_id] = wp.mat33(0.0)
            elif i_diag_np is not None and np.linalg.norm(i_diag_np) > 0.0:
                i_rot = usd.value_to_warp(principal_axes)
                rot = np.array(wp.quat_to_matrix(i_rot), dtype=np.float32).reshape(3, 3)
                inertia = rot @ np.diag(i_diag_np) @ rot.T
                builder.body_inertia[body_id] = wp.mat33(inertia)
                if inertia.any():
                    builder.body_inv_inertia[body_id] = wp.inverse(wp.mat33(*inertia))
                else:
                    builder.body_inv_inertia[body_id] = wp.mat33(0.0)

            # Mass: effective authored value takes precedence over mass computer.
            if has_effective_mass:
                mass = effective_mass
                shape_accumulated_mass = builder.body_mass[body_id]
                if not has_effective_inertia and effective_density is not None:
                    warnings.warn(
                        f"Body {body_path}: authored mass and density without authored diagonalInertia. "
                        f"Ignoring body-level density.",
                        stacklevel=2,
                    )
                # When mass is authored but inertia is not, scale the accumulated
                # inertia to be consistent with the authored mass.
                if not has_effective_inertia and shape_accumulated_mass > 0.0 and mass > 0.0:
                    scale = mass / shape_accumulated_mass
                    builder.body_inertia[body_id] = wp.mat33(np.array(builder.body_inertia[body_id]) * scale)
                    builder.body_inv_inertia[body_id] = wp.inverse(builder.body_inertia[body_id])
            else:
                raw_mass = mass_api.GetMassAttr().Get() if mass_api else None
                if raw_mass is not None and raw_mass != 0.0:
                    warnings.warn(
                        f"Body {body_path}: authored mass is not positive and finite. "
                        "Falling back to mass-computer result.",
                        stacklevel=2,
                    )
                mass = cmp_mass
            builder.body_mass[body_id] = mass
            builder.body_inv_mass[body_id] = 1.0 / mass if mass > 0.0 else 0.0

            builder.body_com[body_id] = wp.vec3(*cmp_com)

            # Assign nonzero inertia if mass is nonzero to make sure the body can be simulated.
            I_m = np.array(builder.body_inertia[body_id])
            mass = builder.body_mass[body_id]
            if I_m.max() == 0.0:
                if mass > 0.0:
                    # Heuristic: assume a uniform density sphere with the given mass
                    # For a sphere: I = (2/5) * m * r^2
                    # Estimate radius from mass assuming reasonable density (e.g., water density ~1000 kg/m³)
                    # This gives r = (3*m/(4*π*p))^(1/3)
                    density = default_shape_density  # kg/m^3
                    volume = mass / density
                    radius = (3.0 * volume / (4.0 * np.pi)) ** (1.0 / 3.0)
                    _, _, I_default = compute_inertia_sphere(density, radius)

                    # Apply parallel axis theorem if center of mass is offset
                    com = np.array(builder.body_com[body_id], dtype=np.float32)
                    if np.linalg.norm(com) > 1e-6:
                        # I = I_cm + m * d² where d is distance from COM to body origin
                        d_squared = np.sum(com**2)
                        I_default += wp.mat33(mass * d_squared * np.eye(3, dtype=np.float32))

                    builder.body_inertia[body_id] = I_default
                    builder.body_inv_inertia[body_id] = wp.inverse(I_default)

                    if verbose:
                        print(
                            f"Applied default inertia matrix for body {body_path}: diagonal elements = [{I_default[0, 0]}, {I_default[1, 1]}, {I_default[2, 2]}]"
                        )
                elif mass_api:
                    warnings.warn(
                        f"Body {body_path} has zero mass and zero inertia despite having the MassAPI USD schema applied.",
                        stacklevel=2,
                    )

    # add joints to floating bodies (bodies not connected as children to any joint)
    new_bodies = list(path_body_map.values())
    if no_articulations and has_joints:
        # Preserve authored orphan-joint graphs while still articulating unrelated bodies (#3002).
        connected_bodies = set(builder.joint_parent) | set(builder.joint_child)
        bodies_to_articulate = [body_id for body_id in new_bodies if body_id not in connected_bodies]
    else:
        bodies_to_articulate = new_bodies

    def add_base_articulations(body_ids: list[int]) -> None:
        if not body_ids:
            return
        if parent_body != -1:
            # When parent_body is specified, manually add joints to floating bodies with correct parent
            joint_children = set(builder.joint_child)
            for body_id in body_ids:
                if body_id in joint_children:
                    continue  # Already has a joint
                if builder.body_mass[body_id] <= 0:
                    continue  # Skip static bodies
                # Compute parent_xform to preserve imported pose when attaching to parent_body
                # When parent_body is specified, use incoming_world_xform as parent-relative offset
                parent_xform = incoming_world_xform
                joint_id = builder._add_base_joint(
                    body_id,
                    floating=floating,
                    base_joint=base_joint,
                    parent=parent_body,
                    parent_xform=parent_xform,
                )
                # Attach to parent's articulation
                builder._finalize_imported_articulation(
                    joint_indices=[joint_id],
                    parent_body=parent_body,
                    articulation_label=None,
                )
                import_attached_cables([builder.body_label[body_id]])
        else:
            joint_children = set(builder.joint_child)
            for body_id in body_ids:
                if body_id in joint_children:
                    continue
                if builder.body_mass[body_id] <= 0:
                    continue

                joint_id = builder._add_base_joint(body_id, floating=floating, base_joint=base_joint)
                body_path = builder.body_label[body_id]
                articulation_root_path = next(
                    (
                        root
                        for root in authored_articulation_root_paths
                        if body_path == root or body_path.startswith("/" if root == "/" else f"{root}/")
                    ),
                    None,
                )
                if articulation_root_path is not None:
                    builder._finalize_imported_articulation(
                        joint_indices=[joint_id],
                        parent_body=parent_body,
                        articulation_label=articulation_root_path,
                    )
                else:
                    builder.add_articulation([joint_id], label=body_path)
                import_attached_cables([body_path])

    add_base_articulations(bodies_to_articulate)

    def initialize_free_joint_velocities() -> None:
        imported_bodies = set(path_body_map.values())
        for joint_id, joint_type in enumerate(builder.joint_type):
            if joint_type != JointType.FREE:
                continue
            child = builder.joint_child[joint_id]
            if child not in imported_bodies:
                continue

            child_qd = builder.body_qd[child]
            linear_velocity = wp.spatial_top(child_qd)
            angular_velocity = wp.spatial_bottom(child_qd)
            parent = builder.joint_parent[joint_id]
            parent_xform = builder.joint_X_p[joint_id]
            if parent >= 0:
                parent_xform = builder.body_q[parent] * parent_xform
                parent_qd = builder.body_qd[parent]
                parent_angular_velocity = wp.spatial_bottom(parent_qd)
                child_com = wp.transform_point(builder.body_q[child], builder.body_com[child])
                parent_com = wp.transform_point(builder.body_q[parent], builder.body_com[parent])
                parent_linear_velocity = wp.spatial_top(parent_qd) + wp.cross(
                    parent_angular_velocity, child_com - parent_com
                )
                linear_velocity -= parent_linear_velocity
                angular_velocity -= parent_angular_velocity

            parent_rotation = wp.transform_get_rotation(parent_xform)
            linear_velocity = wp.quat_rotate_inv(parent_rotation, linear_velocity)
            angular_velocity = wp.quat_rotate_inv(parent_rotation, angular_velocity)
            qd_start = builder.joint_qd_start[joint_id]
            builder.joint_qd[qd_start : qd_start + 6] = [*linear_velocity, *angular_velocity]

    # Build deformables without rigid articulation roots after rigid bodies and collider-mass
    # computation. Attached cables were created directly after their target articulation above.
    # Volume deformables (TetMesh -> soft body). PhysicsVolumeDeformableSimAPI (or a
    # PhysicsDeformableBodyAPI) opts into the mass precedence; a bare TetMesh stays legacy.
    # Mass precedence (proposal): per-point physics:masses > body mass > body density
    # > material density; per-element weighting is left to the add_* builders.
    if _deformable_prims.has_candidates():
        cables_in_shared_graphs: set[str] = set()
        attachments_in_shared_graphs: set[str] = set()
        cable_articulation_roots = {}
        if _deformable_prims.cables and _deformable_prims.attachments:
            (
                cables_in_shared_graphs,
                attachments_in_shared_graphs,
                cable_articulation_roots,
            ) = _deformable_prepare_cable_topology(_deformable_ctx)
        if _deformable_prims.cables:
            _deformable_import_cable(
                _deformable_ctx,
                cables_in_shared_graphs,
                cable_articulation_roots,
            )
        if _deformable_prims.cloth:
            _deformable_import_cloth(_deformable_ctx)
        if _deformable_prims.tetmeshes:
            _deformable_import_volume(_deformable_ctx)

        # PhysicsAttachment prims from the AOUSD deformables proposal. The current
        # builder can faithfully lower the cable/rod subset because imported cables
        # are rigid capsule bodies. Surface/volume attachments require a separate
        # deformable-site constraint model, so those are preserved as attrs and warned.
        if _deformable_prims.attachments:
            _deformable_import_attachments(_deformable_ctx, attachments_in_shared_graphs)

        # AOUSD PhysicsElementCollisionFilter prims: suppress collision between authored element
        # groups (cable segments / collider shapes); runs after the cables and colliders exist.
        if _deformable_prims.element_filters:
            _deformable_import_element_collision_filters(_deformable_ctx)

        # physics:filteredPairs may be authored on the deformable side: simulation geometry,
        # a deformable body prim, or a deformable-owned collider. Those prims are excluded
        # from the native collider loop, so collect their relationships here (the set
        # deduplicates prims reachable through more than one route).
        for _filter_prim in (*_deformable_prims.cables, *_deformable_prims.cloth, *_deformable_prims.tetmeshes):
            _collect_filtered_pairs(_filter_prim, authored_filtered_path_pairs)
        for _filter_path in (*_deformable_prims.body_owner, *_deformable_prims.native_physics_exclude_paths):
            _filter_prim = stage.GetPrimAtPath(_filter_path)
            if _filter_prim and _filter_prim.IsValid():
                _collect_filtered_pairs(_filter_prim, authored_filtered_path_pairs)

    for joint_path, root_xform in excluded_articulation_joints.items():
        joint_desc = joint_descriptions[joint_path]
        parent_id, _ = resolve_joint_parent_child(joint_desc, path_body_map, get_transforms=False)
        if parent_id == -1:
            parse_joint(joint_desc, incoming_xform=root_xform)
        else:
            parse_joint(joint_desc)

    # Filter only articulations created or extended by this import, including parent_body composition.
    imported_articulations = set(builder.joint_articulation[first_imported_joint:])
    imported_articulations.discard(-1)

    for articulation in sorted(imported_articulations):
        if articulation_has_self_collision.get(articulation, enable_self_collisions):
            continue
        bodies: set[int] = set()
        for joint in range(builder.articulation_start[articulation], builder.articulation_end[articulation]):
            parent = builder.joint_parent[joint]
            if parent >= 0:
                bodies.add(parent)
            bodies.add(builder.joint_child[joint])
        for body1, body2 in itertools.combinations(sorted(bodies), 2):
            for shape1 in builder.body_shapes[body1]:
                if not builder.shape_flags[shape1] & ShapeFlags.COLLIDE_SHAPES:
                    continue
                for shape2 in builder.body_shapes[body2]:
                    if not builder.shape_flags[shape2] & ShapeFlags.COLLIDE_SHAPES:
                        continue
                    builder.add_shape_collision_filter_pair(shape1, shape2)

    _apply_collision_groups(builder, stage, imported_rigid_collider_groups, path_shape_map)

    # physics:filteredPairs may also be authored on a rigid-body prim (UsdPhysics allows
    # collider, body, or articulation endpoints); the collider loop never visits body prims.
    # path_body_map covers every imported body regardless of which creation path added it.
    for body_prim_path in path_body_map:
        body_prim = stage.GetPrimAtPath(body_prim_path)
        if body_prim and body_prim.IsValid():
            _collect_filtered_pairs(body_prim, authored_filtered_path_pairs)

    _apply_filtered_pairs(
        builder,
        stage,
        authored_filtered_path_pairs,
        path_shape_map=path_shape_map,
        path_body_map=path_body_map,
        path_cable_map=path_cable_map,
        path_cloth_map=path_cloth_map,
        path_soft_map=path_soft_map,
        body_owner=_deformable_prims.body_owner,
    )

    def _resolve_newton_mimic(joint_prim: Usd.Prim) -> tuple[Sdf.Path | None, float, float]:
        """Resolve the mimic leader joint and coefficients from a follower joint prim.

        ``MjcEqualityJointAPI`` builds on ``NewtonMimicAPI``, so the equality and the plain
        mimic import paths read the same properties through here. The deprecated
        ``mjc:target``, ``mjc:coef0``, and ``mjc:coef1`` aliases are honored as a fallback
        for assets authored before those properties moved to the ``newton:`` namespace.

        ``newton:mimicCoef0`` is authored in the follower's position units, so a revolute
        follower is converted from degrees into the joint coordinates the constraint is
        evaluated in; the deprecated ``mjc:coef0`` is already in radians. ``coef1`` is
        dimensionless. A multi-DOF follower has no defined unit, so its offset is passed
        through unconverted and callers warn about it.

        Returns:
            The leader joint path, or ``None`` when no target is authored, followed by
            ``coef0`` in joint coordinates and the dimensionless ``coef1``.
        """
        mimic_rel = joint_prim.GetRelationship("newton:mimicJoint")
        targets = mimic_rel.GetTargets() if mimic_rel and mimic_rel.HasAuthoredTargets() else []
        if not targets:
            target_rel = joint_prim.GetRelationship("mjc:target")
            targets = target_rel.GetTargets() if target_rel else []

        leader_path = None
        if targets:
            leader_path = targets[0]
            if not leader_path.IsAbsolutePath():
                leader_path = joint_prim.GetPath().GetParentPath().AppendPath(leader_path)

        coef0 = usd.get_attribute(joint_prim, "newton:mimicCoef0")
        if coef0 is None:
            # The deprecated alias was always authored in radians, so it skips the conversion.
            coef0 = usd.get_attribute(joint_prim, "mjc:coef0", default=0.0)
        elif joint_prim.IsA(UsdPhysics.RevoluteJoint):
            coef0 *= DegreesToRadian
        coef1 = usd.get_attribute(joint_prim, "newton:mimicCoef1")
        if coef1 is None:
            coef1 = usd.get_attribute(joint_prim, "mjc:coef1", default=1.0)

        return leader_path, float(coef0), float(coef1)

    # Parse MjcEquality constraints *before* collapsing fixed joints so that the
    # builder's collapse logic can remap body/joint indices and adjust anchors/relposes
    # for any bodies that get merged.
    def _parse_mjc_equality_constraints():
        def add_converted_loop_joint(
            eq_type: EqType,
            body1: int,
            body2: int,
            anchor: wp.vec3,
            relpose: wp.transform | None,
            torquescale: float,
            joint_path: str,
            enabled: bool,
            custom_attrs: dict[str, Any],
        ) -> None:
            try:
                _, joint_idx = mjc_add_equality_loop_joint(
                    builder,
                    eq_type,
                    body1,
                    body2,
                    anchor,
                    relpose,
                    torquescale,
                    joint_path,
                    enabled,
                    custom_attrs,
                )
            except ValueError:
                warnings.warn(
                    f"MuJoCo equality '{joint_path}' has no valid body reference; skipping.",
                    stacklevel=2,
                )
                return

            path_joint_map[joint_path] = joint_idx

        for joint_path, joint_desc in joint_descriptions.items():
            joint_prim = stage.GetPrimAtPath(joint_path)
            if not joint_prim or not joint_prim.IsValid():
                continue
            if any(re.match(p, joint_path) for p in ignore_paths):
                continue

            is_connect = joint_path in mjc_equality_connect_paths
            is_weld = joint_path in mjc_equality_weld_paths
            is_eq_joint = _has_api_schema(joint_prim, "MjcEqualityJointAPI")
            if not (is_connect or is_weld or is_eq_joint):
                continue

            if only_load_enabled_joints and not joint_desc.jointEnabled:
                continue

            if collect_schema_attrs and (is_connect or is_weld):
                R.collect_prim_attrs(joint_prim)

            eq_custom_attrs = usd.get_custom_attribute_values(
                joint_prim, builder_custom_attr_eq, context={"builder": builder}
            )
            enabled = bool(joint_desc.jointEnabled)

            if is_connect or is_weld:
                schema_name = "MjcEqualityConnectAPI" if is_connect else "MjcEqualityWeldAPI"
                body0_info, body1_info = _resolve_equality_bodies(joint_prim, joint_path, schema_name)
                if body0_info is None or body1_info is None:
                    continue

                body0_idx, site0_local_pos = body0_info
                body1_idx, site1_local_pos = body1_info
                target0 = _get_first_target(joint_prim, "physics:body0")
                target1 = _get_first_target(joint_prim, "physics:body1")

                if is_connect:
                    # Use the authored localPose0 when target0 is a known body or the world
                    # (empty target means world); fall back to the site-derived local position
                    # only when target0 is a site prim that is not itself a body.
                    anchor = (
                        wp.vec3(*joint_desc.localPose0Position)
                        if (_is_world_target(target0) or target0 in path_body_map)
                        else site0_local_pos
                    )
                    if convert_mjc_equality_constraints:
                        add_converted_loop_joint(
                            EqType.CONNECT,
                            body0_idx,
                            body1_idx,
                            anchor,
                            None,
                            0.0,
                            joint_path,
                            enabled,
                            eq_custom_attrs,
                        )
                    else:
                        _add_equality_constraint(
                            builder,
                            constraint_type=EqType.CONNECT,
                            body1=body0_idx,
                            body2=body1_idx,
                            anchor=anchor,
                            label=joint_path,
                            enabled=enabled,
                            custom_attributes=eq_custom_attrs,
                        )
                else:
                    local_rot0 = usd.value_to_warp(joint_desc.localPose0Orientation)
                    local_rot1 = usd.value_to_warp(joint_desc.localPose1Orientation)
                    local_pos0 = wp.vec3(*joint_desc.localPose0Position)
                    local_pos1 = wp.vec3(*joint_desc.localPose1Position)
                    # MuJoCo weld anchors are authored on the body1 side. Direct
                    # body/world targets use localPose1; site targets use the site position.
                    anchor = (
                        wp.vec3(*joint_desc.localPose1Position)
                        if (_is_world_target(target1) or target1 in path_body_map)
                        else site1_local_pos
                    )
                    relpose_rot = local_rot0 * wp.quat_inverse(local_rot1)
                    relpose_pos = local_pos0 - wp.quat_rotate(relpose_rot, local_pos1)
                    torquescale_attr = joint_prim.GetAttribute("mjc:torqueScale")
                    torquescale = (
                        float(torquescale_attr.Get()) if torquescale_attr and torquescale_attr.HasValue() else 1.0
                    )
                    relpose = wp.transform(relpose_pos, relpose_rot)
                    if convert_mjc_equality_constraints:
                        add_converted_loop_joint(
                            EqType.WELD,
                            body0_idx,
                            body1_idx,
                            anchor,
                            relpose,
                            torquescale,
                            joint_path,
                            enabled,
                            eq_custom_attrs,
                        )
                    else:
                        _add_equality_constraint(
                            builder,
                            constraint_type=EqType.WELD,
                            body1=body0_idx,
                            body2=body1_idx,
                            anchor=anchor,
                            relpose=relpose,
                            torquescale=torquescale,
                            label=joint_path,
                            enabled=enabled,
                            custom_attributes=eq_custom_attrs,
                        )
                continue

            if is_eq_joint:
                joint1_idx = path_joint_map.get(joint_path)
                if joint1_idx is None:
                    warnings.warn(
                        f"MjcEqualityJointAPI on '{joint_path}' was not found in path_joint_map; skipping.",
                        stacklevel=2,
                    )
                    continue

                leader_path, coef0, coef1 = _resolve_newton_mimic(joint_prim)
                if leader_path is None:
                    warnings.warn(
                        f"MjcEqualityJointAPI on '{joint_path}' has no newton:mimicJoint relationship; skipping.",
                        stacklevel=2,
                    )
                    continue

                target_path = str(leader_path)
                joint2_idx = path_joint_map.get(target_path)
                if joint2_idx is None:
                    warnings.warn(
                        f"MjcEqualityJointAPI on '{joint_path}' references '{target_path}' which was not found in path_joint_map; skipping.",
                        stacklevel=2,
                    )
                    continue

                # Only the constant and linear terms moved to NewtonMimicAPI; the
                # higher-order polynomial terms remain MuJoCo-specific.
                polycoef = [coef0, coef1]
                for attr_name in ("mjc:coef2", "mjc:coef3", "mjc:coef4"):
                    polycoef.append(float(usd.get_attribute(joint_prim, attr_name, default=0.0)))

                # NewtonMimicAPI's opt-out governs both spellings of the constraint. The
                # plain mimic loop below skips these prims, so it is folded into the
                # runtime enabled flag here rather than dropping the constraint.
                eq_enabled = enabled and bool(usd.get_attribute(joint_prim, "newton:mimicEnabled", default=True))

                if convert_mjc_equality_constraints:
                    if mjc_polycoef_has_higher_order(polycoef):
                        warnings.warn(
                            f"Warning: Joint equality '{joint_path}' uses higher-order polycoef terms. "
                            "They are preserved for SolverMuJoCo, but generic Newton mimic constraints use "
                            "only coef0/coef1.",
                            stacklevel=2,
                        )
                    mjc_add_equality_mimic(
                        builder,
                        joint1_idx,
                        joint2_idx,
                        polycoef,
                        joint_path,
                        eq_enabled,
                        eq_custom_attrs,
                    )
                else:
                    _add_equality_constraint(
                        builder,
                        constraint_type=EqType.JOINT,
                        joint1=joint1_idx,
                        joint2=joint2_idx,
                        polycoef=polycoef,
                        label=joint_path,
                        enabled=eq_enabled,
                        custom_attributes=eq_custom_attrs,
                    )

    _parse_mjc_equality_constraints()

    # collapsing fixed joints to reduce the number of simulated bodies connected by fixed joints.
    collapse_results = None
    path_body_relative_transform = {}
    builder_joint_labels_before_collapse = list(builder.joint_label)
    if scene_attributes.get("newton:collapse_fixed_joints", collapse_fixed_joints):
        collapse_results = builder.collapse_fixed_joints()
        body_merged_parent = collapse_results["body_merged_parent"]
        body_merged_transform = collapse_results["body_merged_transform"]
        body_remap = collapse_results["body_remap"]

        for path, body_id in path_body_map.items():
            if body_id in body_remap:
                new_id = body_remap[body_id]
            elif body_id in body_merged_parent:
                # this body has been merged with another body
                new_id = body_remap[body_merged_parent[body_id]]
                path_body_relative_transform[path] = body_merged_transform[body_id]
            else:
                # this body has not been merged
                new_id = body_id

            path_body_map[path] = new_id

        # Cable bodies/joints and attachment joints are addressed by index (not prim path), so
        # remap them through the collapse maps to keep their path maps valid after collapsing.
        path_cable_map, path_attachment_map = _deformable_remap_collapsed(
            path_cable_map,
            path_attachment_map,
            path_attachment_attrs,
            collapse_results["joint_remap"],
            body_remap,
            body_merged_parent,
        )

        # Joint indices may have shifted after collapsing fixed joints; refresh the joint path map accordingly.
        # First rebuild the canonical label→index map, then re-add merged joint aliases.
        new_label_to_idx = {label: idx for idx, label in enumerate(builder.joint_label)}
        old_path_joint_map = path_joint_map
        path_joint_map = dict(new_label_to_idx)
        for path, old_idx in old_path_joint_map.items():
            if path in path_joint_map:
                continue  # already mapped via joint_label
            # Find the new index for this merged alias via the representative label
            old_label = (
                builder_joint_labels_before_collapse[old_idx]
                if old_idx < len(builder_joint_labels_before_collapse)
                else None
            )
            if old_label is not None and old_label in new_label_to_idx:
                path_joint_map[path] = new_label_to_idx[old_label]

    initialize_free_joint_velocities()

    # Mimic constraints from PhysxMimicJointAPI (run after collapse so joint indices are final).
    # PhysxMimicJointAPI is an instance-applied schema (e.g. PhysxMimicJointAPI:rotZ)
    # that couples a follower joint to a leader (reference) joint with a gearing ratio.
    # PhysX convention: jointPos + gearing * refJointPos + offset = 0
    # Newton/URDF convention: joint0 = coef0 + coef1 * joint1
    # Therefore: coef1 = -gearing, coef0 = -offset
    for joint_path, joint_idx in path_joint_map.items():
        joint_prim = stage.GetPrimAtPath(joint_path)
        if not joint_prim or not joint_prim.IsValid():
            continue

        # Skip if NewtonMimicAPI is present — it takes precedence over PhysxMimicJointAPI.
        if usd.has_applied_api_schema(joint_prim, "NewtonMimicAPI"):
            continue
        # Skip if MjcEqualityJointAPI is present — it creates equality constraints, not mimic.
        if _has_api_schema(joint_prim, "MjcEqualityJointAPI"):
            continue

        schemas_listop = joint_prim.GetMetadata("apiSchemas")
        if not schemas_listop:
            continue

        all_schemas = (
            list(schemas_listop.prependedItems)
            + list(schemas_listop.appendedItems)
            + list(schemas_listop.explicitItems)
        )

        for schema in all_schemas:
            schema_str = str(schema)
            if not schema_str.startswith("PhysxMimicJointAPI"):
                continue

            # Extract the axis instance name (e.g. "rotZ" from "PhysxMimicJointAPI:rotZ")
            parts = schema_str.split(":")
            if len(parts) < 2:
                continue
            axis_instance = parts[1]

            ref_joint_rel = joint_prim.GetRelationship(f"physxMimicJoint:{axis_instance}:referenceJoint")
            if not ref_joint_rel:
                continue
            targets = ref_joint_rel.GetTargets()
            if not targets:
                continue
            leader_path = targets[0]
            if not leader_path.IsAbsolutePath():
                leader_path = joint_prim.GetPath().GetParentPath().AppendPath(leader_path)
            leader_path = str(leader_path)

            leader_idx = path_joint_map.get(leader_path)
            if leader_idx is None:
                warnings.warn(
                    f"PhysxMimicJointAPI on '{joint_path}' references '{leader_path}' "
                    f"but leader joint was not found, skipping mimic constraint",
                    stacklevel=2,
                )
                continue

            gearing_attr = joint_prim.GetAttribute(f"physxMimicJoint:{axis_instance}:gearing")
            gearing = float(gearing_attr.Get()) if gearing_attr and gearing_attr.HasValue() else 1.0

            offset_attr = joint_prim.GetAttribute(f"physxMimicJoint:{axis_instance}:offset")
            offset = float(offset_attr.Get()) if offset_attr and offset_attr.HasValue() else 0.0

            builder.set_joint_mimic(joint=joint_idx, reference_joint=leader_idx, coeffs=(-offset, -gearing))

            if verbose:
                print(
                    f"Added PhysxMimicJointAPI constraint: '{joint_path}' follows '{leader_path}' "
                    f"(gearing={gearing}, offset={offset}, axis={axis_instance})"
                )

    # Mimic constraints from NewtonMimicAPI (run after collapse so joint indices are final).
    for joint_path, joint_idx in path_joint_map.items():
        joint_prim = stage.GetPrimAtPath(joint_path)
        if not joint_prim.IsValid() or not joint_prim.HasAPI("NewtonMimicAPI"):
            continue
        if _has_api_schema(joint_prim, "MjcEqualityJointAPI"):
            continue
        mimic_enabled = usd.get_attribute(joint_prim, "newton:mimicEnabled", default=True)
        if not mimic_enabled:
            continue
        leader_path, coef0, coef1 = _resolve_newton_mimic(joint_prim)
        if leader_path is None:
            if verbose:
                print(f"NewtonMimicAPI on {joint_path} has no newton:mimicJoint target; skipping")
            continue
        leader_path_str = str(leader_path)
        if leader_path_str not in path_joint_map:
            warnings.warn(
                f"NewtonMimicAPI on {joint_path}: leader {leader_path_str} not in path_joint_map; skipping mimic constraint.",
                stacklevel=2,
            )
            continue
        # Classify from the authored USD prim rather than builder.joint_type: several
        # single-DOF prims sharing a body pair are merged into one D6 (see
        # parse_merged_joints), which would otherwise misread an angular follower.
        follower_is_revolute = joint_prim.IsA(UsdPhysics.RevoluteJoint)
        follower_is_prismatic = joint_prim.IsA(UsdPhysics.PrismaticJoint)
        if not follower_is_revolute and not follower_is_prismatic:
            # Spherical and D6 followers hold more than one coordinate, and a ball
            # joint's coordinates are a quaternion rather than a scalar angle, so a
            # single offset has no defined unit. _resolve_newton_mimic passes the
            # value through; say so here.
            warnings.warn(
                f"NewtonMimicAPI on {joint_path}: newton:mimicCoef0 has no defined unit for a "
                f"{joint_prim.GetTypeName()} follower, which is not a single-DOF joint. Using the "
                f"authored value unconverted; the offset is applied to every coordinate.",
                stacklevel=2,
            )
        # Independent of units: a single-DOF prim merged into a D6 is constrained on every
        # axis of that joint, not only the one the API was authored on.
        if (follower_is_revolute or follower_is_prismatic) and builder.joint_type[joint_idx] == JointType.D6:
            warnings.warn(
                f"NewtonMimicAPI on {joint_path}: follower was merged into a multi-DOF joint, so the "
                f"mimic relationship applies to every coordinate of that joint, not only the authored axis.",
                stacklevel=2,
            )
        leader_idx = path_joint_map[leader_path_str]
        builder.set_joint_mimic(joint=joint_idx, reference_joint=leader_idx, coeffs=(coef0, coef1))

    # Parse Newton actuator prims from the USD stage.
    from ..actuators.delay import Delay  # noqa: PLC0415
    from ..actuators.usd_parser import parse_actuator_prim  # noqa: PLC0415

    actuator_count = 0
    path_to_dof = {
        path: builder.joint_qd_start[idx] + merged_dof_offset.get(path, 0)
        for path, idx in path_joint_map.items()
        if idx < len(builder.joint_qd_start)
    }
    path_to_coord = {
        path: builder.joint_q_start[idx] + merged_dof_offset.get(path, 0)
        for path, idx in path_joint_map.items()
        if idx < len(builder.joint_q_start)
    }
    for prim in Usd.PrimRange(stage.GetPrimAtPath(root_path)):
        prim_path = str(prim.GetPath())
        if any(re.match(pattern, prim_path) for pattern in ignore_paths):
            continue
        parsed = parse_actuator_prim(prim)
        if parsed is None:
            continue
        target_path = parsed.target_path
        if target_path not in path_to_dof:
            raise ValueError(
                f"Actuator prim {prim.GetPath()} targets '{target_path}' which does not resolve to a known joint DOF"
            )
        joint_idx = path_joint_map[target_path]
        dof_start = builder.joint_qd_start[joint_idx]
        next_start = (
            builder.joint_qd_start[joint_idx + 1]
            if joint_idx + 1 < len(builder.joint_qd_start)
            else builder.joint_dof_count
        )
        if next_start - dof_start != 1:
            raise ValueError(
                f"Actuator prim {prim.GetPath()} targets '{target_path}' which has "
                f"{next_start - dof_start} DOF(s); only 1-DOF joints (Revolute/Prismatic) are supported"
            )
        dof_index = path_to_dof[target_path]
        coord_index = path_to_coord.get(target_path)
        pos_index = coord_index if coord_index is not None and coord_index != dof_index else None

        delay_val = None
        clamping_specs = []
        for comp_class, comp_kwargs in parsed.component_specs:
            if comp_class is Delay:
                delay_val = comp_kwargs.get("delay_steps")
            else:
                clamping_specs.append((comp_class, comp_kwargs))

        builder.add_actuator(
            parsed.drive_class,
            index=dof_index,
            clamping=clamping_specs if clamping_specs else None,
            delay_steps=delay_val,
            pos_index=pos_index,
            **parsed.drive_kwargs,
        )
        actuator_count += 1
    if verbose and actuator_count > 0:
        print(f"Added {actuator_count} actuator(s) from USD")

    result = {
        "fps": stage.GetFramesPerSecond(),
        "duration": stage.GetEndTimeCode() - stage.GetStartTimeCode(),
        "up_axis": stage_up_axis,
        "path_body_map": path_body_map,
        "path_joint_map": path_joint_map,
        "path_shape_map": path_shape_map,
        "path_shape_scale": path_shape_scale,
        "path_particle_map": path_particle_map,
        "mass_unit": mass_unit,
        "linear_unit": linear_unit,
        "scene_attributes": scene_attributes,
        "physics_scene_path": str(physics_scene_prim.GetPath()) if physics_scene_prim is not None else None,
        "physics_dt": physics_dt,
        "collapse_results": collapse_results,
        "schema_attrs": R.schema_attrs,
        # "articulation_roots": articulation_roots,
        "path_body_relative_transform": path_body_relative_transform,
        "max_solver_iterations": max_solver_iters,
        "particle_scene_path": str(particle_scene_prim.GetPath()) if particle_scene_prim is not None else None,
        "actuator_count": actuator_count,
    }

    # Process custom frequencies with USD prim filters
    # Collect frequencies with filters and their attributes, then traverse the imported subtree once
    frequencies_with_filters = []
    for freq_key, freq_obj in builder.custom_frequencies.items():
        if freq_obj.usd_prim_filter is None:
            continue
        freq_attrs = [attr for attr in builder.custom_attributes.values() if attr.frequency == freq_key]
        if not freq_attrs:
            continue
        frequencies_with_filters.append((freq_key, freq_obj, freq_attrs))

    # Traverse the requested root subtree once and check all filters for each prim
    # Use TraverseInstanceProxies to include prims under instanceable prims
    if frequencies_with_filters:
        for prim in Usd.PrimRange(stage.GetPrimAtPath(root_path), Usd.TraverseInstanceProxies()):
            prim_path = str(prim.GetPath())
            if any(re.match(pattern, prim_path) for pattern in ignore_paths):
                continue
            for freq_key, freq_obj, freq_attrs in frequencies_with_filters:
                # Build per-frequency callback context and pass the same object to
                # usd_prim_filter and usd_entry_expander.
                callback_context = {"prim": prim, "result": result, "builder": builder}

                try:
                    matches_frequency = freq_obj.usd_prim_filter(prim, callback_context)
                except Exception as e:
                    raise RuntimeError(
                        f"usd_prim_filter for frequency '{freq_key}' raised an error on prim '{prim.GetPath()}': {e}"
                    ) from e
                if not matches_frequency:
                    continue

                if freq_obj.usd_entry_expander is not None:
                    try:
                        expanded_rows = list(freq_obj.usd_entry_expander(prim, callback_context))
                    except Exception as e:
                        raise RuntimeError(
                            f"usd_entry_expander for frequency '{freq_key}' raised an error on prim '{prim.GetPath()}': {e}"
                        ) from e
                    values_rows = [{attr.key: row.get(attr.key, None) for attr in freq_attrs} for row in expanded_rows]
                    builder.add_custom_values_batch(values_rows)
                    if verbose and len(expanded_rows) > 0:
                        print(
                            f"Parsed custom frequency '{freq_key}' from prim {prim.GetPath()} with {len(expanded_rows)} rows"
                        )
                    continue

                prim_custom_attrs = usd.get_custom_attribute_values(
                    prim,
                    freq_attrs,
                    context={"result": result, "builder": builder},
                )

                # Build a complete values dict for all attributes in this frequency
                # Use None for missing values so add_custom_values can apply defaults
                values_dict = {}
                for attr in freq_attrs:
                    # Use authored value if present, otherwise None (defaults applied at finalize)
                    values_dict[attr.key] = prim_custom_attrs.get(attr.key, None)

                # Always add values for this prim to increment the frequency count,
                # even if all values are None (defaults will be applied during finalization)
                builder.add_custom_values(**values_dict)
                if verbose:
                    print(f"Parsed custom frequency '{freq_key}' from prim {prim.GetPath()}")

    # USD MjcActuator does not preserve the original MJCF authoring tag:
    # MuJoCo's compiler expands <position>/<velocity> shortcuts into raw
    # gain/bias/dyntype fields before USD export, so a <position kp=K> and a
    # hand-written <general> with the same gains produce bit-identical prims.
    # We can't recover the author's intent, so we fix a contract:
    #
    #   USD MjcActuator rows targeting a joint DOF with the position/velocity
    #   shape and default dyntype/gaintype/gear are imported as JOINT_TARGET
    #   and driven by Control.joint_target_q / joint_target_qd.
    #
    # Rows that author non-default dyntype (filter, integrator, ...), gaintype,
    # gear, or carry an unresolved dampratio placeholder (positive biasprm[2])
    # stay CTRL_DIRECT, because JOINT_TARGET would silently drop those features
    # when _init_actuators rebuilds the MuJoCo actuators. Tendon/site/body
    # targets and synthesized per-axis spherical DOF labels also stay
    # CTRL_DIRECT (they don't appear in path_to_dof).
    #
    # Note: per-axis prim paths from joints that were merged into a D6 (the
    # cycle-detection fix from #2557) ARE in path_to_dof and map to single
    # DOFs of the merged joint, so they convert just like single-DOF
    # revolutes -- mirroring how the MJCF importer uses mjcf_joint_name_to_dof
    # to target specific DOFs in combined joints (see import_mjcf.py).
    if "mujoco:actuator_target_label" in builder.custom_attributes:
        mjc_actuator_count = builder._custom_frequency_counts.get("mujoco:actuator", 0)
    else:
        mjc_actuator_count = 0

    if mjc_actuator_count > 0:
        from ..solvers.mujoco.solver_mujoco import SolverMuJoCo  # noqa: PLC0415

        ctrl_source_joint_target = int(SolverMuJoCo.CtrlSource.JOINT_TARGET)

        def _row(key: str, row: int) -> Any:
            """Row value from a custom-frequency attribute, falling back to its default."""
            attr = builder.custom_attributes[key]
            value = attr.values[row] if row < len(attr.values) else None
            return attr.default if value is None else value

        converted = 0

        for row in range(mjc_actuator_count):
            target_path = _row("mujoco:actuator_target_label", row)
            dof = path_to_dof.get(target_path) if target_path else None
            if dof is None:
                continue

            # Convert only when JOINT_TARGET would not silently drop semantically
            # important authored features. _init_actuators rebuilds JOINT_TARGET
            # actuators with default dyntype/gaintype/biastype/gear, so non-default
            # values for those force the actuator to stay CTRL_DIRECT.
            #
            # ctrlrange/forcerange don't gate: the rebuild re-attaches them
            # (see joint_target_ranges in _init_actuators). Effort limit
            # (jnt_actfrcrange) comes from the joint, not the actuator.
            if (
                int(_row("mujoco:actuator_biastype", row)) != _ActuatorBiasType.AFFINE
                or int(_row("mujoco:actuator_dyntype", row)) != _ActuatorDynamicsType.NONE
                or int(_row("mujoco:actuator_gaintype", row)) != _ActuatorGainType.FIXED
            ):
                continue
            gear = list(_row("mujoco:actuator_gear", row))
            if not (np.isclose(gear[0], 1.0) and all(np.isclose(g, 0.0) for g in gear[1:])):
                continue

            gainprm = list(_row("mujoco:actuator_gainprm", row))
            biasprm = list(_row("mujoco:actuator_biasprm", row))
            kp = gainprm[0]
            if kp <= 0.0:
                continue

            # MuJoCo "position" shortcut: gainprm=[kp,0,...], biasprm=[0,-kp,(-kv|0),0,...].
            # A positive biasprm[2] is a dampratio placeholder that MuJoCo's compiler
            # resolves via mj_setConst; leaving such rows CTRL_DIRECT preserves that path.
            # MuJoCo "velocity" shortcut: gainprm=[kv,0,...], biasprm=[0,0,-kv,0,...].
            is_position = np.isclose(biasprm[0], 0.0) and np.isclose(biasprm[1], -kp) and biasprm[2] <= 0.0
            is_velocity = np.isclose(biasprm[0], 0.0) and np.isclose(biasprm[1], 0.0) and np.isclose(biasprm[2], -kp)
            if not (is_position or is_velocity):
                continue

            current_mode = builder.joint_target_mode[dof]
            if is_position:
                builder.joint_target_ke[dof] = kp
                if current_mode == int(JointTargetMode.VELOCITY):
                    builder.joint_target_mode[dof] = int(JointTargetMode.POSITION_VELOCITY)
                elif current_mode == int(JointTargetMode.NONE):
                    builder.joint_target_mode[dof] = int(JointTargetMode.POSITION)
                    builder.joint_target_kd[dof] = -biasprm[2]  # 0 or kv from biasprm=[0,-kp,-kv,...]
            else:  # velocity
                builder.joint_target_kd[dof] = kp
                if current_mode == int(JointTargetMode.POSITION):
                    builder.joint_target_mode[dof] = int(JointTargetMode.POSITION_VELOCITY)
                elif current_mode == int(JointTargetMode.NONE):
                    builder.joint_target_mode[dof] = int(JointTargetMode.VELOCITY)

            # Override the row's CTRL_DIRECT default and write the DOF target index
            # so _init_actuators routes through MuJoCo's joint_target_mode actuators.
            builder.custom_attributes["mujoco:ctrl_source"].values[row] = ctrl_source_joint_target
            builder.custom_attributes["mujoco:actuator_trnid"].values[row] = wp.vec2i(dof, 0)
            # Record the kind classified above so the solver doesn't re-derive it.
            builder.custom_attributes["mujoco:ctrl_type"].values[row] = int(
                SolverMuJoCo.CtrlType.POSITION if is_position else SolverMuJoCo.CtrlType.VELOCITY
            )

            converted += 1

        if verbose and converted > 0:
            print(f"Mapped {converted} MuJoCo USD actuator(s) to joint targets")
    if return_deformable_results:
        # The deformable results are opt-in so the default return shape carries no
        # deformable additions and stays isolated from changes to this experimental contract.
        result.update(
            {
                "path_cable_map": path_cable_map,
                "path_cloth_map": path_cloth_map,
                "path_soft_map": path_soft_map,
                "path_cable_attrs": path_cable_attrs,
                "path_cloth_attrs": path_cloth_attrs,
                "path_soft_attrs": path_soft_attrs,
                "path_attachment_map": path_attachment_map,
                "path_attachment_attrs": path_attachment_attrs,
            }
        )

    return result


def _raise_on_stage_errors(usd_stage, stage_source: str):
    get_errors = getattr(usd_stage, "GetCompositionErrors", None)
    if get_errors is None:
        return
    errors = get_errors()
    if not errors:
        return
    messages = []
    for err in errors:
        try:
            messages.append(err.GetMessage())
        except Exception:
            messages.append(str(err))
    formatted = "\n".join(f"- {message}" for message in messages)
    raise RuntimeError(f"USD stage has composition errors while loading {stage_source}:\n{formatted}")
