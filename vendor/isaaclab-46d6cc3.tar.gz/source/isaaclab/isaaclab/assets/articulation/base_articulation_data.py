# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import warnings
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

import warp as wp

from ...utils.buffers import TimestampedBuffer
from ...utils.leapp import (
    POSE6_ELEMENT_NAMES,
    POSE7_ELEMENT_NAMES,
    QUAT_XYZW_ELEMENT_NAMES,
    XYZ_ELEMENT_NAMES,
    InputKindEnum,
    body_pose6_resolver,
    body_pose_resolver,
    body_quat_resolver,
    body_xyz_resolver,
    joint_names_resolver,
    leapp_tensor_semantics,
)
from ...utils.warp import ProxyArray
from . import ordering_kernels

if TYPE_CHECKING:
    from ...actuators import ActuatorCollection
    from .ordering import ArticulationNameMap


class BaseArticulationData(ABC):
    """Data container for an articulation.

    This class contains the data for an articulation in the simulation. The data includes the state of
    the root rigid body, the state of all the bodies in the articulation, and the joint state. The data is
    stored in the simulation world frame unless otherwise specified.

    An articulation is comprised of multiple rigid bodies or links. For a rigid body, there are two frames
    of reference that are used:

    - Actor frame: The frame of reference of the rigid body prim. This typically corresponds to the Xform prim
      with the rigid body schema.
    - Center of mass frame: The frame of reference of the center of mass of the rigid body.

    Depending on the settings, the two frames may not coincide with each other. In the robotics sense, the actor frame
    can be interpreted as the link frame.
    """

    __backend_name__: str = "base"
    """The name of the backend for the articulation data container."""

    def __init__(self, root_view, device: str):
        """Initializes the articulation data.

        Args:
            root_view: The root articulation view.
            device: The device used for processing.
        """
        # Set the parameters
        self.device = device
        self._actuator_collection: ActuatorCollection | None = None
        self._joint_pos_target = None
        self._joint_vel_target = None
        self._joint_effort_target = None
        self._joint_pos_target_ta: ProxyArray | None = None
        self._joint_vel_target_ta: ProxyArray | None = None
        self._joint_effort_target_ta: ProxyArray | None = None
        self._body_joint_wrench = TimestampedBuffer()
        self._body_joint_wrench_ta: ProxyArray | None = None

    def bind_actuator_collection(self, actuators: ActuatorCollection) -> None:
        """Bind collection-owned command and telemetry aliases plus actuator compatibility projections."""
        self._actuator_collection = actuators
        self._joint_pos_target = actuators.target_command.position.warp
        self._joint_vel_target = actuators.target_command.velocity.warp
        self._joint_effort_target = actuators.target_command.effort.warp
        self._computed_torque = actuators.computed_effort.warp
        self._applied_torque = actuators.applied_effort.warp
        self._soft_joint_vel_limits = actuators._soft_joint_vel_limits
        self._joint_pos_target_ta = actuators.target_command.position
        self._joint_vel_target_ta = actuators.target_command.velocity
        self._joint_effort_target_ta = actuators.target_command.effort
        self._computed_torque_ta = actuators.computed_effort
        self._applied_torque_ta = actuators.applied_effort
        self._soft_joint_vel_limits_ta = ProxyArray(self._soft_joint_vel_limits)

    def _get_actuator_collection_proxy(self, name: str, buffer_name: str, proxy_name: str) -> ProxyArray:
        collection = self._actuator_collection
        if collection is not None:
            command_field = {
                "joint_pos_target": "position",
                "joint_vel_target": "velocity",
                "joint_effort_target": "effort",
            }.get(name)
            collection_field = {
                "computed_torque": "computed_effort",
                "applied_torque": "applied_effort",
            }.get(name, name)
            replacement = f"command.{command_field}" if command_field is not None else collection_field
            warnings.warn(
                f"ArticulationData.{name} is deprecated. Use articulation.actuators.{replacement} instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            return (
                getattr(collection.target_command, command_field)
                if command_field is not None
                else getattr(collection, collection_field)
            )

        warnings.warn(
            f"ArticulationData.{name} is deprecated.",
            DeprecationWarning,
            stacklevel=2,
        )
        buffer = getattr(self, buffer_name)
        if buffer is None:
            buffer = wp.zeros((self._num_instances, self._num_joints), dtype=wp.float32, device=self.device)
            setattr(self, buffer_name, buffer)
        proxy = getattr(self, proxy_name)
        if proxy is None:
            proxy = ProxyArray(buffer)
            setattr(self, proxy_name, proxy)
        return proxy

    @abstractmethod
    def update(self, dt: float) -> None:
        raise NotImplementedError

    @abstractmethod
    def _reset_pose(self, from_link: bool = True) -> None:
        """Invalidate cached pose-dependent quantities after a pose write to the simulation.

        Backends implement this to mark the affected pose buffers stale (and trigger any
        forward-kinematics refresh) so the next read recomputes from the freshly written state.

        Args:
            from_link: Set ``True`` when the root link pose was written so the derived
                center-of-mass pose (:attr:`root_com_pose_w`) is also invalidated; set ``False``
                when the center-of-mass pose was written directly so it is not clobbered.
        """
        raise NotImplementedError

    @abstractmethod
    def _reset_velocity(self, from_com: bool = True) -> None:
        """Invalidate cached velocity-dependent quantities after a velocity write to the simulation.

        Backends implement this to mark the affected velocity buffers stale (and trigger any
        forward-kinematics refresh) so the next read recomputes from the freshly written state.

        Args:
            from_com: Set ``True`` when the root center-of-mass velocity was written so the derived
                link velocity (:attr:`root_link_vel_w`) is also invalidated; set ``False`` when the
                link velocity was written directly so it is not clobbered.
        """
        raise NotImplementedError

    ##
    # Names.
    ##

    body_names: list[str] | None = None
    """Body names in public API order.

    Configured order is used when present; otherwise this is active backend
    solver-view order.
    """

    joint_names: list[str] | None = None
    """Joint names in public API order.

    Configured order is used when present; otherwise this is active backend
    solver-view order.
    """

    joint_ordering: ArticulationNameMap | None = None
    """Bidirectional map between backend and public joint order.

    This is ``None`` whenever public and backend orders coincide (default
    ordering, or a configured ordering that resolved to backend order); a
    non-``None`` map always denotes an actual permutation.
    """

    body_ordering: ArticulationNameMap | None = None
    """Bidirectional map between backend and public body order.

    This is ``None`` whenever public and backend orders coincide (default
    ordering, or a configured ordering that resolved to backend order); a
    non-``None`` map always denotes an actual permutation.
    """

    fixed_tendon_names: list[str] | None = None
    """Fixed tendon names in active backend solver-view order."""

    spatial_tendon_names: list[str] | None = None
    """Spatial tendon names in active backend solver-view order."""

    @property
    def has_joint_ordering(self) -> bool:
        """Whether a nonidentity joint ordering is active.

        Derived from :attr:`joint_ordering`; a non-``None`` map always denotes an
        actual permutation between backend and public joint order.
        """
        return self.joint_ordering is not None

    @property
    def has_body_ordering(self) -> bool:
        """Whether a nonidentity body ordering is active.

        Derived from :attr:`body_ordering`; a non-``None`` map always denotes an
        actual permutation between backend and public body order.
        """
        return self.body_ordering is not None

    def _apply_ordering_maps_after_resolve(self) -> None:
        """Configure backend-order staging after the articulation resolves ordering maps.

        The owning articulation calls this once it has resolved and stored the joint
        and body ordering maps (:attr:`joint_ordering` and :attr:`body_ordering`) on
        this data container. The base implementation is a no-op; backend data classes
        override it to allocate or release the backend-order shadow buffers their read
        paths require when the public order differs from backend order.
        """

    def _make_jacobian_body_user_to_backend(self) -> wp.array:
        """Build the compact user-to-backend row map for Jacobian body axes.

        The map follows the installed :attr:`body_ordering`, or backend body
        order when no ordering is active. Fixed-base articulations omit the
        root link's Jacobian rows, so a nonzero :attr:`_jacobian_link_offset`
        drops backend row 0 and shifts the remaining rows down by one.

        Returns:
            One-dimensional ``wp.int32`` device array of backend Jacobian rows in
            public body order.
        """
        body_ordering = self.body_ordering
        body_user_to_backend = (
            body_ordering.user_to_backend_indices if body_ordering is not None else range(self._num_bodies)
        )
        if self._jacobian_link_offset == 0:
            backend_rows = tuple(int(backend_id) for backend_id in body_user_to_backend)
        else:
            backend_rows = tuple(int(backend_id) - 1 for backend_id in body_user_to_backend if int(backend_id) != 0)
        return wp.array(backend_rows, dtype=wp.int32, device=self.device)

    def _fetch_body_com_pose_b_backend(self, buf: TimestampedBuffer) -> None:
        """Read the current backend-order static body COM pose into ``buf`` when stale.

        Backend hook for :meth:`_ensure_body_com_pose_b_current` and
        :attr:`_backend_body_com_pose_b`. The base raises because only backends that
        stage a static body COM pose implement the fetch.

        Args:
            buf: Timestamped buffer to refresh with the backend-order COM pose.
        """
        raise NotImplementedError

    def _ensure_body_com_pose_b_current(self) -> None:
        """Refresh the static body COM pose cache when explicitly invalidated.

        Under body ordering the fetch fills the backend-order staging buffer and the
        result is gathered into public order; otherwise it fills the public buffer
        directly.
        """
        if self._body_com_pose_b.timestamp >= 0.0:
            return
        if self.body_ordering is None:
            self._fetch_body_com_pose_b_backend(self._body_com_pose_b)
            return
        backend_staging = self._body_com_pose_b_backend
        if backend_staging is None:
            raise RuntimeError(f"{self.__backend_name__} body COM ordering staging was not initialized.")
        self._fetch_body_com_pose_b_backend(backend_staging)
        wp.launch(
            ordering_kernels.reorder_2d_backend_to_user,
            dim=(self._num_instances, self._num_bodies),
            inputs=[backend_staging.data, self.body_ordering.user_to_backend],
            outputs=[self._body_com_pose_b.data],
            device=self.device,
        )
        self._body_com_pose_b.timestamp = backend_staging.timestamp

    @property
    def _backend_body_com_pose_b(self) -> wp.array(dtype=wp.transformf, ndim=2):
        """Backend-order body COM pose buffer for root-only computations."""
        if self.body_ordering is None:
            self._ensure_body_com_pose_b_current()
            return self._body_com_pose_b.data
        backend_staging = self._body_com_pose_b_backend
        if backend_staging is None:
            raise RuntimeError(f"{self.__backend_name__} body COM ordering staging was not initialized.")
        self._fetch_body_com_pose_b_backend(backend_staging)
        return backend_staging.data

    ##
    # Defaults - Initial state.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def default_root_pose(self) -> ProxyArray:
        """Default root pose ``[pos, quat]`` in the local environment frame.

        The position and quaternion are of the articulation root's actor frame. Shape is (num_instances),
        dtype = wp.transformf. In torch this resolves to (num_instances, 7).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def default_root_vel(self) -> ProxyArray:
        """Default root velocity ``[lin_vel, ang_vel]`` in the local environment frame.

        The linear and angular velocities are of the articulation root's center of mass frame.
        Shape is (num_instances), dtype = wp.spatial_vectorf. In torch this resolves to (num_instances, 6).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def default_root_state(self) -> ProxyArray:
        """Deprecated, same as :attr:`default_root_pose` and :attr:`default_root_vel`."""
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def default_joint_pos(self) -> ProxyArray:
        """Default joint positions of all joints.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to (num_instances, num_joints).

        This quantity is configured through the :attr:`isaaclab.assets.ArticulationCfg.init_state` parameter.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def default_joint_vel(self) -> ProxyArray:
        """Default joint velocities of all joints.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to (num_instances, num_joints).

        This quantity is configured through the :attr:`isaaclab.assets.ArticulationCfg.init_state` parameter.
        """
        raise NotImplementedError

    ##
    # Joint commands -- Set into simulation.
    ##

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.COMMAND_JOINT_POSITION)
    def joint_pos_target(self) -> ProxyArray:
        """Joint position targets commanded by the user [m or rad, depending on joint type].

        .. deprecated:: 3.0.0
            Use ``articulation.actuators.target_command.position`` instead.

        Shape is (num_instances, num_joints), dtype = wp.float32.
        """
        return self._get_actuator_collection_proxy("joint_pos_target", "_joint_pos_target", "_joint_pos_target_ta")

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.COMMAND_JOINT_VELOCITY)
    def joint_vel_target(self) -> ProxyArray:
        """Joint velocity targets commanded by the user [m/s or rad/s, depending on joint type].

        .. deprecated:: 3.0.0
            Use ``articulation.actuators.target_command.velocity`` instead.

        Shape is (num_instances, num_joints), dtype = wp.float32.
        """
        return self._get_actuator_collection_proxy("joint_vel_target", "_joint_vel_target", "_joint_vel_target_ta")

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.COMMAND_JOINT_TORQUES)
    def joint_effort_target(self) -> ProxyArray:
        """Joint effort targets commanded by the user [N or N·m, depending on joint type].

        .. deprecated:: 3.0.0
            Use ``articulation.actuators.target_command.effort`` instead.

        Shape is (num_instances, num_joints), dtype = wp.float32.
        """
        return self._get_actuator_collection_proxy(
            "joint_effort_target", "_joint_effort_target", "_joint_effort_target_ta"
        )

    ##
    # Joint commands -- Explicit actuators.
    ##

    @property
    @leapp_tensor_semantics(kind="state/joint/computed_torque")
    def computed_torque(self) -> ProxyArray:
        """Computed actuator torques before clipping [N or N·m, depending on joint type].

        .. deprecated:: 3.0.0
            Use ``articulation.actuators.computed_effort`` instead.

        Shape is (num_instances, num_joints), dtype = wp.float32.
        """
        return self._get_actuator_collection_proxy("computed_torque", "_computed_torque", "_computed_torque_ta")

    @property
    @leapp_tensor_semantics(kind="state/joint/applied_torque")
    def applied_torque(self) -> ProxyArray:
        """Actuator torques applied after clipping [N or N·m, depending on joint type].

        .. deprecated:: 3.0.0
            Use ``articulation.actuators.applied_effort`` instead.

        Shape is (num_instances, num_joints), dtype = wp.float32.
        """
        return self._get_actuator_collection_proxy("applied_torque", "_applied_torque", "_applied_torque_ta")

    ##
    # Joint properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_stiffness(self) -> ProxyArray:
        """Solver joint-drive stiffness [N/m or N·m/rad, depending on joint type].

        Shape is (num_instances, num_joints), dtype = wp.float32. Explicit
        actuator joints report zero because their model owns the gains.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_damping(self) -> ProxyArray:
        """Solver joint-drive damping [N·s/m or N·m·s/rad, depending on joint type].

        Shape is (num_instances, num_joints), dtype = wp.float32. Explicit
        actuator joints report zero because their model owns the gains.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_armature(self) -> ProxyArray:
        """Joint armature provided to the simulation.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to (num_instances, num_joints).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_friction_coeff(self) -> ProxyArray:
        """Backend-specific joint friction values provided to the simulation.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to (num_instances, num_joints).

        .. warning::
            The physical meaning and units of this value depend on the concrete backend and solver. Do not assume
            values are comparable across backends; check the backend-specific :class:`ArticulationData`
            implementation before interpreting or reusing them.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_pos_limits(self) -> ProxyArray:
        """Joint position limits provided to the simulation.

        Shape is (num_instances, num_joints, 2), dtype = wp.vec2f. In torch this resolves to
        (num_instances, num_joints, 2).

        The limits are in the order :math:`[lower, upper]`.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_vel_limits(self) -> ProxyArray:
        """Joint maximum velocity provided to the simulation.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to (num_instances, num_joints).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def joint_effort_limits(self) -> ProxyArray:
        """Joint maximum effort provided to the simulation.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to (num_instances, num_joints).
        """
        raise NotImplementedError

    ##
    # Joint properties - Custom.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def soft_joint_pos_limits(self) -> ProxyArray:
        r"""Soft joint positions limits for all joints.

        Shape is (num_instances, num_joints), dtype = wp.vec2f. In torch this resolves to
        (num_instances, num_joints, 2).

        The limits are in the order :math:`[lower, upper]`.The soft joint position limits are computed as
        a sub-region of the :attr:`joint_pos_limits` based on the
        :attr:`~isaaclab.assets.ArticulationCfg.soft_joint_pos_limit_factor` parameter.

        Consider the joint position limits :math:`[lower, upper]` and the soft joint position limits
        :math:`[soft_lower, soft_upper]`. The soft joint position limits are computed as:

        .. math::

            soft\_lower = (lower + upper) / 2 - factor * (upper - lower) / 2
            soft\_upper = (lower + upper) / 2 + factor * (upper - lower) / 2

        The soft joint position limits help specify a safety region around the joint limits. It isn't used by the
        simulation, but is useful for learning agents to prevent the joint positions from violating the limits.
        """
        raise NotImplementedError

    @property
    @leapp_tensor_semantics(const=True)
    def soft_joint_vel_limits(self) -> ProxyArray:
        """Actuator-resolved soft joint velocity limits [m/s or rad/s, depending on joint type].

        Shape is (num_instances, num_joints), dtype = wp.float32.

        These values are produced by the actuator model and can differ from :attr:`joint_vel_limits` for a
        state-dependent velocity-limit model, such as one with a variable gear ratio. They are compatibility outputs;
        the solver velocity limits remain :attr:`joint_vel_limits`.
        """
        return self._soft_joint_vel_limits_ta

    ##
    # Fixed tendon properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_stiffness(self) -> ProxyArray:
        """Fixed tendon stiffness provided to the simulation.

        Shape is (num_instances, num_fixed_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_fixed_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_damping(self) -> ProxyArray:
        """Fixed tendon damping provided to the simulation.

        Shape is (num_instances, num_fixed_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_fixed_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_limit_stiffness(self) -> ProxyArray:
        """Fixed tendon limit stiffness provided to the simulation.

        Shape is (num_instances, num_fixed_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_fixed_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_rest_length(self) -> ProxyArray:
        """Fixed tendon rest length provided to the simulation.

        Shape is (num_instances, num_fixed_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_fixed_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_offset(self) -> ProxyArray:
        """Fixed tendon offset provided to the simulation.

        Shape is (num_instances, num_fixed_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_fixed_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_pos_limits(self) -> ProxyArray:
        """Fixed tendon position limits provided to the simulation.

        Shape is (num_instances, num_fixed_tendons, 2), dtype = wp.vec2f. In torch this resolves to
        (num_instances, num_fixed_tendons, 2).
        """
        raise NotImplementedError

    ##
    # Spatial tendon properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def spatial_tendon_stiffness(self) -> ProxyArray:
        """Spatial tendon stiffness provided to the simulation.

        Shape is (num_instances, num_spatial_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_spatial_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def spatial_tendon_damping(self) -> ProxyArray:
        """Spatial tendon damping provided to the simulation.

        Shape is (num_instances, num_spatial_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_spatial_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def spatial_tendon_limit_stiffness(self) -> ProxyArray:
        """Spatial tendon limit stiffness provided to the simulation.

        Shape is (num_instances, num_spatial_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_spatial_tendons).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def spatial_tendon_offset(self) -> ProxyArray:
        """Spatial tendon offset provided to the simulation.

        Shape is (num_instances, num_spatial_tendons), dtype = wp.float32. In torch this resolves to
        (num_instances, num_spatial_tendons).
        """
        raise NotImplementedError

    ##
    # Root state properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names=POSE7_ELEMENT_NAMES)
    def root_link_pose_w(self) -> ProxyArray:
        """Root link pose ``[pos, quat]`` in simulation world frame.

        Shape is (num_instances,), dtype = wp.transformf. In torch this resolves to (num_instances, 7).

        This quantity is the pose of the articulation root's actor frame relative to the world.
        The orientation is provided in (x, y, z, w) format.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_VEL, element_names=POSE6_ELEMENT_NAMES)
    def root_link_vel_w(self) -> ProxyArray:
        """Root link velocity ``[lin_vel, ang_vel]`` in simulation world frame.

        Shape is (num_instances,), dtype = wp.spatial_vectorf. In torch this resolves to (num_instances, 6).

        This quantity contains the linear and angular velocities of the articulation root's actor frame
        relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names=POSE7_ELEMENT_NAMES)
    def root_com_pose_w(self) -> ProxyArray:
        """Root center of mass pose ``[pos, quat]`` in simulation world frame.

        Shape is (num_instances,), dtype = wp.transformf. In torch this resolves to (num_instances, 7).

        This quantity is the pose of the articulation root's center of mass frame relative to the world.
        The orientation is provided in (x, y, z, w) format.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_VEL, element_names=POSE6_ELEMENT_NAMES)
    def root_com_vel_w(self) -> ProxyArray:
        """Root center of mass velocity ``[lin_vel, ang_vel]`` in simulation world frame.

        Shape is (num_instances,), dtype = wp.spatial_vectorf. In torch this resolves to (num_instances, 6).

        This quantity contains the linear and angular velocities of the articulation root's center of mass frame
        relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/state")
    def root_state_w(self) -> ProxyArray:
        """Deprecated, same as :attr:`root_link_pose_w` and :attr:`root_com_vel_w`."""
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/link_state")
    def root_link_state_w(self) -> ProxyArray:
        """Deprecated, same as :attr:`root_link_pose_w` and :attr:`root_link_vel_w`."""
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/com_state")
    def root_com_state_w(self) -> ProxyArray:
        """Deprecated, same as :attr:`root_com_pose_w` and :attr:`root_com_vel_w`."""
        raise NotImplementedError

    ##
    # Body state properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def body_mass(self) -> ProxyArray:
        """Body mass ``wp.float32`` in the world frame.

        Shape is (num_instances, num_bodies), dtype = wp.float32. In torch this resolves to (num_instances, num_bodies).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(const=True)
    def body_inertia(self) -> ProxyArray:
        """Flattened body inertia in the world frame.

        Shape is (num_instances, num_bodies, 9), dtype = wp.float32. In torch this resolves to
        (num_instances, num_bodies, 9).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names_resolver=body_pose_resolver)
    def body_link_pose_w(self) -> ProxyArray:
        """Body link pose ``[pos, quat]`` in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.transformf. In torch this resolves to
        (num_instances, num_bodies, 7).

        This quantity is the pose of the articulation links' actor frame relative to the world.
        The orientation is provided in (x, y, z, w) format.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_VEL, element_names_resolver=body_pose6_resolver)
    def body_link_vel_w(self) -> ProxyArray:
        """Body link velocity ``[lin_vel, ang_vel]`` in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.spatial_vectorf. In torch this resolves to
        (num_instances, num_bodies, 6).

        This quantity contains the linear and angular velocities of the articulation links' actor frame
        relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names_resolver=body_pose_resolver)
    def body_com_pose_w(self) -> ProxyArray:
        """Body center of mass pose ``[pos, quat]`` in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.transformf. In torch this resolves to
        (num_instances, num_bodies, 7).

        This quantity is the pose of the center of mass frame of the articulation links relative to the world.
        The orientation is provided in (x, y, z, w) format.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_VEL, element_names_resolver=body_pose6_resolver)
    def body_com_vel_w(self) -> ProxyArray:
        """Body center of mass velocity ``[lin_vel, ang_vel]`` in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.spatial_vectorf. In torch this resolves to
        (num_instances, num_bodies, 6).

        This quantity contains the linear and angular velocities of the articulation links' center of mass frame
        relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/state")
    def body_state_w(self) -> ProxyArray:
        """Deprecated, same as :attr:`body_link_pose_w` and :attr:`body_com_vel_w`."""
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/link_state")
    def body_link_state_w(self) -> ProxyArray:
        """Deprecated, same as :attr:`body_link_pose_w` and :attr:`body_link_vel_w`."""
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/com_state")
    def body_com_state_w(self) -> ProxyArray:
        """Deprecated, same as :attr:`body_com_pose_w` and :attr:`body_com_vel_w`."""
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/wrench")
    def body_joint_wrench(self) -> ProxyArray:
        """Incoming joint reaction wrench ``[force, torque]`` for each body.

        Shape is (num_instances, num_bodies), dtype = ``wp.spatial_vectorf``. In torch this
        resolves to (num_instances, num_bodies, 6). Entries follow :attr:`body_names`.
        Force [N] and torque [N*m] are expressed in the child-side joint frame, with torque
        referenced at the child-side joint anchor. This is not the applied actuator effort.

        Newton requires :attr:`ArticulationCfg.enable_joint_wrench` before simulation startup.
        Its free and world-fixed root entries are zero; loop-closing constraints are excluded.
        PhysX and OVPhysX include the backend's root reaction. Values describe the last physics
        step, so step the simulation after resetting or writing state before reading them.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ACC, element_names_resolver=body_pose6_resolver)
    def body_com_acc_w(self) -> ProxyArray:
        """Acceleration of all bodies center of mass ``[lin_acc, ang_acc]``.

        Shape is (num_instances, num_bodies), dtype = wp.spatial_vectorf. In torch this resolves to
        (num_instances, num_bodies, 6).

        All values are relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names_resolver=body_pose_resolver)
    def body_com_pose_b(self) -> ProxyArray:
        """Center of mass pose ``[pos, quat]`` of all bodies in their respective body's link frames.

        Shape is (num_instances, num_bodies), dtype = wp.transformf. In torch this resolves to
        (num_instances, num_bodies, 7).

        This quantity is the pose of the center of mass frame of the rigid body relative to the body's link frame.
        The orientation is provided in (x, y, z, w) format.
        """
        raise NotImplementedError

    ##
    # Dynamics quantities (task-space controllers).
    ##

    @property
    @leapp_tensor_semantics(kind="state/body/link_jacobian")
    def body_link_jacobian_w(self) -> ProxyArray:
        """Per-body geometric Jacobian referenced at each body's link origin in world frame.

        Shape: ``(num_instances, num_jacobi_bodies, 6, num_joints + num_base_dofs)``,
        dtype ``wp.float32``. Linear rows ``[0:3]`` [m/s per unit DoF velocity];
        angular rows ``[3:6]`` [rad/s per unit DoF velocity].

        Contract: for any generalized velocity ``v`` of length
        ``num_joints + num_base_dofs``,

        .. code-block:: text

            J[:, jacobi_body_idx, 0:3, :] @ v == body_link_lin_vel_w[:, body_idx]
            J[:, jacobi_body_idx, 3:6, :] @ v == body_link_ang_vel_w[:, body_idx]

        Conventions:
            * Body axis: ``jacobi_body_idx == body_idx - 1`` for fixed-base (fixed-root
              row excluded); ``jacobi_body_idx == body_idx`` for floating-base.
              With custom body ordering, fixed-base Jacobian rows follow user body
              order with the fixed root omitted.
            * DoF axis: leading
              :attr:`~isaaclab.assets.BaseArticulation.num_base_dofs` floating-base
              columns (world-frame ``[lin_x, lin_y, lin_z, ang_x, ang_y, ang_z]``),
              then actuated-joint columns in :attr:`joint_names` order.
        """
        raise NotImplementedError(f"{type(self).__name__} does not implement body_link_jacobian_w.")

    @property
    @leapp_tensor_semantics(kind="state/body/com_jacobian")
    def body_com_jacobian_w(self) -> ProxyArray:
        """Per-body geometric Jacobian referenced at each body's center of mass in world frame.

        Same shape and indexing conventions as :attr:`body_link_jacobian_w`. Linear
        rows ``[0:3]`` give the velocity at the body's center of mass; angular rows
        ``[3:6]`` are reference-point invariant (identical to
        :attr:`body_link_jacobian_w`).

        Contract: for any generalized velocity ``v``,

        .. code-block:: text

            J[:, jacobi_body_idx, 0:3, :] @ v == body_com_lin_vel_w[:, body_idx]
            J[:, jacobi_body_idx, 3:6, :] @ v == body_com_ang_vel_w[:, body_idx]
        """
        raise NotImplementedError(f"{type(self).__name__} does not implement body_com_jacobian_w.")

    @property
    @leapp_tensor_semantics(kind="state/joint/mass_matrix")
    def mass_matrix(self) -> ProxyArray:
        """Per-env generalized mass matrix ``M(q)`` in joint space.

        Shape: ``(num_instances, num_joints + num_base_dofs, num_joints + num_base_dofs)``,
        dtype ``wp.float32`` [kg·m² or kg, per DoF type]. DoF-axis convention matches
        :attr:`body_link_jacobian_w`.

        ``M(q)`` is symmetric positive-definite. ``M[i, j]`` is the coefficient
        relating DoF ``j``'s acceleration to the inertial torque on DoF ``i`` in
        ``M(q) q_ddot + C(q, q_dot) q_dot + g(q) = tau``.
        """
        raise NotImplementedError(f"{type(self).__name__} does not implement mass_matrix.")

    @property
    @leapp_tensor_semantics(kind="state/joint/gravity_compensation")
    def gravity_compensation_forces(self) -> ProxyArray:
        """Per-env gravity compensation torques ``g(q)`` in joint space.

        Shape: ``(num_instances, num_joints + num_base_dofs)``, dtype ``wp.float32``
        [N·m or N, per DoF type]. DoF-axis convention matches
        :attr:`body_link_jacobian_w`.

        ``g(q)`` is the gravity-loading term in
        ``M(q) q_ddot + C(q, q_dot) q_dot + g(q) = tau``. Applying ``tau = g(q)`` at
        ``q_dot = 0`` with no external load yields ``q_ddot = 0`` (static equilibrium
        under gravity).
        """
        raise NotImplementedError(f"{type(self).__name__} does not implement gravity_compensation_forces.")

    ##
    # Joint state properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.JOINT_POSITION, element_names_resolver=joint_names_resolver)
    def joint_pos(self) -> ProxyArray:
        """Joint positions of all joints.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to
        (num_instances, num_joints).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.JOINT_VELOCITY, element_names_resolver=joint_names_resolver)
    def joint_vel(self) -> ProxyArray:
        """Joint velocities of all joints.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to
        (num_instances, num_joints).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/joint/acceleration", element_names_resolver=joint_names_resolver)
    def joint_acc(self) -> ProxyArray:
        """Joint acceleration of all joints.

        Shape is (num_instances, num_joints), dtype = wp.float32. In torch this resolves to
        (num_instances, num_joints).
        """
        raise NotImplementedError

    ##
    # Derived Properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.VECTOR3D, element_names=XYZ_ELEMENT_NAMES)
    def projected_gravity_b(self) -> ProxyArray:
        """Projection of the gravity direction on base frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind="state/body/heading")
    def heading_w(self) -> ProxyArray:
        """Yaw heading of the base frame (in radians).

        Shape is (num_instances), dtype = wp.float32. In torch this resolves to (num_instances,).

        .. note::
            This quantity is computed by assuming that the forward-direction of the base
            frame is along x-direction, i.e. :math:`(1, 0, 0)`.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_link_lin_vel_b(self) -> ProxyArray:
        """Root link linear velocity in base frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the linear velocity of the articulation root's actor frame with respect to
        its actor frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_link_ang_vel_b(self) -> ProxyArray:
        """Root link angular velocity in base frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the angular velocity of the articulation root's actor frame with respect to
        its actor frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_com_lin_vel_b(self) -> ProxyArray:
        """Root center of mass linear velocity in base frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the linear velocity of the articulation root's center of mass frame with respect to
        its actor frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_com_ang_vel_b(self) -> ProxyArray:
        """Root center of mass angular velocity in base frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the angular velocity of the articulation root's center of mass frame with respect to
        its actor frame.
        """
        raise NotImplementedError

    ##
    # Sliced properties.
    ##

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names=XYZ_ELEMENT_NAMES)
    def root_link_pos_w(self) -> ProxyArray:
        """Root link position in simulation world frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the position of the actor frame of the root rigid body relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names=QUAT_XYZW_ELEMENT_NAMES)
    def root_link_quat_w(self) -> ProxyArray:
        """Root link orientation (x, y, z, w) in simulation world frame.

        Shape is (num_instances), dtype = wp.quatf. In torch this resolves to (num_instances, 4).

        This quantity is the orientation of the actor frame of the root rigid body.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_link_lin_vel_w(self) -> ProxyArray:
        """Root linear velocity in simulation world frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the linear velocity of the root rigid body's actor frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_link_ang_vel_w(self) -> ProxyArray:
        """Root link angular velocity in simulation world frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the angular velocity of the actor frame of the root rigid body relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names=XYZ_ELEMENT_NAMES)
    def root_com_pos_w(self) -> ProxyArray:
        """Root center of mass position in simulation world frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the position of the center of mass frame of the root rigid body relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names=QUAT_XYZW_ELEMENT_NAMES)
    def root_com_quat_w(self) -> ProxyArray:
        """Root center of mass orientation (x, y, z, w) in simulation world frame.

        Shape is (num_instances), dtype = wp.quatf. In torch this resolves to (num_instances, 4).

        This quantity is the orientation of the principal axes of inertia of the root rigid body relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_com_lin_vel_w(self) -> ProxyArray:
        """Root center of mass linear velocity in simulation world frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the linear velocity of the root rigid body's center of mass frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_com_ang_vel_w(self) -> ProxyArray:
        """Root center of mass angular velocity in simulation world frame.

        Shape is (num_instances), dtype = wp.vec3f. In torch this resolves to (num_instances, 3).

        This quantity is the angular velocity of the root rigid body's center of mass frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names_resolver=body_xyz_resolver)
    def body_link_pos_w(self) -> ProxyArray:
        """Positions of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the position of the articulation bodies' actor frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names_resolver=body_quat_resolver)
    def body_link_quat_w(self) -> ProxyArray:
        """Orientation (x, y, z, w) of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.quatf. In torch this resolves to
        (num_instances, num_bodies, 4).

        This quantity is the orientation of the articulation bodies' actor frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names_resolver=body_xyz_resolver)
    def body_link_lin_vel_w(self) -> ProxyArray:
        """Linear velocity of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the linear velocity of the articulation bodies' actor frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names_resolver=body_xyz_resolver)
    def body_link_ang_vel_w(self) -> ProxyArray:
        """Angular velocity of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the angular velocity of the articulation bodies' actor frame relative to the world.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names_resolver=body_xyz_resolver)
    def body_com_pos_w(self) -> ProxyArray:
        """Positions of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the position of the articulation bodies' center of mass frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names_resolver=body_quat_resolver)
    def body_com_quat_w(self) -> ProxyArray:
        """Orientation (x, y, z, w) of the principal axes of inertia of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.quatf. In torch this resolves to
        (num_instances, num_bodies, 4).

        This quantity is the orientation of the principal axes of inertia of the articulation bodies.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names_resolver=body_xyz_resolver)
    def body_com_lin_vel_w(self) -> ProxyArray:
        """Linear velocity of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the linear velocity of the articulation bodies' center of mass frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names_resolver=body_xyz_resolver)
    def body_com_ang_vel_w(self) -> ProxyArray:
        """Angular velocity of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the angular velocity of the articulation bodies' center of mass frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_ACCELERATION, element_names_resolver=body_xyz_resolver)
    def body_com_lin_acc_w(self) -> ProxyArray:
        """Linear acceleration of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the linear acceleration of the articulation bodies' center of mass frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_ACCELERATION, element_names_resolver=body_xyz_resolver)
    def body_com_ang_acc_w(self) -> ProxyArray:
        """Angular acceleration of all bodies in simulation world frame.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the angular acceleration of the articulation bodies' center of mass frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names_resolver=body_xyz_resolver)
    def body_com_pos_b(self) -> ProxyArray:
        """Center of mass position of all of the bodies in their respective link frames.

        Shape is (num_instances, num_bodies), dtype = wp.vec3f. In torch this resolves to
        (num_instances, num_bodies, 3).

        This quantity is the center of mass location relative to its body's link frame.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names_resolver=body_quat_resolver)
    def body_com_quat_b(self) -> ProxyArray:
        """Orientation (x, y, z, w) of the principal axes of inertia of all of the bodies in their respective link
        frames.

        Shape is (num_instances, num_bodies), dtype = wp.quatf. In torch this resolves to
        (num_instances, num_bodies, 4).

        This quantity is the orientation of the principal axes of inertia relative to its body's link frame.
        """
        raise NotImplementedError

    def _create_buffers(self) -> None:
        # -- Defaults (Lazy allocation of default values)
        self._default_mass = None
        self._default_inertia = None
        self._default_joint_stiffness = None
        self._default_joint_damping = None
        self._default_joint_armature = None
        self._default_joint_friction_coeff = None
        self._default_joint_viscous_friction_coeff = None
        self._default_joint_pos_limits = None
        self._default_fixed_tendon_stiffness = None
        self._default_fixed_tendon_damping = None
        self._default_fixed_tendon_limit_stiffness = None
        self._default_fixed_tendon_rest_length = None
        self._default_fixed_tendon_offset = None
        self._default_fixed_tendon_pos_limits = None
        self._default_spatial_tendon_stiffness = None
        self._default_spatial_tendon_damping = None
        self._default_spatial_tendon_limit_stiffness = None
        self._default_spatial_tendon_offset = None

    """
    Shorthands for commonly used properties.
    """

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names=POSE7_ELEMENT_NAMES)
    def root_pose_w(self) -> ProxyArray:
        """Shorthand for :attr:`root_link_pose_w`."""
        return self.root_link_pose_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names=XYZ_ELEMENT_NAMES)
    def root_pos_w(self) -> ProxyArray:
        """Shorthand for :attr:`root_link_pos_w`."""
        return self.root_link_pos_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names=QUAT_XYZW_ELEMENT_NAMES)
    def root_quat_w(self) -> ProxyArray:
        """Shorthand for :attr:`root_link_quat_w`."""
        return self.root_link_quat_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_VEL, element_names=POSE6_ELEMENT_NAMES)
    def root_vel_w(self) -> ProxyArray:
        """Shorthand for :attr:`root_com_vel_w`."""
        return self.root_com_vel_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_lin_vel_w(self) -> ProxyArray:
        """Shorthand for :attr:`root_com_lin_vel_w`."""
        return self.root_com_lin_vel_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_ang_vel_w(self) -> ProxyArray:
        """Shorthand for :attr:`root_com_ang_vel_w`."""
        return self.root_com_ang_vel_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_lin_vel_b(self) -> ProxyArray:
        """Shorthand for :attr:`root_com_lin_vel_b`."""
        return self.root_com_lin_vel_b

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names=XYZ_ELEMENT_NAMES)
    def root_ang_vel_b(self) -> ProxyArray:
        """Shorthand for :attr:`root_com_ang_vel_b`."""
        return self.root_com_ang_vel_b

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSE, element_names_resolver=body_pose_resolver)
    def body_pose_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_link_pose_w`."""
        return self.body_link_pose_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names_resolver=body_xyz_resolver)
    def body_pos_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_link_pos_w`."""
        return self.body_link_pos_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names_resolver=body_quat_resolver)
    def body_quat_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_link_quat_w`."""
        return self.body_link_quat_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_VEL, element_names_resolver=body_pose6_resolver)
    def body_vel_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_vel_w`."""
        return self.body_com_vel_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_VELOCITY, element_names_resolver=body_xyz_resolver)
    def body_lin_vel_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_lin_vel_w`."""
        return self.body_com_lin_vel_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_VELOCITY, element_names_resolver=body_xyz_resolver)
    def body_ang_vel_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_ang_vel_w`."""
        return self.body_com_ang_vel_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ACC, element_names_resolver=body_pose6_resolver)
    def body_acc_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_acc_w`."""
        return self.body_com_acc_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_LINEAR_ACCELERATION, element_names_resolver=body_xyz_resolver)
    def body_lin_acc_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_lin_acc_w`."""
        return self.body_com_lin_acc_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ANGULAR_ACCELERATION, element_names_resolver=body_xyz_resolver)
    def body_ang_acc_w(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_ang_acc_w`."""
        return self.body_com_ang_acc_w

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_POSITION, element_names_resolver=body_xyz_resolver)
    def com_pos_b(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_pos_b`."""
        return self.body_com_pos_b

    @property
    @leapp_tensor_semantics(kind=InputKindEnum.BODY_ROTATION, element_names_resolver=body_quat_resolver)
    def com_quat_b(self) -> ProxyArray:
        """Shorthand for :attr:`body_com_quat_b`."""
        return self.body_com_quat_b

    @property
    @leapp_tensor_semantics(const=True)
    def joint_limits(self) -> ProxyArray:
        """Shorthand for :attr:`joint_pos_limits`."""
        return self.joint_pos_limits

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_limits(self) -> ProxyArray:
        """Shorthand for :attr:`default_joint_pos_limits`."""
        return self.default_joint_pos_limits

    @property
    @leapp_tensor_semantics(const=True)
    def joint_velocity_limits(self) -> ProxyArray:
        """Shorthand for :attr:`joint_vel_limits`."""
        return self.joint_vel_limits

    @property
    @leapp_tensor_semantics(const=True)
    def joint_friction(self) -> ProxyArray:
        """Shorthand for :attr:`joint_friction_coeff`."""
        return self.joint_friction_coeff

    @property
    @leapp_tensor_semantics(const=True)
    def fixed_tendon_limit(self) -> ProxyArray:
        """Shorthand for :attr:`fixed_tendon_pos_limits`."""
        return self.fixed_tendon_pos_limits

    """
    Defaults - Default values will no longer be stored.
    """

    @property
    @leapp_tensor_semantics(const=True)
    def default_mass(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`body_mass` instead and manage the default mass manually."""
        warnings.warn(
            "The `default_mass` property will be deprecated in a IsaacLab 4.0. Please use `body_mass` instead. "
            "The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_mass is None:
            self._default_mass = wp.clone(self.body_mass.warp, self.device)
        return ProxyArray(self._default_mass)

    @property
    @leapp_tensor_semantics(const=True)
    def default_inertia(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`body_inertia` instead and manage the default inertia manually."""
        warnings.warn(
            "The `default_inertia` property will be deprecated in a IsaacLab 4.0. Please use `body_inertia` instead. "
            "The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_inertia is None:
            self._default_inertia = wp.clone(self.body_inertia.warp, self.device)
        return ProxyArray(self._default_inertia)

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_stiffness(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`joint_stiffness` instead and manage the default joint stiffness
        manually."""
        warnings.warn(
            "The `default_joint_stiffness` property will be deprecated in a IsaacLab 4.0. Please use `joint_stiffness` "
            "instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_joint_stiffness is None:
            self._default_joint_stiffness = wp.clone(self.joint_stiffness.warp, self.device)
        return ProxyArray(self._default_joint_stiffness)

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_damping(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`joint_damping` instead and manage the default joint damping
        manually."""
        warnings.warn(
            "The `default_joint_damping` property will be deprecated in a IsaacLab 4.0. Please use `joint_damping` "
            "instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_joint_damping is None:
            self._default_joint_damping = wp.clone(self.joint_damping.warp, self.device)
        return ProxyArray(self._default_joint_damping)

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_armature(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`joint_armature` instead and manage the default joint armature
        manually."""
        warnings.warn(
            "The `default_joint_armature` property will be deprecated in a IsaacLab 4.0. Please use `joint_armature` "
            "instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_joint_armature is None:
            self._default_joint_armature = wp.clone(self.joint_armature.warp, self.device)
        return ProxyArray(self._default_joint_armature)

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_friction_coeff(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`joint_friction_coeff` instead and manage the default joint friction
        coefficient manually."""
        warnings.warn(
            "The `default_joint_friction_coeff` property will be deprecated in a IsaacLab 4.0. Please use "
            "`joint_friction_coeff` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_joint_friction_coeff is None:
            self._default_joint_friction_coeff = wp.clone(self.joint_friction_coeff.warp, self.device)
        return ProxyArray(self._default_joint_friction_coeff)

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_viscous_friction_coeff(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`joint_viscous_friction_coeff` instead and manage the default joint
        viscous friction coefficient manually."""
        warnings.warn(
            "The `default_joint_viscous_friction_coeff` property will be deprecated in a IsaacLab 4.0. Please use "
            "`joint_viscous_friction_coeff` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_joint_viscous_friction_coeff is None:
            self._default_joint_viscous_friction_coeff = wp.clone(
                getattr(self, "joint_viscous_friction_coeff").warp, self.device
            )
        return ProxyArray(self._default_joint_viscous_friction_coeff)

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_pos_limits(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`joint_pos_limits` instead and manage the default joint position
        limits manually."""
        warnings.warn(
            "The `default_joint_pos_limits` property will be deprecated in a IsaacLab 4.0. Please use "
            "`joint_pos_limits` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_joint_pos_limits is None:
            self._default_joint_pos_limits = wp.clone(self.joint_pos_limits.warp, self.device)
        return ProxyArray(self._default_joint_pos_limits)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_stiffness(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`fixed_tendon_stiffness` instead and manage the default fixed tendon
        stiffness manually."""
        warnings.warn(
            "The `default_fixed_tendon_stiffness` property will be deprecated in a IsaacLab 4.0. Please use "
            "`fixed_tendon_stiffness` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_fixed_tendon_stiffness is None:
            self._default_fixed_tendon_stiffness = wp.clone(self.fixed_tendon_stiffness.warp, self.device)
        return ProxyArray(self._default_fixed_tendon_stiffness)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_damping(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`fixed_tendon_damping` instead and manage the default fixed tendon
        damping manually."""
        warnings.warn(
            "The `default_fixed_tendon_damping` property will be deprecated in a IsaacLab 4.0. Please use "
            "`fixed_tendon_damping` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_fixed_tendon_damping is None:
            self._default_fixed_tendon_damping = wp.clone(self.fixed_tendon_damping.warp, self.device)
        return ProxyArray(self._default_fixed_tendon_damping)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_limit_stiffness(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`fixed_tendon_limit_stiffness` instead and manage the default fixed
        tendon limit stiffness manually."""
        warnings.warn(
            "The `default_fixed_tendon_limit_stiffness` property will be deprecated in a IsaacLab 4.0. Please use "
            "`fixed_tendon_limit_stiffness` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_fixed_tendon_limit_stiffness is None:
            self._default_fixed_tendon_limit_stiffness = wp.clone(self.fixed_tendon_limit_stiffness.warp, self.device)
        return ProxyArray(self._default_fixed_tendon_limit_stiffness)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_rest_length(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`fixed_tendon_rest_length` instead and manage the default fixed tendon
        rest length manually."""
        warnings.warn(
            "The `default_fixed_tendon_rest_length` property will be deprecated in a IsaacLab 4.0. Please use "
            "`fixed_tendon_rest_length` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_fixed_tendon_rest_length is None:
            self._default_fixed_tendon_rest_length = wp.clone(self.fixed_tendon_rest_length.warp, self.device)
        return ProxyArray(self._default_fixed_tendon_rest_length)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_offset(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`fixed_tendon_offset` instead and manage the default fixed tendon
        offset manually."""
        warnings.warn(
            "The `default_fixed_tendon_offset` property will be deprecated in a IsaacLab 4.0. Please use "
            "`fixed_tendon_offset` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_fixed_tendon_offset is None:
            self._default_fixed_tendon_offset = wp.clone(self.fixed_tendon_offset.warp, self.device)
        return ProxyArray(self._default_fixed_tendon_offset)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_pos_limits(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`fixed_tendon_pos_limits` instead and manage the default fixed tendon
        position limits manually."""
        warnings.warn(
            "The `default_fixed_tendon_pos_limits` property will be deprecated in a IsaacLab 4.0. Please use "
            "`fixed_tendon_pos_limits` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_fixed_tendon_pos_limits is None:
            self._default_fixed_tendon_pos_limits = wp.clone(self.fixed_tendon_pos_limits.warp, self.device)
        return ProxyArray(self._default_fixed_tendon_pos_limits)

    @property
    @leapp_tensor_semantics(const=True)
    def default_spatial_tendon_stiffness(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`spatial_tendon_stiffness` instead and manage the default spatial
        tendon stiffness manually."""
        warnings.warn(
            "The `default_spatial_tendon_stiffness` property will be deprecated in a IsaacLab 4.0. Please use "
            "`spatial_tendon_stiffness` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_spatial_tendon_stiffness is None:
            self._default_spatial_tendon_stiffness = wp.clone(self.spatial_tendon_stiffness.warp, self.device)
        return ProxyArray(self._default_spatial_tendon_stiffness)

    @property
    @leapp_tensor_semantics(const=True)
    def default_spatial_tendon_damping(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`spatial_tendon_damping` instead and manage the default spatial tendon
        damping manually."""
        warnings.warn(
            "The `default_spatial_tendon_damping` property will be deprecated in a IsaacLab 4.0. Please use "
            "`spatial_tendon_damping` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_spatial_tendon_damping is None:
            self._default_spatial_tendon_damping = wp.clone(self.spatial_tendon_damping.warp, self.device)
        return ProxyArray(self._default_spatial_tendon_damping)

    @property
    @leapp_tensor_semantics(const=True)
    def default_spatial_tendon_limit_stiffness(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`spatial_tendon_limit_stiffness` instead and manage the default
        spatial tendon limit stiffness manually."""
        warnings.warn(
            "The `default_spatial_tendon_limit_stiffness` property will be deprecated in a IsaacLab 4.0. Please use "
            "`spatial_tendon_limit_stiffness` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_spatial_tendon_limit_stiffness is None:
            self._default_spatial_tendon_limit_stiffness = wp.clone(
                self.spatial_tendon_limit_stiffness.warp, self.device
            )
        return ProxyArray(self._default_spatial_tendon_limit_stiffness)

    @property
    @leapp_tensor_semantics(const=True)
    def default_spatial_tendon_offset(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`spatial_tendon_offset` instead and manage the default spatial tendon
        offset manually."""
        warnings.warn(
            "The `default_spatial_tendon_offset` property will be deprecated in a IsaacLab 4.0. Please use "
            "`spatial_tendon_offset` instead. The default value will need to be managed manually.",
            DeprecationWarning,
            stacklevel=2,
        )
        if self._default_spatial_tendon_offset is None:
            self._default_spatial_tendon_offset = wp.clone(self.spatial_tendon_offset.warp, self.device)
        return ProxyArray(self._default_spatial_tendon_offset)

    @property
    @leapp_tensor_semantics(const=True)
    def default_fixed_tendon_limit(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`default_fixed_tendon_pos_limits` instead."""
        warnings.warn(
            "The `default_fixed_tendon_limit` property will be deprecated in a IsaacLab 4.0. Please use"
            " `default_fixed_tendon_pos_limits` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.default_fixed_tendon_pos_limits

    @property
    @leapp_tensor_semantics(const=True)
    def default_joint_friction(self) -> ProxyArray:
        """Deprecated property. Please use :attr:`default_joint_friction_coeff` instead."""
        warnings.warn(
            "The `default_joint_friction` property will be deprecated in a IsaacLab 4.0. Please use"
            " `default_joint_friction_coeff` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.default_joint_friction_coeff
